// Card 29 re-check: the shell always starts after routing, even when a surface chunk fails to load (a stale
// chunk after a deploy, or a network error), so the service worker registers and can offer the update.
export async function boot({ route, notice, startShell }) {
  try { await route(); }
  catch { try { notice(); } catch { /* The shell still starts. */ } }
  finally { startShell(); }
}

/** Text-only notice in the page's main landmark. */
export function loadFailedNotice(doc = globalThis.document) {
  const main = doc.querySelector('main');
  if (!main) return;
  const title = doc.createElement('h1'); title.textContent = 'Case could not load this page';
  const text = doc.createElement('p'); text.textContent = 'Check your connection, then reload. If Case was just updated, reloading fetches the new version.';
  text.setAttribute('role', 'alert');
  main.replaceChildren(title, text);
}
