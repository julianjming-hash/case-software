import {isUuid,isUuidV7,normalizeCode} from '../shared/ids.mjs';
import {isTint} from '../shared/tints.mjs';
const exact=(value,keys)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===keys.length&&keys.every(k=>Object.hasOwn(value,k));
const text=(v,max=320)=>typeof v==='string'&&v.length>0&&v.length<=max&&!/[\u0000-\u001f\u007f]/.test(v);
const email=v=>text(v)&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const date=v=>typeof v==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,6})?(?:Z|[+-]\d\d:\d\d)$/.test(v)&&Number.isFinite(Date.parse(v));
const nullable=(v,check)=>v===null||check(v);
const revision=v=>Number.isSafeInteger(v)&&v>=0&&v<=9999999999;
const profile=v=>exact(v,['user_id','disabled_at','soft_deleted_at','delete_due_at','admin_revision'])&&isUuid(v.user_id)&&['disabled_at','soft_deleted_at','delete_due_at'].every(k=>nullable(v[k],date))&&revision(v.admin_revision);
const cursor=(v,room=false)=>nullable(v,x=>room?typeof x==='string'&&/^[0-9A-HJKMNP-TV-Z](?::[0-9A-HJKMNP-TV-Z]{6})?$/.test(x)&&(!x.includes(':')||x[0]===x[2]):isUuidV7(x));
const array=(rows,max,check,id)=>Array.isArray(rows)&&rows.length<=max&&rows.every(check)&&new Set(rows.map(r=>r[id])).size===rows.length;
const user=v=>exact(v,['id','email','invitedAt','confirmedAt','bannedUntil','createdAt','profile'])&&isUuid(v.id)&&email(v.email)&&nullable(v.createdAt,date)&&['invitedAt','confirmedAt','bannedUntil'].every(k=>nullable(v[k],date))&&nullable(v.profile,p=>profile(p)&&p.user_id===v.id);
const version=v=>exact(v,['case_id','version_id','version_no','title','status','admin_revision','workspace_id','group_id','group_name','tint','group_revision'])&&isUuidV7(v.case_id)&&isUuidV7(v.version_id)&&Number.isSafeInteger(v.version_no)&&v.version_no>0&&text(v.title,200)&&['published','withdrawn'].includes(v.status)&&revision(v.admin_revision)&&isUuidV7(v.workspace_id)&&revision(v.group_revision)&&(v.group_id===null?v.group_name===null&&v.tint==='neutral':isUuidV7(v.group_id)&&text(v.group_name,60)&&isTint(v.tint));
const room=v=>exact(v,['code','sessionId','registeredAt','expiresAt','ownerEmail','phase','participantCount'])&&normalizeCode(v.code,6)===v.code&&isUuidV7(v.sessionId)&&nullable(v.registeredAt,date)&&date(v.expiresAt)&&nullable(v.ownerEmail,email)&&['lobby','surface_live','responses_open','responses_locked','path_selected','consequence_revealed','terminal_teaching','discussion_paused','ended'].includes(v.phase)&&Number.isInteger(v.participantCount)&&v.participantCount>=0&&v.participantCount<=300;
const statuses=['active','disabled','soft_deleted','restored','invited','withdrawn','published','ended','accepted','rejected','rate_limited','unknown','reconciliation_needed','completed','failed','unknown_outcome','manual_reconciliation_needed'];
function auditSnapshot(v){return v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).every(k=>k==='status'?statuses.includes(v[k]):k==='email'?email(v[k]):['admin_revision','version_no'].includes(k)&&revision(v[k]));}
const actions=['stepup_start','stepup_verify','facilitator_invite','facilitator_resend','facilitator_disable','facilitator_enable','facilitator_soft_delete','facilitator_restore','facilitator_hard_delete','case_publish','version_withdraw','room_end'];
const audit=v=>exact(v,['id','intent_id','phase','action','target_type','target_id','actor_email','before','after','at','from_prefix'])&&isUuidV7(v.id)&&nullable(v.intent_id,isUuidV7)&&['intent','outcome','attempt'].includes(v.phase)&&(v.phase==='intent'?v.intent_id===v.id:v.phase==='outcome'?v.intent_id!==null&&v.intent_id!==v.id:v.intent_id===null)&&actions.includes(v.action)&&['admin','facilitator','case','version','room'].includes(v.target_type)&&nullable(v.target_id,isUuid)&&email(v.actor_email)&&auditSnapshot(v.before)&&auditSnapshot(v.after)&&date(v.at)&&nullable(v.from_prefix,x=>typeof x==='string'&&x.length<=64&&/^[0-9a-f.:]+\/(?:24|64)$/.test(x));
export function acceptAdminResponse(operation,value){
 let valid=false;
 if(['facilitators_list','facilitators_search'].includes(operation))valid=exact(value,['users','nextPage'])&&array(value.users,1000,user,'id')&&nullable(value.nextPage,x=>Number.isSafeInteger(x)&&x>=1&&x<=100000);
 else if(operation==='cases_list')valid=exact(value,['versions','nextCursor'])&&array(value.versions,100,version,'version_id')&&cursor(value.nextCursor);
 else if(operation==='rooms_list')valid=exact(value,['rooms','nextCursor'])&&array(value.rooms,100,room,'sessionId')&&cursor(value.nextCursor,true);
 else if(operation==='audit_list')valid=exact(value,['events','nextCursor'])&&array(value.events,100,audit,'id')&&cursor(value.nextCursor);
 else if(operation==='stepup_start')valid=exact(value,['accepted'])&&value.accepted===true;
 else if(operation==='stepup_verify')valid=exact(value,['elevation'])&&text(value.elevation,2048);
 else if(operation==='facilitators_invite')valid=exact(value,['accepted','userId','idempotent'])&&value.accepted===true&&isUuid(value.userId)&&typeof value.idempotent==='boolean';
 else if(operation==='facilitators_resend')valid=exact(value,['accepted','userId'])&&value.accepted===true&&isUuid(value.userId);
 else if(operation.startsWith('facilitators_'))valid=exact(value,['profile'])&&profile(value.profile);
 else if(['cases_publish','versions_withdraw'].includes(operation))valid=exact(value,['version'])&&exact(value.version,['version_id','status','admin_revision'])&&isUuidV7(value.version.version_id)&&['published','withdrawn'].includes(value.version.status)&&revision(value.version.admin_revision);
 else if(operation==='rooms_end')valid=exact(value,['ended'])&&value.ended===true;
 return valid?value:null;
}
