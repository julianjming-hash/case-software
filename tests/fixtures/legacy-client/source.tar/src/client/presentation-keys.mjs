// One gate shared by the served console and the prototype. A key on an existing control belongs
// to that control, even when it is the same key used to advance a presentation.
const INTERACTIVE = 'input,textarea,select,button,a,summary,dialog,[role="button"],[role="dialog"],[role="textbox"],[aria-modal="true"],[contenteditable]';
export function presentationKeyAction(event, { hasMoreGroup = false, replaying = false, canReplayForward = false, canReplayBack = false } = {}) {
  if (event.defaultPrevented || event.repeat || event.isComposing || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return null;
  if (event.target?.isContentEditable || event.target?.closest?.(INTERACTIVE)) return null;
  if (event.key === 'ArrowLeft') return canReplayBack ? 'replay_back' : null;
  if (!['ArrowRight', ' ', 'Enter'].includes(event.key)) return null;
  if (replaying) return canReplayForward ? 'replay_forward' : null;
  return hasMoreGroup ? 'reveal_group' : null;
}
