// Case detail (card 29, CASE-166): cover, summary, learning objectives, audience, setting, version and the
// pilot pin, then Start room. Start room keeps its authority and flow: the Worker rechecks membership and
// the published document, and the room opens at its lobby, where the display check lives.
import { accountRequest, node } from './auth-ui.mjs';
import { isUuidV7 } from '../shared/ids.mjs';
import { casesUrl } from '../shared/urls.mjs';
import { validCatalogueRow, validVersionList } from '../shared/catalogue.mjs';
import { validCaseGroup, UNGROUPED } from '../shared/groups.mjs';
import { paintCovers, clearCoverCache } from './cover-art.mjs';
import { watchTheme } from './appearance.mjs';
import { lengthText, fieldText } from './library-model.mjs';
import { coverFor, pilotTag, formatDate } from './library-parts.mjs';

const ROW_KEYS = ['version_id', 'case_id', 'title', 'summary', 'audience', 'setting', 'duration_min', 'version_no',
  'published_at', 'content_sha256', 'art'];
export function catalogueCase(value, caseId, versionNo) {
  const item = value?.case;
  // Card 30: the case's group arrives beside the row; the cover takes its tint.
  const group = item?.group;
  const row = item && validCaseGroup(group) && { ...Object.fromEntries(ROW_KEYS.map(key => [key, item[key]])),
    group_id: group.id, group_name: group.name, tint: group.tint };
  if (!row || !validCatalogueRow(row) || row.case_id !== caseId || row.version_no !== versionNo || !isUuidV7(item.workspace_id) ||
      !['owner', 'author', 'facilitator', 'admin'].includes(item.role) || !Array.isArray(item.learning_objectives) ||
      item.learning_objectives.length > 8 || item.learning_objectives.some(o => typeof o !== 'string') ||
      !validVersionList(item.versions) || !item.versions.some(v => v.version_id === row.version_id))
    throw new Error('invalid_case');
  return { row, workspaceId: item.workspace_id, role: item.role, group, objectives: item.learning_objectives, versions: item.versions,
    pilotPin: value.pilotPin ?? null };
}

export function mountCaseDetail(host, { auth, caseId, versionNo, onBack, onStart, onGroupChanged = () => {} }) {
  let closed = false, covers = [], picker = null;
  const root = node('article', null, 'case-detail'); root.setAttribute('aria-labelledby', 'caseDetailTitle');
  const back = node('a', '← Cases', 'case-back'); back.href = casesUrl(location.origin);
  back.addEventListener('click', event => {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault(); onBack();
  });
  const status = node('p', 'Loading case…', 'case-detail-status'); status.setAttribute('role', 'status');
  root.append(back, status);
  host.append(root);
  const stopTheme = watchTheme(() => { clearCoverCache(); void paintCovers(covers, { cssSize: 400 }); });

  void (async () => {
    try {
      const value = await accountRequest(auth, ['cases', caseId, 'versions', String(versionNo)]);
      if (closed) return;
      const { row, workspaceId, role, group, objectives, versions, pilotPin } = catalogueCase(value, caseId, versionNo);
      const layout = node('div', null, 'case-detail-layout');
      const cover = coverFor(row, covers = [], 'cover large');
      const info = node('div', null, 'case-detail-info');
      const heading = node('h1', row.title); heading.id = 'caseDetailTitle'; heading.tabIndex = -1;
      const facts = node('dl', null, 'case-facts');
      for (const [term, value] of [['Length', lengthText(row.duration_min)], ['Audience', fieldText(row.audience, 'audience')],
        ['Setting', fieldText(row.setting, 'setting')], ['Group', group.name ?? UNGROUPED],
        ['Published', `Version ${row.version_no} · ${formatDate(row.published_at)}`]])
        facts.append(node('dt', term), node('dd', value));
      const groupFact = [...facts.querySelectorAll('dt')].find(dt => dt.textContent === 'Group')?.nextElementSibling;
      const summary = node('p', fieldText(row.summary, 'summary'), 'case-detail-summary');
      const learning = node('section', null, 'case-objectives');
      learning.append(node('h2', 'Learning objectives'));
      if (objectives.length) { const list = node('ul'); for (const item of objectives) list.append(node('li', item)); learning.append(list); }
      else learning.append(node('p', 'Learning objectives not set'));
      const pin = pilotTag(row, pilotPin);
      pin.id = `pilot-pin-${row.version_id}`;
      const start = node('button', 'Start room', 'btn primary lg'); start.type = 'button';
      start.setAttribute('aria-describedby', pin.id);
      const startStatus = node('p', '', 'case-start-note');
      startStatus.setAttribute('role', 'status');
      start.addEventListener('click', async () => {
        if (closed || start.disabled) return;
        start.disabled = true; startStatus.textContent = 'Starting room…';
        try { await onStart({ workspaceId, versionId: row.version_id }); }
        catch { if (!closed) startStatus.textContent = 'The room could not start. Try again.'; }
        finally { if (!closed) start.disabled = false; }
      });
      const actions = node('div', null, 'case-start');
      actions.append(start, startStatus);
      // Every published version of the case (Julian, 2026-10-06): the card shows the latest; an older or
      // pilot-pinned version stays startable here with the same authority.
      const others = versions.filter(v => v.version_id !== row.version_id);
      const history = node('section', null, 'case-versions');
      history.append(node('h2', 'Published versions'));
      const list = node('ul', null, 'case-version-list');
      for (const version of versions) {
        const item = node('li', null, 'case-version');
        const tag = pilotTag(version, pilotPin);
        item.append(node('span', `Version ${version.version_no} · ${formatDate(version.published_at)}${version.version_id === row.version_id ? ' · shown above' : ''}`), tag);
        if (version.version_id !== row.version_id) {
          tag.id = `pilot-pin-${version.version_id}`;
          const other = node('button', `Start room with version ${version.version_no}`, 'btn quiet'); other.type = 'button';
          other.setAttribute('aria-describedby', tag.id);
          other.addEventListener('click', async () => {
            if (closed || other.disabled) return;
            other.disabled = true; startStatus.textContent = 'Starting room…';
            try { await onStart({ workspaceId, versionId: version.version_id }); }
            catch { if (!closed) startStatus.textContent = 'The room could not start. Try again.'; }
            finally { if (!closed) other.disabled = false; }
          });
          item.append(other);
        }
        list.append(item);
      }
      history.append(list);
      const groupSlot = node('div', null, 'case-group-slot');
      info.append(heading, facts, groupSlot, summary, learning, pin, actions, ...(others.length ? [history] : []));
      layout.append(cover, info);
      status.textContent = ''; status.classList.add('sr-only');
      root.append(layout);
      heading.focus();
      void paintCovers(covers, { cssSize: 400 });
      // Owners of the case's workspace assign its group here (P-20); the control is its own lazy chunk.
      if (role === 'owner') {
        const loaded = await import('./groups-screen.mjs').catch(() => null);
        if (closed || !loaded) return;
        picker = loaded.mountCaseGroup(groupSlot, { request: (parts, options) => accountRequest(auth, parts, options), workspaceId, caseId, group,
          onChanged: next => {
            if (groupFact) groupFact.textContent = next.name ?? UNGROUPED;
            cover.dataset.tint = next.tint;
            for (const item of covers) item.group = next.tint;
            void paintCovers(covers, { cssSize: 400 });
            onGroupChanged(next);
          } });
      }
    } catch {
      if (!closed) status.textContent = 'This case is unavailable. It may have been withdrawn, or it is not in your workspaces.';
    }
  })();
  return { close() { closed = true; stopTheme(); picker?.close(); root.remove(); } };
}
