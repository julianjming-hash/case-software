// The projector's two approved room events (CASE-139, CASE-169) and their neutral fallback tone.
import { createCuePlayer } from './room-cues.mjs';
export const CUE_FOR_EVENT = Object.freeze({ decision_open: 'decision-opened', reveal: 'material-revealed' });
const HZ = Object.freeze({ decision_open: 440, reveal: 330 });
function tone(ctx, kind) {
  const oscillator = ctx.createOscillator(), gain = ctx.createGain();
  oscillator.type = 'sine'; oscillator.frequency.value = HZ[kind];
  gain.gain.setValueAtTime(0, ctx.currentTime); gain.gain.linearRampToValueAtTime(.035, ctx.currentTime + .02);
  gain.gain.linearRampToValueAtTime(0, ctx.currentTime + .16);
  oscillator.connect(gain); gain.connect(ctx.destination); oscillator.start(); oscillator.stop(ctx.currentTime + .18);
  oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
}
export const createRoomCuePlayer = options => createCuePlayer({ map: CUE_FOR_EVENT, fallback: tone, ...options });
