// The one Worker authorization core (card 35, docs/PERMISSIONS.md §4.1, invariants 1-3, 9).
//
// actorFor() is the ONLY place the admin flag is computed: from the verified JWT and ADMIN_EMAILS (CASE-137),
// never from a body, header, query, cookie or cached /me value. authorize() reads the caller's membership
// once per request and applies the shared matrix (src/shared/permissions.mjs). adminArgs() is the only
// producer of the p_admin/p_admin_email RPC arguments; the RPCs check them again in SQL (case_app.authorize).
import { isAdminUser, adminEmails } from './admin/gate.mjs';
import { accountActive } from './admin/account-active.mjs';
import { isUuidV7 } from '../shared/ids.mjs';
import { MATRIX, WORKSPACE_ROLES, rolesFor, adminReaches } from '../shared/permissions.mjs';
import { readMe } from './published-rooms.mjs';

const refuse = (error, status) => ({ ok: false, error, status });

/** The request's actor. `user` must come from verifyFacilitatorJwt; nothing else may set `admin`. */
export function actorFor(user, env) {
  const admin = isAdminUser(user, env);
  return Object.freeze({ userId: user.userId, email: admin ? user.email : null, admin });
}

/** The admin arguments every workspace RPC receives. A non-admin sends false and null. */
export function adminArgs(actor) {
  return actor?.admin === true && typeof actor.email === 'string'
    ? { p_admin: true, p_admin_email: actor.email } : { p_admin: false, p_admin_email: null };
}

/** Pure: may this role (or the admin path) take this action, per the matrix? Step-up is checked by the caller. */
export function allows(action, { admin = false, role = null } = {}) {
  if (!Object.hasOwn(MATRIX, action)) return false;
  if (admin) return adminReaches(action);
  return WORKSPACE_ROLES.includes(role) && rolesFor(action).includes(role);
}

/**
 * Authorize (actor, workspace, action) for one request. Reads get_me once (membership and display name).
 * Resolves `{ ok, role, profile }` where role is 'admin' on the admin path, or `{ ok: false, error, status }`.
 */
export async function authorize(client, actor, workspaceId, action, onAlert) {
  if (!Object.hasOwn(MATRIX, action)) throw new TypeError(`unknown action ${action}`);
  if (!actor || !isUuidV7(workspaceId)) return refuse('forbidden', 403);
  const me = await readMe(client, actor.userId, { limit: 1, workspaceId, admin: adminArgs(actor) }, onAlert);
  if (!me.ok) return me;
  const membership = me.memberships.find(row => row?.workspace_id === workspaceId);
  if (actor.admin) {
    // An admin's get_me lists every workspace (as 'admin'); an absent one does not exist.
    if (!membership) return refuse('not_found', 404);
    if (!allows(action, { admin: true })) return refuse('forbidden', 403);
    return { ok: true, role: 'admin', profile: me.profile };
  }
  if (!membership || !allows(action, { role: membership.role })) return refuse('forbidden', 403);
  return { ok: true, role: membership.role, profile: me.profile };
}

/** SHA-256 hex of an admin's verified email: a room records it so a later mint can re-test ADMIN_EMAILS. */
export async function emailDigest(email) {
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(email));
  return Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, '0')).join('');
}

/**
 * The room starter as an actor, for a mint with no JWT in hand (shared-PC pickup): the starter's user id,
 * and the admin path only if the digest the room recorded at start still matches a CURRENT ADMIN_EMAILS entry.
 */
export async function starterActor(userId, ownerAdminDigest, env) {
  if (typeof ownerAdminDigest === 'string') {
    for (const email of adminEmails(env) ?? []) {
      if (await emailDigest(email) === ownerAdminDigest) return Object.freeze({ userId, email, admin: true });
    }
  }
  return Object.freeze({ userId, email: null, admin: false });
}

/**
 * Invariant 10: a console credential (re-mint P-24, shared-PC approval P-25, pickup) is minted only for an
 * active account that is still a member of the room's workspace, or an admin. `room` is the DO's
 * canIssueFacilitatorToken answer. An inline dev room (marked by its DO) is re-minted only where inline rooms
 * are on. A room started before this Worker records no workspace in its DO; its workspace is then read from its
 * session row (red-team item 3), and a room with neither is refused.
 */
export async function mayMintConsole(client, actor, room, action, env, onAlert, sessionId) {
  if (room?.inlineDev === true) return env?.CASE_DEV_INLINE_CASES === '1' ? { ok: true } : refuse('forbidden', 403);
  let workspaceId = room?.workspaceId;
  if (workspaceId === null || workspaceId === undefined) {
    if (!isUuidV7(sessionId)) return refuse('unavailable', 503);
    const found = await client.call('get_session_workspace', { p_session_id: sessionId });
    if (!found?.ok) return refuse('unavailable', 503);
    if (!isUuidV7(found.data)) return refuse('forbidden', 403);
    workspaceId = found.data;
  }
  if (!isUuidV7(workspaceId)) return refuse('unavailable', 503);
  const active = await accountActive(client, actor.userId);
  if (active) return refuse(active.error, active.status);
  const member = await authorize(client, actor, workspaceId, action, onAlert);
  return member.ok ? { ok: true } : refuse(member.status === 404 ? 'forbidden' : member.error, member.status === 404 ? 403 : member.status);
}
