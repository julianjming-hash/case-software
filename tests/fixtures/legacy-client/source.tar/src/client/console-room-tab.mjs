// The console's Room tab (card 36b, CASE-174): a lazy chunk that console-room.mjs preloads when the room mounts,
// so the Run tab's first paint does not carry it. It renders the tab's controls down to Settings, with the labels
// and order they had inline; the Manual room and This console sections stay in console-room.mjs, so the outage
// path never depends on this chunk; the room's state and commands stay in console-room.mjs and arrive through `c` (getters and
// callbacks, never a copy of the capability). Only console-room.mjs imports it (tests/surface-parity-36b.test.mjs).
import { devicePairUrl } from '../shared/urls.mjs';
import { accountRequest, node } from './auth-ui.mjs';
import { formatCode, normalizeCode, PAIR_CODE_LENGTH } from '../shared/ids.mjs';
import { cleanText } from '../shared/text.mjs';
import { avatarEl } from './avatar.mjs';
import { displayNameProblem, normaliseDisplayName } from '../shared/participant.mjs';

const keyed = (key, item) => { item.dataset.focusKey = key; return item; };

export function renderRoomTab(view, c) {
  const { el, button, section, roomCommand, render } = c;
  const { manual } = c.state();
  const panel = el('section', null, 'console-room-tab'); panel.id = 'console-room-tab';
  const people = section(`People · ${view.participants?.filter(p => !p.removed).length ?? 0}`);
  const roster = view.participants?.filter(p => !p.removed) ?? [];
  if (!roster.length) people.append(el('p', 'No one has joined yet'));
  for (const person of roster) {
    const row = el('div', null, 'console-person');
    row.dataset.id = person.id; // what Rename and Remove capture, so an unchanged row is never kept stale (card 37)
    const identity = el('div', null, 'console-person-identity');
    const name = cleanText(person.name || 'Unnamed', 80);
    const joinedAt = Date.parse(person.joinedAt);
    identity.append(avatarEl(person.avatarId, { size: 36, name }),
      el('span', name), el('small', `Joined ${Number.isFinite(joinedAt) ?
        new Date(joinedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) :
        'time unavailable'}`));
    row.append(identity);
    // Focus keys and the confirm name the person, not only the name: two people may share one (card 37).
    const joined = Number.isFinite(joinedAt) ? new Date(joinedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : 'time unavailable';
    if (view.actions?.includes('rename')) row.append(keyed(`rename-${person.id}`, button(`Rename ${name}`, () => {
      const requested = window.prompt('Rename participant', name);
      if (requested == null) return;
      const renamed = normaliseDisplayName(requested);
      if (displayNameProblem(renamed)) {
        c.setStatus('Use a name of 3 to 20 letters, numbers, spaces, hyphens or apostrophes.');
        render(); return;
      }
      roomCommand('rename', { participantId: person.id, displayName: renamed });
    }, 'btn tertiary')));
    if (view.actions?.includes('remove_participant')) row.append(keyed(`remove-${person.id}`, button(`Remove ${person.name || 'participant'} from room`, () => {
      if (window.confirm(`Remove ${cleanText(person.name || 'participant', 80)} (joined ${joined}) from room?`))
        roomCommand('remove_participant', { participantId: person.id });
    }, 'btn tertiary')));
    people.append(row);
  }
  people.append(el('p', 'Join code', 'eyebrow'), el('p', formatCode(c.joinCode), 'mono console-code'));
  if (view.actions?.includes('close_joining')) people.append(button(view.joiningClosed ? 'Reopen joining' : 'Close joining',
    () => roomCommand('close_joining', { closed: !view.joiningClosed })));
  panel.append(people);

  panel.append(c.projectorSetup());
  // A slot: console-room.mjs places the persistent panel in it after reconciling, so typed codes survive (card 37).
  if (c.sharedComputer() && !manual) { const slot = el('div', null, 'console-shared-slot'); slot.dataset.keep = 'shared-computer'; panel.append(slot); }
  const consoles = c.consoles();
  if (consoles && !manual) panel.append(renderConsoles(consoles, c));

  if (view.actions?.includes('show_names')) panel.append(button(view.namesShown ?
    'Hide names on projector' : 'Show names on projector', () => roomCommand('show_names', { on: !view.namesShown })));
  if (view.actions?.includes('set_timer')) {
    const settings = section('Settings');
    const timer = el('select'); timer.setAttribute('aria-label', 'Round timer');
    timer.dataset.focusKey = 'round-timer';
    for (const [seconds, label] of [[null, 'No timer'], [60, '1 minute'], [120, '2 minutes'], [300, '5 minutes']]) {
      const option = el('option', label); option.value = seconds ?? ''; timer.append(option);
    }
    settings.append(timer, button('Set timer', event => {
      const pick = event.currentTarget.closest('section').querySelector('[data-focus-key="round-timer"]').value; // the live pick
      roomCommand('set_timer', { seconds: pick ? Number(pick) : null });
    }));
    panel.append(settings);
  }
  return panel;
}

// Consoles (card 35b, E27, P-27, CASE-177): the signed-in starter sees the room's live console credentials (device
// kind and issue time only) and stops one shared computer now. Rendered into the patched Room tab, so its
// controls take property handlers and id-based focus keys (card 37); the list itself lives in createConsoles.
function renderConsoles(consoles, c) {
  const { el, button, section, render } = c;
  const { rows, failed } = consoles.view();
  const card = section('Consoles', 'console-card console-consoles');
  card.append(el('p', 'Stopping a shared computer takes it out of this room at once. This console, the projector and participants carry on.', 'field-hint'));
  // Loaded once on first render; after a failure only Refresh asks again, so a render never loops a request.
  if (!rows) { if (!failed) consoles.load(); card.append(el('p', failed ? 'The consoles could not be listed.' : 'Checking consoles…')); }
  for (const entry of rows ?? []) {
    const row = el('div', null, 'console-person'); row.dataset.id = `console-${entry.id}`;
    const since = time(entry.issuedAt), shared = entry.kind === 'shared';
    row.append(el('span', entry.kind === 'unknown' ? `Console paired before an update · since ${since} · use Take over or End room to remove it`
      : `${shared ? 'Shared computer' : 'Signed-in device'} · since ${since}`));
    if (shared) row.append(keyed(`revoke-console-${entry.id}`, button(`Stop shared computer (since ${since})`, () => {
      if (window.confirm(`Stop the shared computer that joined at ${since}? It leaves the room now and needs a new approval to return.`))
        consoles.revoke(entry.id);
    }, 'btn danger')));
    card.append(row);
  }
  card.append(keyed('refresh-consoles', button('Refresh consoles', () => { consoles.load(); render(); }, 'btn tertiary')));
  return card;
}

/** The starter's console list for one room, fetched with the account session (never the room capability). */
export function createConsoles({ auth, sessionId, render, setStatus }) {
  let rows = null, failed = false, loading = false;
  const path = ['sessions', sessionId, 'consoles'];
  async function load() {
    if (loading) return;
    loading = true;
    try {
      const body = await accountRequest(auth, path);
      rows = Array.isArray(body?.consoles) ? body.consoles.filter(entry => Number.isSafeInteger(entry?.id) &&
        ['shared', 'starter', 'unknown'].includes(entry.kind)) : []; failed = false;
    } catch { rows = null; failed = true; }
    finally { loading = false; render(); }
  }
  async function revoke(id) {
    try {
      await accountRequest(auth, [...path, 'revoke'], { method: 'POST', body: { id } });
      setStatus('Shared computer stopped. It has left this room.');
    } catch { setStatus('That shared computer could not be stopped. Refresh and try again; a console paired before an update needs Take over or End room.'); }
    rows = null; await load();
  }
  return { view: () => ({ rows, failed }), load, revoke };
}

// "Use a shared computer" (card 29, CASE-166; formerly "Approve a PC" on the library page). It lives in
// the console Room tab beside display pairing and is scoped to this room: the room is preselected, never
// chosen from a list. The approval flow and confirmation are unchanged: preview the computer's code, show
// browser, coarse location, requested and expiry in a review dialog, then approve. The computer then takes
// over the room and this console is fenced. The panel and dialog are created once and kept across Room
// tab re-renders, so a typed code, a preview or an open dialog survive room updates.

const BROWSERS = ['Chrome', 'Edge', 'Firefox', 'Safari', 'Other'];
const time = value => { const at = new Date(value); return Number.isFinite(at.getTime()) ? at.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : 'Not recorded'; };

export function createSharedComputer({ auth, sessionId, joinCode }) {
  const room = formatCode(joinCode);
  const section = node('section', null, 'console-card console-shared-computer');
  const heading = node('h2', 'Use a shared computer');
  const pairPath = devicePairUrl('00000000', location.origin).replace(/\/00000000$/, '');
  const explain = node('p', `Run this room from a shared computer without signing your account into it. Open ${pairPath.replace(/^https?:\/\//, '')} on that computer and enter the eight-character code it shows.`);
  const label = node('label', 'Computer code', 'computer-code-label');
  const input = node('input', null, 'computer-code-input mono'); input.type = 'text'; input.maxLength = 11;
  input.autocomplete = 'off'; input.spellcheck = false; input.placeholder = 'XXXX XXXX'; input.dataset.focusKey = 'computer-code';
  input.setAttribute('autocapitalize', 'characters'); input.setAttribute('aria-describedby', 'computerCodeHint');
  label.append(input);
  const hint = node('p', 'Eight characters, shown on the shared computer. This is not the room code. This device stops controlling the room once the computer takes over.', 'field-hint');
  hint.id = 'computerCodeHint';
  const review = node('button', 'Review computer', 'btn quiet'); review.type = 'button'; review.dataset.focusKey = 'review-computer';
  const status = node('p', '', 'console-status'); status.setAttribute('role', 'status');
  section.append(heading, explain, label, hint, review, status);

  const dialog = node('dialog', null, 'computer-dialog'); dialog.setAttribute('aria-labelledby', 'computerDialogTitle');
  const title = node('h2', `Use this computer for room ${room}?`); title.id = 'computerDialogTitle';
  const facts = node('dl', null, 'kv');
  const note = node('p', 'The computer gets control of this room only: no account, no library, no administration. This console stops controlling the room. Participants and the projector carry on unaffected.', 'banner manual');
  const cancel = node('button', 'Cancel', 'btn tertiary'); cancel.type = 'button';
  const approve = node('button', `Approve room ${room}`, 'btn primary'); approve.type = 'button';
  const buttons = node('div', null, 'dialog-actions'); buttons.append(cancel, approve);
  dialog.append(title, facts, note, buttons);
  document.body.append(dialog);

  let code = null, generation = 0, busy = false, closed = false;
  const reset = () => { code = null; generation++; };
  review.addEventListener('click', async () => {
    if (closed || busy) return;
    const next = normalizeCode(input.value, PAIR_CODE_LENGTH);
    if (!next) { status.textContent = 'Enter the eight-character code shown on the shared computer.'; return; }
    const current = ++generation; code = null; busy = true; review.disabled = true; status.textContent = 'Checking the computer…';
    try {
      const seen = await accountRequest(auth, ['console-pairs', 'preview'], { method: 'POST', body: { code: next } });
      if (closed || current !== generation) return;
      if (!BROWSERS.includes(seen?.browser) || typeof seen.country !== 'string' || typeof seen.city !== 'string') throw new Error('invalid_preview');
      code = next;
      facts.replaceChildren();
      for (const [term, value] of [['Code', formatCode(next)], ['Browser', seen.browser],
        ['Location', `${seen.city}, ${seen.country} (approximate)`], ['Requested', time(seen.requestedAt)], ['Expires', time(seen.expiresAt)]])
        facts.append(node('dt', term), node('dd', value));
      status.textContent = '';
      approve.disabled = false; cancel.disabled = false;
      dialog.showModal(); cancel.focus();
    } catch { if (!closed && current === generation) status.textContent = 'That computer code is unavailable or expired.'; }
    finally { if (current === generation || closed) { busy = false; review.disabled = false; } }
  });
  cancel.addEventListener('click', () => { reset(); dialog.close(); });
  dialog.addEventListener('cancel', () => reset());
  dialog.addEventListener('close', () => { if (!closed && review.isConnected) review.focus(); });
  approve.addEventListener('click', async () => {
    if (closed || busy || !code) return;
    const approvedCode = code, current = generation; busy = true; approve.disabled = true; cancel.disabled = true;
    try {
      const result = await accountRequest(auth, ['console-pairs', 'approve'], { method: 'POST', body: { code: approvedCode, sessionId } });
      if (closed || current !== generation) return;
      if (result?.approved !== true) throw new Error('approval_unavailable');
      reset(); input.value = ''; dialog.close();
      status.textContent = 'Computer approved. It now runs this room, and this console will stop controlling it.';
    } catch {
      if (!closed && current === generation) { dialog.close(); reset(); status.textContent = 'Approval failed, the code expired or the room ended. Ask the computer for a new code.'; }
    } finally { busy = false; approve.disabled = false; cancel.disabled = false; }
  });
  return { section, close() { closed = true; reset(); if (dialog.open) dialog.close(); dialog.remove(); section.remove(); } };
}

/** The display pairing code a facilitator types, approved over the room link (formerly console-display.mjs). */
export async function approveDisplayCode(link, rawCode) {
  const code = normalizeCode(rawCode, 8);
  if (!code) return { ok: false, error: 'bad_code' };
  try { return await link.approveDisplay(code); }
  catch { return { ok: false, error: 'unavailable' }; }
}
