import { connect, storedCredential } from './transport.mjs';
import { qrSvg } from './projector-qr.mjs';
import { markSvg, markFor } from './projector-marks.mjs';
import { avatarEl } from './avatar.mjs';
import { joinUrl, qrPayload, parseRoute, displayPairUrl } from '../shared/urls.mjs';
import { formatCode, isUuidV7 } from '../shared/ids.mjs';
import { cleanText } from '../shared/text.mjs';
import { timerRemainingS, timerWords, TIMER_ANNOUNCE_AT } from '../shared/timer.mjs';
import { keepScreenAwake } from './device.mjs';
import { acceptDisplayView, acceptLocalFrame, visiblePeople, cueForChange } from './projector-view.mjs';
import { newlyPublicGroup } from './presentation-emphasis.mjs';
import { renderResponseResult } from './projector-result.mjs';
import { arrivalFeedback } from './lobby-arrivals.mjs';
import { createRoomCuePlayer } from './room-cue-events.mjs';
import { CUE_URLS } from './audio-assets.mjs';
import { readVolume, writeVolume } from './room-volume.mjs';

export function mount() {
const route = parseRoute(location.pathname);
const credential = storedCredential('display');
const sessionId = route?.sessionId ?? credential?.sessionId;
const params = new URLSearchParams(location.search);
const topology = params.get('topology') === 'same-pc' ? 'same-pc' : 'separate';
const timeScale = Math.min(1, Math.max(.005, Number(params.get('scale')) || 1));
if (!sessionId || (topology === 'separate' && credential?.sessionId !== sessionId)) { location.replace(displayPairUrl('00000000', location.origin)); return; }
document.body.classList.add('projector');
document.querySelector('main')?.remove();
const root = document.createElement('div'); root.className = 'screen';
for (const [tag,id] of [['header','top'], ['main','main'], ['footer','foot']]) { const n = document.createElement(tag); n.id = id; if (tag === 'main') n.setAttribute('aria-label', 'Projector'); if (tag === 'header') n.className = 'top'; root.append(n); }
for (const id of ['announce', 'timerStatus']) { const n = document.createElement('div'); n.id = id; n.className = 'sr-only'; n.setAttribute('aria-live', 'polite'); document.body.append(n); }
document.body.prepend(root);
let roomArt = null, closed = false; // splash.mjs, lazy (card 36b)
keepScreenAwake();
let audio = null;
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
let volume = 1;
try { volume = readVolume(localStorage); } catch { /* storage blocked */ }
const volumeInput = document.createElement('input');
volumeInput.type = 'range'; volumeInput.className = 'volume'; volumeInput.min = '0'; volumeInput.max = '100'; volumeInput.step = '5';
volumeInput.value = Math.round(volume * 100); volumeInput.setAttribute('aria-label', 'Room sound volume');
volumeInput.addEventListener('input', () => { volume = Number(volumeInput.value) / 100; try { writeVolume(localStorage, volume); } catch { /* preference only */ } });
const cues = createRoomCuePlayer({ urls: CUE_URLS, enabled: () => soundOn, reduced: () => reduced.matches, hidden: () => document.hidden, getContext: () => audio, volume: () => volume });
const trackedFetch = async (...args) => { const response = await fetch(...args); if (response.ok) lastContact = Date.now(); return response; };
class ContactSocket extends WebSocket { constructor(...args) { super(...args); this.addEventListener('message', () => { lastContact = Date.now(); }); } }
const link = credential?.sessionId === sessionId ? connect({ role: 'display', api: location.origin, sessionId, timeScale, timings: { LONG_POLL_WAIT_S: Math.max(1, Math.round(10 * timeScale)) }, fetchImpl: trackedFetch, WebSocketImpl: ContactSocket }) : null;
// ── state ──
let server = null;          // latest server snapshot { epoch, revision, view }
let local = null;           // latest local_snapshot (same-PC manual mode) { epoch, revision, view }
let status = 'connecting';  // link status
let lastContact = Date.now();
let lostNotice = false;
let soundOn = false, presented = false;

let arrivalPrevious = null, arrivalIndices = [], arrivalTimer = null, arrivalOverflow = false;
const arrivalStatus = document.createElement('div');
arrivalStatus.className = 'arrival-status sr-only'; arrivalStatus.setAttribute('role', 'status');
arrivalStatus.setAttribute('aria-live', 'polite'); arrivalStatus.setAttribute('aria-atomic', 'true');
document.body.append(arrivalStatus);
function noteArrivals(view) {
  const cue = view ? arrivalFeedback(arrivalPrevious, view, { reducedMotion: reduced.matches }) : null;
  arrivalPrevious = view;
  if (view?.phase !== 'waiting') { arrivalStatus.textContent = ''; arrivalIndices = []; arrivalOverflow = false; clearTimeout(arrivalTimer); return; }
  arrivalStatus.dataset.arrivals = view.arrivalCount;
  if (!cue) return;
  arrivalStatus.textContent = `${cue.count} joined`;
  arrivalIndices = cue.indices; arrivalOverflow = cue.overflow > 0 && !reduced.matches; clearTimeout(arrivalTimer);
  arrivalTimer = setTimeout(() => { arrivalIndices = []; arrivalOverflow = false; render(); }, 1500);
}


const $ = (id) => document.getElementById(id);
function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = cleanText(text, 2000); return e; }
const SVGNS = 'http://www.w3.org/2000/svg';
const ICONS = {
  phone: 'M8 2.5h8a1.5 1.5 0 0 1 1.5 1.5v16a1.5 1.5 0 0 1-1.5 1.5H8A1.5 1.5 0 0 1 6.5 20V4A1.5 1.5 0 0 1 8 2.5zM11 18h2',
  lock: 'M6 11h12v9H6zM8.5 11V8a3.5 3.5 0 0 1 7 0v3',
  pause: 'M8 5v14M16 5v14',
  speech: 'M4 5h16v11H10l-5 4v-4H4z',
  rewind: 'M11 6l-7 6 7 6zM20 6l-7 6 7 6z',
  offline: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM5.6 5.6l12.8 12.8',
  arc: 'M12 3a9 9 0 1 0 9 9',
  clock: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7v5l3 2',
  people: 'M9 11a3.2 3.2 0 1 0 0-6.4A3.2 3.2 0 0 0 9 11zM3 20c0-3.5 2.7-6 6-6s6 2.5 6 6M16 5.3a3 3 0 0 1 0 5.4M18 14.5c1.8.8 3 2.6 3 5.5',
  sound: 'M4 9v6h4l5 4V5L8 9zM16.5 9a4 4 0 0 1 0 6',
  mute: 'M4 9v6h4l5 4V5L8 9zM17 9l4 6M21 9l-4 6',
};
function icon(name) {
  const s = document.createElementNS(SVGNS, 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'ic'); s.setAttribute('aria-hidden', 'true');
  const p = document.createElementNS(SVGNS, 'path'); p.setAttribute('d', ICONS[name]); s.append(p);
  return s;
}

// ── what to render: the server snapshot, or the console's local view (same PC, manual mode) ──
function current() {
  if (topology === 'same-pc' && local && local.epoch >= (server?.epoch ?? 0)) return { view: local.view, from: 'local' };
  return server ? { view: server.view, from: 'server' } : { view: null, from: 'none' };
}

// Cues follow the selected public view, never an inactive transport source.
// Once this projector has presented material, leaving the join screen restores it silently.
function changed(previous) {
  const view = current().view;
  const cue = cueForChange(previous, view, presented);
  if (cue || previous?.phase !== view.phase || view.replay || view.manual || previous?.decision?.decisionId !== view.decision?.decisionId || previous?.surface?.surfaceId !== view.surface?.surfaceId) cues.cancel();
  noteArrivals(view); void cues.play(cue);
  presented ||= view.phase !== 'waiting';
  render();
}

link?.on('snapshot', (snap) => {
  if (!acceptDisplayView(snap.view) || snap.view.sessionId !== sessionId) return;
  const previous = current().view;
  server = snap; lastContact = Date.now();
  if (local && snap.epoch > local.epoch) local = null;
  changed(previous);
});
link?.on('status', (s) => { status = s; render(); });
link?.on('error', error => {
  if (error === 'unauthorised' || error === 'unknown_room') {
    link.forget(); cleanup(); location.replace(displayPairUrl('00000000', location.origin));
  }
});
let lc = null; let hello = null;
if (topology === 'same-pc') {
  lc = new BroadcastChannel('case-room-local');
  const say = () => lc.postMessage({ t: 'projector_hello', sessionId });
  say(); hello = setInterval(say, Math.max(10, 4000 * timeScale));
  lc.onmessage = ({ data: frame }) => {
    if (frame?.t === 'mute_projector') {
      if (Object.keys(frame).length === 3 && frame.sessionId === sessionId && isUuidV7(frame.requestId)) {
        cues.cancel(); soundOn = false; render();
        lc.postMessage({ t: 'projector_muted', sessionId, requestId: frame.requestId });
      }
      return;
    }
    const accepted = acceptLocalFrame(frame, sessionId, local);
    if (accepted) { const previous = current().view; local = accepted; changed(previous); }
    else if (frame?.t === 'local_end' && frame.sessionId === sessionId && Object.keys(frame).length === 2) { cues.cancel(); if (local?.view.phase !== 'ended') local = null; render(); }
    else if (frame?.t === 'show_projector' && frame.sessionId === sessionId && Object.keys(frame).length === 2) showProjectorWord();
  };
}
// The display check: the word `Projector` fills this screen for a moment, so the facilitator can
// see which physical screen is the projector (and that the console is not duplicated onto it).
function showProjectorWord() {
  let o = document.getElementById('projectorCheck');
  if (!o) {
    o = document.createElement('div');
    o.id = 'projectorCheck';
    o.setAttribute('role', 'status');

    o.textContent = 'Projector';
    document.body.append(o);
  }
  o.hidden = false;
  clearTimeout(showProjectorWord.t);
  showProjectorWord.t = setTimeout(() => { o.hidden = true; }, 6000 * timeScale);
}

const clock = setInterval(() => {
  if (topology === 'separate') {
    const stale = Date.now() - lastContact > 15000 * timeScale;
    if (stale !== lostNotice) { lostNotice = stale; render(); }
  }
  tickTimer();
}, Math.max(10, 500 * timeScale));

// ── advisory timer: text only, announced politely at 60 s, 10 s and 0 only. ONE rounding with the
// console and the phones (src/shared/timer.mjs; walkthrough bug 3). ──
let timerKey = null; const announced = new Set();
function tickTimer() {
  const { view } = current();
  const line = document.getElementById('timerLine');
  if (!line || !view?.timer) return;
  const rem = timerRemainingS(view.timer);
  const txt = timerWords(rem);
  if (line.textContent !== txt) line.textContent = txt;
  const key = view.timer.endsAt ?? `p${view.timer.remainingS}`;
  if (key !== timerKey) { timerKey = key; announced.clear(); }
  for (const mark of [...TIMER_ANNOUNCE_AT].reverse()) {
    if (rem <= mark && !announced.has(mark)) {
      announced.add(mark);
      if (mark === 60 && (announced.has(10) || announced.has(0))) continue;
      $('timerStatus').textContent = timerWords(mark);
      break;
    }
  }
}

// ── phase state (CASE-114): one accent on the pill; the label is short, the call to action sits in the
// decision column. A consequence is a revealed route's surface. ──
function phaseOf(view) {
  if (!view) return null;
  switch (view.phase) {
    case 'waiting': return null;
    case 'decision_open': return view.manual ? ['locked', 'Facilitator-led'] : ['open', 'Decision open'];
    case 'reviewing': return ['locked', view.manual ? 'Facilitator-led' : 'Responses locked'];
    case 'paused': return ['paused', 'Discussion pause'];
    case 'teaching': return ['consequence', 'Teaching point'];
    case 'ended': return ['reveal', 'Session ended'];
    default: return ['consequence', 'terminal'].includes(view.surface?.timelineKind) ? ['consequence', 'Consequence'] : ['reveal', 'Revealed'];
  }
}

// ── top row ──
function layer(cls, ic, text) { const b = el('span', `layer ${cls}`); b.append(icon(ic), el('span', null, text)); return b; }
function renderTop(view, from) {
  const title = el('div', 'title');
  title.append(el('p', 'eyebrow', 'Case'));
  if (view?.caseTitle && view.phase !== 'waiting') title.append(el('p', 'case', view.caseTitle));
  // Room status: the phase pill and the layers (manual, replay, lost), icon plus text, never colour alone.
  const box = el('section'); box.id = 'banners'; box.setAttribute('aria-label', 'Room status');
  const ph = phaseOf(view);
  if (ph) { const p = el('span', 'pill', ph[1]); p.dataset.phase = ph[0]; box.append(p); }
  if (topology === 'separate' && lostNotice) box.append(layer('lost', 'offline', 'Connection lost · follow the facilitator'));
  if (view?.replay) box.append(layer('replay', 'rewind', 'Presentation replay · phones remain on live surface'));
  if (view?.manual) box.append(layer('manual', 'speech', 'Manual room mode · facilitator-led discussion'));
  const meta = el('div', 'meta');
  if (view?.phase === 'decision_open' && !view.manual && view.names === null) {
    const n = view.counts.responded;
    if (n !== null) { const c = el('span', 'count'); c.append(icon('people'), el('span', 'num', `${n} of ${view.counts.present}`), ' answered'); meta.append(c); }
    if (view.timer) { const t = el('span', 'timer'); const w = el('span', null, timerWords(timerRemainingS(view.timer))); w.id = 'timerLine'; t.append(icon('clock'), w); meta.append(t); }
  }
  // Connection state (SCREENS.md Connection states): nothing while live; a same-PC window following the
  // console locally has the console as its authority, so no indicator either.
  if (from !== 'local' && (status === 'connecting' || status === 'lost')) { const c = el('span', 'conn'); c.append(icon('arc'), status === 'lost' ? 'Reconnecting…' : 'Connecting…'); meta.append(c); }
  $('top').replaceChildren(title, box, meta);
}

// ── information column ──
/** The vitals strip: label, value, unit, trend arrow and the earlier value (CASE-090). */
function renderVitals(obs) {
  if (!obs?.length) return null;
  const ul = el('ul', 'vitals');
  ul.setAttribute('aria-label', 'Vitals');
  for (const o of obs) {
    const li = el('li');
    const value = o.value;
    const say = `${o.label} ${value}${o.unit ? ' ' + o.unit : ''}${o.trend ? `, ${o.trend} from ${o.previous}` : ''}`;
    li.append(el('span', 'sr-only', say));
    const row = el('span', 'vrow'); row.setAttribute('aria-hidden', 'true');
    row.append(el('span', 'vv', value));
    if (o.unit) row.append(el('span', 'vu', o.unit));
    const lbl = el('span', 'vl', o.label); lbl.setAttribute('aria-hidden', 'true');
    li.append(lbl, row);
    if (o.trend) { const a = el('span', 'va', `${o.trend === 'up' ? '↑' : '↓'} ${o.previous}`); a.setAttribute('aria-hidden', 'true'); li.append(a); } // earlier value (CASE-090)
    ul.append(li);
  }
  return ul;
}
function listTile(cls, title, items) {
  if (!items?.length) return null;
  const box = el('section', `card find ${cls}`);
  box.setAttribute('aria-label', title);
  box.append(el('p', 'eyebrow', title));
  const ul = el('ul');
  for (const t of items) ul.append(el('li', null, t));
  box.append(ul);
  return box;
}
function sceneCard(s) {
  const card = el('section', 'card scene');
  card.setAttribute('aria-label', 'Live surface');
  card.dataset.kind = s.timelineKind;
  card.append(el('h1', null, s.title));
  if (s.scene) card.append(el('p', 'prose', s.scene));
  return card;
}
function findingsTiles(s, { investigations = true } = {}) {
  const f = listTile('findings', 'Findings', s.points);
  const i = investigations ? listTile('investigations', 'Investigations', s.investigations) : null;
  if (!f && !i) return null;
  const wrap = el('div', 'tiles2');
  if (f) wrap.append(f);
  if (i) wrap.append(i);
  return wrap;
}

/** The options as stacked tiles in the one authored order, each with its shape + colour mark and full text. */
function renderTiles(decision) {
  const opts = decision.interaction.options;
  if (!opts.length) return null; // free text: the prompt only
  const ol = el('ol', 'tiles');
  ol.setAttribute('aria-label', 'Options');
  opts.forEach((o, i) => {
    const m = markFor(i);
    const li = el('li', 'tile opt-tile' + (o.explored || o.disabled ? ' dim' : ''));
    li.style.setProperty('--mk', m.fill);
    li.append(markSvg(i, { size: 72, decorative: false }), el('span', 'lbl', o.label));
    if (o.explored) li.append(el('span', 'tag', 'Explored'));
    ol.append(li);
  });
  return ol;
}
function decisionColumn(view) {
  const d = view.decision;
  const box = el('section', 'card decision');
  box.setAttribute('aria-label', 'Team decision');
  box.dataset.phase = phaseOf(view)[0];
  const call = el('p', 'call');
  if (view.manual) call.append(icon('speech'), 'Facilitator-led discussion');
  else if (view.phase === 'decision_open') call.append(icon('phone'), 'Team decision open · Choose on your phone');
  else if (view.phase === 'reviewing') call.append(icon('lock'), 'Responses locked · Facilitator reviewing');
  else if (view.phase === 'paused') call.append(icon('pause'), 'Paused · answers are held');
  box.append(call, el('h2', null, d.prompt));
  const t = renderTiles(d);
  if (t) box.append(t);
  return box;
}


function renderLobby(view) {
  const panel = el('section', 'card joinpanel');
  panel.setAttribute('aria-label', 'Join');
  if (topology === 'same-pc') panel.append(el('p', 'check', 'Projector'));
  panel.append(el('p', 'status-line', `${view.counts.participants} in the room`), el('h1', null, view.caseTitle));
  if (view.joiningClosed) { panel.append(el('h2', null, 'Joining is closed')); return panel; }
  const url = joinUrl(view.joinCode, location.origin);
  const q = el('div', 'qrcard'); q.append(qrSvg(qrPayload(url), { margin: 4 }));
  q.firstChild.setAttribute('aria-label', `QR code for ${url.replace('https://', '')}`);
  panel.append(q, el('h2', null, 'Join the case'), el('div', 'url', url.replace(/^https:\/\//, '')), el('div', 'code-label', 'Room code'), el('div', 'code', formatCode(view.joinCode)));
  return panel;
}
/**
 * Lay the main grid out (CASE-113). `place` says where the findings and investigations tiles go:
 * 'right' (no decision open: the right column carries them), 'left' (under the vitals) or 'none'
 * (only for a surface without an open decision). An open decision keeps Findings (CASE-134).
 */
function renderMain(view, layout) {
  const { vitals: vPlace = 'left', tiles: place = 'right', investigations = true } = layout;
  const main = $('main');
  main.className = '';
  if (!view) { main.className = 'single'; main.replaceChildren(el('h1', 'waiting-note', 'Waiting for the room…')); return; } // every state has a level-one heading (axe)
  if (view.phase === 'waiting') { main.className = 'single splash-main'; main.replaceChildren(renderLobby(view)); return; }
  if (view.phase === 'ended') {
    const end = el('section', 'card endcard');
    end.append(el('h2', null, 'Session ended'), el('p', null, 'Thank you · your private recap is on your phone for 24 hours'));
    main.className = 'single splash-main'; main.replaceChildren(el('h1', 'sr-only', view.caseTitle), end); return;
  }
  if (view.responseResult?.type === 'ranking' && !view.replay) {
    const column = el('div', 'col'); column.append(el('h1', 'sr-only', view.caseTitle), renderResponseResult(view, { el, markSvg }));
    main.className = 'single'; main.replaceChildren(column); return;
  }
  const s = view.surface;
  const left = el('div', 'col');
  const right = el('div', 'col');
  if (s) left.append(sceneCard(s));
  else left.append(el('h1', 'sr-only', view.caseTitle));
  const vit = s ? renderVitals(s.observations) : null;
  if (vit && vPlace === 'left') left.append(vit);
  const tiles = s ? findingsTiles(s, { investigations }) : null;
  if (view.responseResult) right.append(renderResponseResult(view, { el, markSvg }));
  else if (view.decision) right.append(decisionColumn(view));
  if (vit && vPlace === 'right') right.append(vit);
  if (tiles && place === 'right') right.append(tiles);
  if (tiles && place === 'left') left.append(tiles);
  if (!right.childElementCount) { main.className = 'single'; main.replaceChildren(left); return; }
  main.replaceChildren(left, right);
}
/** Where the vitals and the tiles go, in order of preference, for this view. */
function placements(view) {
  if (!view || view.phase === 'waiting') return [{}];
  if (view.decision && view.phase !== 'ended') return innerWidth >= 1920 ? [{ tiles: 'left' }] : [{ tiles: 'left' }, { tiles: 'left', investigations: false }];
  return [{ tiles: 'right' }, { tiles: 'left' }, { vitals: 'right', tiles: 'right' }, { vitals: 'right', tiles: 'left' }, ...(innerWidth >= 1920 ? [] : [{ vitals: 'right', tiles: 'none' }, { tiles: 'none' }])];
}

// ── bottom row ──
function renderFooter(view) {
  const kids = [];
  const joinable = view && !view.joiningClosed && view.phase !== 'ended' && view.phase !== 'waiting';
  if (joinable) {
    const url = joinUrl(view.joinCode, location.origin);
    const q = el('div', 'qrcell'); q.append(qrSvg(qrPayload(url), { margin: 4 }));
    q.firstChild.setAttribute('aria-label', `QR code for ${url.replace('https://', '')}`);
    const route = el('div', 'route');
    const code = el('div', 'code'); code.append(el('span', 'k', 'Code'), el('b', null, formatCode(view.joinCode)));
    route.append(el('div', 'url', url.replace(/^https:\/\//, '')), code);
    kids.push(q, route);
  } else if (view && view.joiningClosed && view.phase !== 'ended') kids.push(el('span', 'closed', 'Joining is closed'));
  else kids.push(el('span'));
  $('foot').className = joinable ? '' : 'noroute';
  kids.push(renderNames(view));
  const snd = el('button', 'sound'); snd.type = 'button';
  snd.setAttribute('aria-pressed', soundOn);
  snd.setAttribute('aria-label', 'Room sound');
  snd.append(icon(soundOn ? 'sound' : 'mute'));
  snd.onclick = async () => { cues.cancel(); if (soundOn) soundOn = false; else { audio ??= new AudioContext(); await audio.resume(); soundOn = audio.state === 'running'; } render(); };
  const cell = el('div', 'sound-cell'); cell.append(snd, volumeInput);
  kids.push(cell);
  $('foot').replaceChildren(...kids);
}

/** `In the room`: avatar-only chips until Show names, then avatar + name (CASE-133). */
function renderNames(view) {
  const box = el('section', 'names');
  if (!view) return box;
  box.setAttribute('aria-labelledby', 'namesH');
  const hd = el('h2', null, 'In the room'); hd.id = 'namesH';
  box.append(hd);
  const ul = el('ul');
  const showingNames = view.names !== null;
  const { people: avatars, more } = visiblePeople(view);
  for (const [index, n] of avatars.entries()) {
    const li = el('li', `chip${showingNames ? '' : ' anonymous'}`);
    if (view.phase === 'waiting' && arrivalIndices.includes(index)) li.classList.add('arrival-new');
    if (!showingNames) li.setAttribute('aria-label', 'Participant');
    li.append(avatarEl(n.avatarId, { size: 32, name: showingNames ? n.name : '' }));
    if (showingNames) li.append(el('span', 'nm', n.name));
    ul.append(li);
  }
  ul.dataset.unnamed = more;
  box.append(ul);
  if (view.phase === 'waiting' && arrivalStatus.textContent) box.append(el('span', `arrival-note${arrivalOverflow ? ' arrival-new' : ''}`, arrivalStatus.textContent));
  return box;
}
/** Chips that do not fit on the one line become `+N`; the hidden names stay out of the page (no title). */
function fitNames() {
  const ul = $('foot').querySelector('.names ul');
  if (!ul) return;
  const chips = [...ul.children];
  const extra = +ul.dataset.unnamed;
  const more = el('li', 'chip more');
  const place = (n) => { more.textContent = `+ ${n} more`; more.setAttribute('aria-label', `and ${n} more`); if (!more.isConnected) ul.append(more); };
  if (extra) place(extra);
  let hiddenN = 0;
  for (let i = chips.length - 1; i >= 0 && ul.scrollWidth > ul.clientWidth + 1; i--) {
    if (chips[i].classList.contains('arrival-new')) $('foot').querySelector('.arrival-note')?.classList.add('arrival-new');
    chips[i].remove(); hiddenN += 1; place(hiddenN + extra);
  }
}

// Fit at any size without scrolling. During a decision, Findings shrink first to an 18px floor;
// spacing and other type follow, then Investigations yield and Findings truncate with a count.
function fit(view) {
  const m = $('main');
  const ok = () => [...m.querySelectorAll('.col')].every((c) => c.scrollHeight <= c.clientHeight + 1) && m.scrollWidth <= m.clientWidth + 1;
  const set = (s, sp, findSize) => { document.documentElement.style.setProperty('--s', s); m.style.setProperty('--s', s); m.style.setProperty('--sp', sp); m.style.setProperty('--p-find', `${findSize}px`); };
  const decision = Boolean(view?.decision && view.phase !== 'ended');
  const stages = [];
  const findingsFloor = innerWidth >= 1920 ? 24 : 18;
  if (decision) for (const f of (innerWidth >= 1920 ? [24] : [24, 22, 20, 18])) stages.push([1, 1, f]);
  for (const sp of [1, .8, .6, .45]) stages.push([1, sp, decision ? findingsFloor : 24]);
  for (const s of [.94, .88, .82, .76, .7]) stages.push([s, .45, decision ? findingsFloor : 24]);
  for (const sp of [.3, .15, 0]) stages.push([.7, sp, decision ? findingsFloor : 24]);
  const run = () => { for (const st of stages) { set(...st); if (ok()) return true; } return false; };
  const order = placements(view);
  const spill = () => Math.max(0, ...[...m.querySelectorAll('.col')].map((c) => c.scrollHeight - c.clientHeight));
  let fitted = false, best = null;
  for (const [i, layout] of order.entries()) {
    if (i) renderMain(view, layout);
    if ((fitted = run())) break;
    if (!best || spill() < best.spill) best = { layout, spill: spill() };
  }
  if (!fitted && best && best.layout !== order.at(-1)) { renderMain(view, best.layout); run(); }
  if (!fitted && decision && innerWidth < 1920) {
    const list = m.querySelector('.findings ul');
    if (list) {
      const items = [...list.children];
      const more = el('li', 'more');
      list.append(more);
      for (let n = 1; n <= items.length; n++) {
        items[items.length - n].hidden = true;
        more.textContent = `+${n} more on your phone`;
        if (ok()) { fitted = true; break; }
      }
    }
  }
  m.dataset.overflow = !fitted; // lab check: text never scrolls
}
window.addEventListener('resize', render);

let lastKey = null, lastPresented = null;
function announceIfChanged(view, group) {
  const surface = view?.surface;
  const groupSignature = surface ? JSON.stringify([surface.scene, surface.observations, surface.points, surface.investigations]) : '';
  const key = view ? [view.phase, view.joiningClosed, view.surface?.surfaceId, groupSignature, view.manual, view.replay, view.decision?.prompt, view.decision?.status, !!view.lastResult].join('|') : 'none';
  if (key === lastKey) return;
  lastKey = key;
  if (!view) return;
  const say = view.phase === 'waiting' ? `${view.caseTitle}. ${view.joiningClosed ? 'Joining is closed' : 'Join the case'}`
    : view.phase === 'decision_open' ? 'Team decision open. Choose on your phone'
    : view.phase === 'reviewing' ? (view.manual ? 'Manual room mode. Facilitator-led discussion' : 'Responses locked. Facilitator reviewing')
    : view.phase === 'paused' ? 'Discussion pause'
    : view.phase === 'ended' ? 'Session ended'
    : `${view.surface?.title ?? ''}`;
  $('announce').textContent = group ? `New ${group} shared. ${say}` : say;
}

function render() {
  const hadFocus = ['sound', 'volume'].find(name => document.activeElement?.classList?.contains(name));
  const { view, from } = current();
  const accentGroup = view && !view.replay ? newlyPublicGroup(lastPresented, view.surface) : null;
  lastPresented = view?.replay ? null : view?.surface ?? null;
  renderTop(view, from);
  renderMain(view, placements(view)[0]);
  if (roomArt?.projectorArt) roomArt.projectorArt(root, view); else roomArt ||= import('./splash.mjs').then(m => { roomArt = m; if (!closed) render(); }, () => { roomArt = {}; });
  renderFooter(view);
  announceIfChanged(view, accentGroup);
  fit(view);
  const accentSelector = { scene: '.scene', observations: '.vitals', findings: '.findings', investigations: '.investigations' }[accentGroup];
  if (accentSelector) $('main').querySelector(accentSelector)?.classList.add('presentation-new-group');
  fitNames();
  if (hadFocus) $('foot').querySelector(`.${hadFocus}`)?.focus();
  document.title = 'Case projector';
  document.documentElement.dataset.topology = topology;
  document.documentElement.dataset.source = from;
}
render();

function cleanup() { cues.cancel(); closed = true; roomArt?.projectorArt?.(root, null); clearTimeout(arrivalTimer); arrivalStatus.remove(); clearInterval(clock); clearInterval(hello); clearTimeout(showProjectorWord.t); lc?.close(); link?.close(); audio?.close(); lastPresented = null; window.removeEventListener('resize', render); }
window.addEventListener('pagehide', cleanup, { once: true });
return { close: cleanup };
}
