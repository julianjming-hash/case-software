// Participant-only next-load recovery. No transport or private draft is exposed here.
import { readParticipantRecovery, recoverJoinCapability } from './phone-recovery.mjs';
export function createPhoneBootstrap({code=null,sessionId=null,credential,knownInventory,
  readRecovery=readParticipantRecovery,preflight=recoverJoinCapability,cleanup}) {
  let selection=false,count=0,refused=false,terminal=null,started=false,flight=null,disposed=false;
  const denied=()=>({status:'refused',count:0});
  const gone=()=>({status:'disposed',count:0});
  // Drop the parsed capability binding; never mutate its persisted record.
  const release=()=>{credential=null;};
  async function reject() {
    if(disposed)return gone();
    refused=true;selection=false;count=0;release();
    try{terminal=(await cleanup('token_loss',false))?.complete?denied():{status:'storage_unavailable',count:0};return disposed?gone():terminal;}
    catch{terminal={status:'storage_unavailable',count:0};return disposed?gone():terminal;}
  }
  async function recover() {
    if(disposed)return gone();
    if(terminal)return terminal;
    if(refused)return denied();
    if(code){
      const result=await preflight({code,credential});
      if(disposed)return gone();
      if(result.status==='unavailable')return {status:'unavailable',count};
      if(result.status!=='recovered'||result.sessionId!==credential.sessionId)return reject();
    }
    terminal={status:'ready',count,sessionId:credential.sessionId};release();return terminal;
  }
  async function start() {
    if(disposed)return gone();
    if(started)return recover();started=true;
    if(!credential||knownInventory!==true||sessionId&&sessionId!==credential.sessionId)return reject();
    const validated=await readRecovery({role:'participant',sessionId:credential.sessionId,credential,knownInventory});
    if(disposed)return gone();
    if(!validated.preserve)return reject();
    selection=true;count=validated.count;
    const cleaned=await cleanup('next_load',selection);
    if(disposed)return gone();
    if(!cleaned?.complete)return reject();
    return recover();
  }
  const run=fn=>{if(!flight)flight=Promise.resolve().then(fn).catch(()=>disposed?gone():reject()).finally(()=>{flight=null;});return flight;};
  return {start:()=>run(start),retry:()=>run(()=>started?recover():start()),release,
    dispose(){disposed=true;release();selection=false;count=0;terminal=null;}};
}
