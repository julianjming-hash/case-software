// Device-local room authority during an outage. Only the event segment enters
// sessionStorage; the case pack and mirror stay in memory. Spoken marker text
// remains in that bounded tab segment for local notes, never in an upload.
import { uuidv7, isUuidV7 } from '../shared/ids.mjs';
import { dispatch, project } from '../shared/room-machine.mjs';
import { WIRE_VERSION, parseCommandEnvelope, parseManualCommandEnvelope, buildEvent } from '../shared/wire.mjs';
import { cleanText } from '../shared/text.mjs';
import { publishProjectorFrame } from './console-projection.mjs';

const MAX_SAVED_BYTES = 256_000;
const MAX_EVENTS = 500;
const keyFor = sessionId => `case-lab:segment:${sessionId}`;
const utf8Bytes = text => new TextEncoder().encode(text).byteLength;

export class ConsoleManualRoom {
  constructor(mirror, caseDoc, options = {}) {
    const { storage = sessionStorage, channel = new BroadcastChannel('case-room-local'),
      segmentId = uuidv7() } = options;
    this.state = { ...structuredClone(mirror), caseDoc };
    this.storage = storage;
    this.channel = channel;
    this.ownsChannel = !Object.hasOwn(options, 'channel');
    this.segmentId = segmentId;
    this.storageKey = keyFor(mirror.sessionId);
    this.epoch = mirror.epoch;
    this.events = [];
    this.markers = [];
    this.ledger = new Map();
    this.persistenceOk = null;
  }

  static saved(sessionId, storage = sessionStorage) {
    if (!isUuidV7(sessionId)) return null;
    try {
      const raw = storage.getItem(keyFor(sessionId));
      if (!raw || utf8Bytes(raw) > MAX_SAVED_BYTES) return null;
      const saved = JSON.parse(raw);
      if (!isUuidV7(saved?.segmentId) || !Number.isSafeInteger(saved.epoch) ||
          !Array.isArray(saved.events) || saved.events.length > MAX_EVENTS ||
          !Array.isArray(saved.markers) || saved.markers.length > MAX_EVENTS) return null;
      if (Object.keys(saved).sort().join(',') !== 'epoch,events,markers,segmentId') return null;
      if (!saved.markers.every(marker => marker && typeof marker.at === 'string' &&
          marker.at.length <= 40 && Number.isFinite(Date.parse(marker.at)) &&
          typeof marker.text === 'string' && marker.text.length <= 200 &&
          marker.text === cleanText(marker.text, 200) &&
          Object.keys(marker).sort().join(',') === 'at,text')) return null;
      if (!saved.events.every(event => event && typeof event.at === 'string' &&
          event.at.length <= 40 && Number.isFinite(Date.parse(event.at)) &&
          (() => { const { at, ...envelope } = event;
            return parseManualCommandEnvelope(envelope).ok &&
              (event.type !== 'manual_marker' || event.text === cleanText(event.text, 200)); })())) return null;
      return saved;
    } catch { return null; }
  }

  static restore(mirror, caseDoc, saved, options = {}) {
    if (!saved || saved.epoch !== mirror.epoch || !isUuidV7(saved.segmentId) ||
        !Array.isArray(saved.events) || saved.events.length > MAX_EVENTS ||
        !Array.isArray(saved.markers) || saved.markers.length > MAX_EVENTS) return null;
    const manual = new ConsoleManualRoom(mirror, caseDoc,
      { ...options, segmentId: saved.segmentId });
    for (const event of saved.events) {
      const { at, ...envelope } = event;
      if (typeof at !== 'string' || manual.#apply(envelope, at, true).receipt !== 'accepted') {
        manual.close(); manual.forget(); return null;
      }
    }
    manual.markers = saved.markers;
    manual.persistenceOk = manual.save();
    return manual;
  }

  enter() { return this.command('enter_manual', { segmentId: this.segmentId }); }

  command(type, payload = {}) {
    if (this.events.length >= MAX_EVENTS) return { receipt: 'rejected', reason: 'segment_full' };
    if (type === 'manual_marker') {
      if (typeof payload.text !== 'string' || payload.text.length > 200)
        return { receipt: 'rejected', reason: 'bad_text' };
      payload = { ...payload, text: cleanText(payload.text, 200) };
    }
    const envelope = { v: WIRE_VERSION, type, epoch: this.state.epoch,
      clientEventId: uuidv7(), ...payload };
    const receipt = this.#apply(envelope, new Date().toISOString());
    if (receipt.receipt === 'accepted') {
      if (type === 'manual_marker') this.markers.push({ at: this.events.at(-1).at,
        text: payload.text });
      this.persistenceOk = this.save();
    }
    return receipt;
  }

  #apply(envelope, at, restoring = false) {
    const parsed = restoring ? parseManualCommandEnvelope(envelope) : parseCommandEnvelope(envelope, 'facilitator');
    if (!parsed.ok) return { receipt: 'rejected', reason: parsed.error };
    const event = buildEvent(parsed.envelope,
      { actor: { role: 'facilitator', id: 'facilitator' }, at, newId: uuidv7 });
    if (restoring && event.type === 'ranked_page' && this.state.manual) event.expectRevision = this.state.revision;
    const result = dispatch(this.state, event, this.ledger);
    const receipt = result.effects.find(effect => effect.type === 'receipt') ??
      { receipt: 'accepted' };
    if (receipt.receipt === 'accepted') {
      this.state = result.state;
      const recorded = { ...envelope };
      if (recorded.type === 'ranked_page') delete recorded.expectRevision;
      this.events.push({ ...recorded, at });
      this.publish();
    }
    return receipt;
  }

  save() {
    const raw = JSON.stringify({ epoch: this.epoch, segmentId: this.segmentId,
      events: this.events, markers: this.markers });
    if (utf8Bytes(raw) > MAX_SAVED_BYTES) return false;
    try { this.storage.setItem(this.storageKey, raw); return true; }
    catch { return false; }
  }

  forget() { try { this.storage.removeItem(this.storageKey); } catch { /* private mode */ } }
  view() { return project(this.state, 'facilitator'); }
  publish() {
    const frame = { t: 'local_snapshot', epoch: this.state.epoch,
      revision: this.state.revision, displayRevision: this.state.display.revision,
      view: project(this.state, 'display') };
    publishProjectorFrame(this.channel, frame, this.state.sessionId);
  }
  segmentBody() {
    return { v: WIRE_VERSION, segmentId: this.segmentId,
      events: this.events.map(event => event.type === 'manual_marker' ?
        { ...event, text: '' } : event) };
  }
  notesText() {
    const paths = new Map(this.state.caseDoc.decisions.flatMap(decision =>
      decision.paths.map(path => [path.id, path.label])));
    const lines = [`Case: ${this.state.caseDoc.title}`,
      `Manual room segment ${this.segmentId}`, ''];
    for (const event of this.events) {
      if (event.type === 'select_path') lines.push(`${event.at}  Route chosen: ${paths.get(event.pathId) ?? event.pathId}`);
      if (event.type === 'reveal') lines.push(`${event.at}  Revealed to the room`);
    }
    for (const marker of this.markers) lines.push(`${marker.at}  Marker: ${marker.text}`);
    return lines.join('\n') + '\n';
  }
  static notesFromSaved(saved) {
    if (!saved || !isUuidV7(saved.segmentId) || !Array.isArray(saved.events) ||
        !Array.isArray(saved.markers)) return '';
    const lines = [`Manual room segment ${saved.segmentId}`,
      'Saved on this device after a reload. Room and route names return only after you reconnect.', ''];
    for (const event of saved.events) {
      if (event.type === 'select_path') lines.push(`${event.at}  Route chosen (${event.pathId})`);
      if (event.type === 'reveal') lines.push(`${event.at}  Revealed to the room`);
    }
    for (const marker of saved.markers)
      lines.push(`${marker.at}  Marker: ${cleanText(marker.text, 200)}`);
    return lines.join('\n') + '\n';
  }
  close() {
    this.channel.postMessage({ t: 'local_end', sessionId: this.state.sessionId });
    if (this.ownsChannel) this.channel.close();
  }
}

/** Exactly one validated tab segment may pass a navigation boundary. */
export function savedManualKey(storage = null) {
  try {
    storage ??= globalThis.sessionStorage;
    let found = null;
    for (let i = 0; i < storage.length; i++) {
      const key = storage.key(i);
      if (!key?.startsWith('case-lab:segment:')) continue;
      const sessionId = key.slice('case-lab:segment:'.length);
      if (found || !isUuidV7(sessionId) || !ConsoleManualRoom.saved(sessionId, storage)) return null;
      found = key;
    }
    return found;
  } catch { return null; }
}
