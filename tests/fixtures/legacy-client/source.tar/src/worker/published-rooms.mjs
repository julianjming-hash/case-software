// Published-room orchestration. Dependencies are supplied by the Worker so tests
// can prove the entire failure path without Supabase, a deployed origin or a DO.
import { validateCaseDocument } from '../shared/case-document.mjs';
import { sanitizeArt } from '../shared/art-descriptor.mjs';
import { tintOf } from '../shared/tints.mjs';
import { ACTIONS } from '../shared/permissions.mjs';
import { authorize, adminArgs, emailDigest } from './authorize.mjs';

const fail = (error, status) => ({ ok: false, error, status });
const safeAlert = (hook, event) => {
  if (typeof hook !== 'function') return;
  try { void Promise.resolve(hook(Object.freeze(event))).catch(() => {}); }
  catch { /* alert transport cannot replace an HTTP result */ }
};

export function rpcFailure(name, result, onAlert) {
  if (result?.code === '42501' || result?.code === 'PGRST202') {
    safeAlert(onAlert, { kind: 'rpc_forbidden', name });
    return fail('internal_error', 500);
  }
  if (result?.kind === 'unavailable') return fail('unavailable', 503);
  if (result?.kind === 'conflict') return fail('conflict', 409);
  if (result?.kind === 'unique') return fail('conflict', 409);
  if (result?.kind === 'not_found') return fail('not_found', 404);
  return fail('bad_request', 400);
}

/** get_me for the verified caller. `admin` is adminArgs(actor) from the core; nothing else sets it. */
export async function readMe(rpc, userId, { limit = 100, after = null, workspaceId = null,
  admin = adminArgs(null) } = {}, onAlert) {
  const result = await rpc.call('get_me', {
    p_user_id: userId, p_limit: limit, p_after: after, p_workspace_id: workspaceId, ...admin,
  });
  if (!result?.ok) return rpcFailure('get_me', result, onAlert);
  const rows = Array.isArray(result.data) ? result.data : [];
  const [row] = rows;
  if (rows.length !== 1 || row?.user_id !== userId || !Array.isArray(row.memberships) ||
      row.admin !== admin.p_admin ||
      (row.next_after !== null && typeof row.next_after !== 'string') ||
      (row.display_name !== null && typeof row.display_name !== 'string')) return fail('unavailable', 503);
  return { ok: true, profile: { userId, displayName: row.display_name },
    memberships: row.memberships, nextAfter: row.next_after, admin: row.admin };
}

export async function readIntactVersion(rpc, actor, workspaceId, versionId, onAlert) {
  const result = await rpc.call('get_case_version_for_workspace', {
    p_version_id: versionId, p_workspace_id: workspaceId, p_user_id: actor.userId, ...adminArgs(actor),
  });
  if (!result?.ok) return rpcFailure('get_case_version_for_workspace', result, onAlert);
  if (!Array.isArray(result.data) || result.data.length > 1) return fail('unavailable', 503);
  if (!result.data.length) return fail('not_found', 404);
  const row = result.data[0];
  const text = row?.document_text;
  const hash = row?.content_sha256;
  const integrity = () => { safeAlert(onAlert, { kind: 'case_version_integrity' }); return fail('case_version_integrity', 502); };
  if (typeof text !== 'string' || typeof hash !== 'string' || !/^\\x[0-9a-f]{64}$/i.test(hash)) return integrity();
  const bytes = new TextEncoder().encode(text);
  if (bytes.length > 1_048_576) return integrity();
  const digest = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)), byte => byte.toString(16).padStart(2, '0')).join('');
  if (digest !== hash.slice(2).toLowerCase()) return integrity();
  let document;
  try { document = JSON.parse(text); } catch { return integrity(); }
  if (!validateCaseDocument(document).ok || document.schema_version !== row.schema_version) return integrity();
  // The version's stored art descriptor (CASE-164); anything but the exact numbers-only shape is dropped.
  // The case's current group tint (card 30): one of ten names, else neutral; the room freezes it at start.
  return { ok: true, document, versionNo: row.version_no, art: sanitizeArt(row.art), tint: tintOf(row.tint) };
}

async function compensate({ rpc, directory, room, code, sessionId, endDb, abortRoom, onAlert }) {
  // Close Directory first: no failed start can be joined while other cleanup runs.
  try { await directory.release(code, sessionId); } catch { /* continue cleanup */ }
  if (abortRoom) try { await room.abortCreate(sessionId); } catch { /* expiry alarm remains the backstop */ }
  if (endDb) {
    try {
      const result = await rpc.call('end_session', { p_session_id: sessionId, p_final_revision: 0, p_final_epoch: 0 });
      if (!result?.ok) rpcFailure('end_session', result, onAlert);
    } catch { /* an unavailable DB cannot block Directory cleanup */ }
  }
}

export async function startPublishedRoom({
  rpc, actor, workspaceId, caseVersionId, ttlMs, sessionId,
  directory, room, newCode, nowMs = Date.now(), onAlert,
}) {
  const userId = actor.userId;
  const member = await authorize(rpc, actor, workspaceId, ACTIONS.startRoom, onAlert);
  if (!member.ok) return member;
  const profile = await rpc.call('ensure_profile', {
    p_user_id: userId, p_display_name: member.profile.displayName || 'Facilitator',
  });
  if (!profile?.ok) return rpcFailure('ensure_profile', profile, onAlert);
  const version = await readIntactVersion(rpc, actor, workspaceId, caseVersionId, onAlert);
  if (!version.ok) return version;
  const expiresAtMs = nowMs + ttlMs;
  for (let attempt = 0; attempt < 8; attempt++) {
    const code = newCode();
    let claimed;
    try { claimed = await directory.register(code, sessionId, expiresAtMs); }
    catch {
      await compensate({ rpc, directory, room, code, sessionId, endDb: false, abortRoom: false, onAlert });
      return fail('unavailable', 503);
    }
    if (!claimed) continue;
    let inserted;
    try {
      inserted = await rpc.call('create_session', {
        p_session_id: sessionId, p_case_version_id: caseVersionId, p_workspace_id: workspaceId,
        p_facilitator_id: userId, p_join_code: code, p_ttl: `${ttlMs / 60_000} minutes`, ...adminArgs(actor),
      });
    } catch { inserted = { ok: false, kind: 'unavailable', status: 503, code: 'network' }; }
    if (!inserted?.ok) {
      await compensate({ rpc, directory, room, code, sessionId,
        endDb: inserted?.kind === 'unavailable', abortRoom: false, onAlert });
      if (inserted?.kind === 'unique' && inserted.code === '23505') continue;
      return rpcFailure('create_session', inserted, onAlert);
    }
    if (inserted.data !== sessionId) {
      await compensate({ rpc, directory, room, code, sessionId, endDb: true, abortRoom: false, onAlert });
      return fail('unavailable', 503);
    }
    let created;
    const ownerAdminDigest = actor.admin ? await emailDigest(actor.email) : null;
    try { created = await room.create({ sessionId, joinCode: code, caseDoc: version.document,
      caseVersionNo: version.versionNo, art: version.art, tint: version.tint, ownerUserId: userId, workspaceId, ownerAdminDigest, ttlMs, archiveSessionId: sessionId }); }
    catch { /* a DO may have committed before the response failed */ }
    if (!created || created.error || typeof created.facilitatorToken !== 'string' || typeof created.expiresAt !== 'string') {
      await compensate({ rpc, directory, room, code, sessionId, endDb: true, abortRoom: true, onAlert });
      return fail('unavailable', 503);
    }
    return { ok: true, sessionId, joinCode: code,
      facilitatorToken: created.facilitatorToken, expiresAt: created.expiresAt };
  }
  return fail('no_join_code', 503);
}
