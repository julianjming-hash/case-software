// Served participant renderer ported from the approved room phone prototype.
import { connect, storedCredential } from './transport.mjs';
import { parseRoute, privacyUrl, sessionUrl, joinEntryUrl } from '../shared/urls.mjs';
import { cleanText } from '../shared/text.mjs';
import { createOutbox } from './outbox.mjs';
import { settlePhoneDelivery, restorePhoneVote } from './phone-delivery.mjs';
import { createTurnstileController } from './turnstile-widget.mjs';
import { createJoinDocumentHandoff } from './join-handoff.mjs';
import { createPhoneTerminal } from './phone-terminal.mjs';
import { installPhonePageRestore } from './phone-pageshow.mjs';
import { openVoteStore } from './vote-store.mjs';
import { normalizeCode, formatCode, JOIN_CODE_LENGTH } from '../shared/ids.mjs';
import { WIRE_VERSION } from '../shared/wire.mjs';
import { markSvg, markFor } from './projector-marks.mjs';
import { timerRemainingS, timerWords, TIMER_ANNOUNCE_AT } from '../shared/timer.mjs';
import { identifierWarning } from '../shared/identifiers.mjs';
import { NAME_MAX, NAME_PROBLEM_TEXT, displayNameProblem, normaliseDisplayName } from '../shared/participant.mjs';
import { avatarEl } from './avatar.mjs';
import { h } from './phone-dom.mjs';
import { applyProfileReceipt } from './phone-profile.mjs';
import { rankingMoveControl, rankingRemoveControl } from './phone-ranking.mjs';
import { responseSummary } from './response-summary.mjs';
import { customAvatarPicker, joinAvatarPicker } from './phone-avatar-picker.mjs';
import { attachRoomCodeMask } from './phone-join-code.mjs';
import { mountCodeBoxes } from './code-boxes.mjs';
import { createPhoneBootstrap } from './phone-bootstrap.mjs';
import { createPhoneCleanup } from './phone-cleanup.mjs';
import { createParticipantTelemetry } from './phone-telemetry.mjs';
import { createTelemetry } from './telemetry.mjs';
import { inspectPhoneInventory } from './phone-recovery.mjs';
import { TEARDOWN_KEYS, assertKnownStorageKeys } from './teardown.mjs';
import { publicTimelineEntry } from './presentation-nav.mjs';
import { newlyPublicGroup } from './presentation-emphasis.mjs';

export async function mount() {
  const removePageRestore=installPhonePageRestore();
  let stopped=false,live=null,bootstrap=null,preserve=false,knownInventory=false,privacyReturn=false,handoffSessionId=null;
  const safeStorage=name=>{try{return globalThis[name];}catch{return null;}};
  const localStorage=safeStorage('localStorage'),sessionStorage=safeStorage('sessionStorage');
  const route=parseRoute(location.href);
  const entryDocument=route?.route==='join';
  let draft='';try{draft=sessionStorage?.getItem('case:phone:join-code-draft') ?? '';}catch{/* denied */}
  const initialCode=route?.code ?? normalizeCode(draft,JOIN_CODE_LENGTH) ?? '';
  let credential=storedCredential('participant',null,localStorage);
  const missingSavedPlace=!!route?.sessionId&&!credential;
  const cleanup=createPhoneCleanup({localStorage,sessionStorage,caches:globalThis.caches,indexedDB:globalThis.indexedDB,
    selection:()=>({role:'participant',sessionId:live?.sessionId ?? handoffSessionId ?? credential?.sessionId,
      credential:storedCredential('participant',null,localStorage),knownInventory,queueValidated:preserve}),
    privacyReturn:()=>privacyReturn,clearMemory:reason=>{if(reason!=='next_load'){credential=null;if(stopped||live)bootstrap?.dispose();else bootstrap?.release();}live?.cancel();}});
  const handoff=createJoinDocumentHandoff({cleanup,active:()=>!stopped,origin:location.origin,
    navigate:url=>{stopped=true;credential=null;bootstrap?.dispose();location.replace(url);},
    onUnavailable:()=>{document.querySelector('main')?.replaceChildren(h('section',{class:'card'},h('h1',{text:'Answer storage unavailable'}),h('p',{text:'Private storage could not be cleared. Close this page and reopen it in your browser.'})));}});
  const enterPlay=sessionId=>{handoffSessionId=sessionId;return handoff(sessionId);};
  const onPagehide=()=>{stopped=true;void cleanup('pagehide');};
  window.addEventListener('pagehide',onPagehide,{once:true});
  knownInventory=await inspectPhoneInventory({localStorage,sessionStorage,indexedDB:globalThis.indexedDB,
    assertKnownStorageKeys,knownDatabases:TEARDOWN_KEYS.knownDatabases});
  if(stopped)return;
  bootstrap=createPhoneBootstrap({code:route?.code,sessionId:route?.sessionId,credential,knownInventory,
    cleanup:(reason,selected)=>{preserve=selected;return cleanup(reason);}});
  const activate=result=>{
    if(stopped)return;
    credential=null;bootstrap.dispose();
    if(result.status==='ready'&&entryDocument){void enterPlay(result.sessionId);return;}
    if(result.status==='refused'&&!entryDocument){document.querySelector('main').replaceChildren(h('section',{class:'card'},h('h1',{text:'Your saved place is unavailable'}),h('p',{text:'This browser no longer has your saved place. To rejoin a room that is still open, enter its code.'}),h('p',{text:"Open in your browser or use mobile data if this page won't load"}),h('a',{href:joinEntryUrl(location.origin),class:'btn',text:'Enter a room code'})));return;}
    live=mountParticipant({initialCode,cleanup,missingSavedPlace,entryDocument,onHandoff:enterPlay,
      onValidated:()=>{preserve=true;},onPrivacy:()=>{privacyReturn=true;},active:()=>!stopped});
  };
  const show=result=>{
    if(stopped)return;
    if(result.status==='ready'||result.status==='refused'){activate(result);return;}
    const unavailable=result.status==='unavailable';
    const main=document.querySelector('main');
    main.replaceChildren(h('section',{class:'card'},h('h1',{text:unavailable?'Recovery unavailable':'Answer storage unavailable'}),
      h('p',{text:unavailable?'Could not confirm your room. Retry when the connection is available.':'Private storage could not be cleared. Close this page and reopen it in your browser.'}),
      result.count?h('p',{text:`Not sent yet · ${result.count}`}):null,
      unavailable?h('button',{type:'button',class:'btn primary',text:'Retry',onclick:async event=>{
        event.currentTarget.disabled=true;show(await bootstrap.retry());
      }}):null));
  };
  show(await bootstrap.start());
  return {cancel(){stopped=true;credential=null;bootstrap?.dispose();live?.cancel();removePageRestore();window.removeEventListener('pagehide',onPagehide);},
    teardown:reason=>{stopped=true;credential=null;bootstrap?.dispose();return cleanup(reason??'token_loss');}};
}

function mountParticipant({initialCode,cleanup,onValidated,onPrivacy,active,missingSavedPlace=false,entryDocument=false,onHandoff}) {
let disposed = false;
const timeouts = new Set(), intervals = new Set(), listeners = [], challenges = new Set(), splashes = new Set();
const listen = (target, type, fn) => { target.addEventListener(type, fn); listeners.push(() => target.removeEventListener(type, fn)); };
const setTimeout = (fn, delay) => { const id = globalThis.setTimeout(() => { timeouts.delete(id); if (!disposed) fn(); }, delay); timeouts.add(id); return id; };
const setInterval = (fn, delay) => { const id = globalThis.setInterval(() => { if (!disposed) fn(); }, delay); intervals.add(id); return id; };


// ───────────────────────── tiny DOM helpers (text only) ─────────────────────────
const SVGNS = 'http://www.w3.org/2000/svg';

const S_ = (d, extra = {}) => ['path', { d, fill: 'none', stroke: 'currentColor', 'stroke-width': 1.7, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', ...extra }];
const ICONS = {
  spinner: [['circle', { cx: 8, cy: 8, r: 6, fill: 'none', stroke: 'currentColor', 'stroke-width': 2, 'stroke-opacity': .25 }], S_('M8 2a6 6 0 0 1 6 6', { 'stroke-width': 2 })],
  hourglass: [S_('M4 2h8M4 14h8M5 2c0 4 3 4 3 6s-3 2-3 6M11 2c0 4-3 4-3 6s3 2 3 6')],
  eye: [S_('M1 8s3-5 7-5 7 5 7 5-3 5-7 5-7-5-7-5z'), ['circle', { cx: 8, cy: 8, r: 2, fill: 'currentColor' }]],
  people: [['circle', { cx: 8, cy: 5, r: 2.5, fill: 'none', stroke: 'currentColor', 'stroke-width': 1.7 }], S_('M3 14c0-3 2-5 5-5s5 2 5 5')],
  lock: [['rect', { x: 3, y: 7, width: 10, height: 7, rx: 1.5, fill: 'none', stroke: 'currentColor', 'stroke-width': 1.7 }], S_('M5 7V5a3 3 0 0 1 6 0v2')],
  book: [S_('M2 3h5a1 1 0 0 1 1 1v9a1 1 0 0 0-1-1H2zM14 3H9a1 1 0 0 0-1 1v9a1 1 0 0 1 1-1h5z')],
  pause: [['rect', { x: 4, y: 3, width: 3, height: 10, fill: 'currentColor' }], ['rect', { x: 9, y: 3, width: 3, height: 10, fill: 'currentColor' }]],
  flag: [S_('M3 14V2M3 3h9l-2 3 2 3H3')],
  wifioff: [S_('M1 6a10 10 0 0 1 14 0M4 9a6 6 0 0 1 8 0M7 12a2 2 0 0 1 2 0M2 2l12 12')],
  check: [S_('M3 8.5l3 3 7-7', { 'stroke-width': 2 })],
  info: [['circle', { cx: 8, cy: 8, r: 6.5, fill: 'none', stroke: 'currentColor', 'stroke-width': 1.7 }], S_('M8 7v4M8 4.8v.2')],
  alert: [S_('M8 2l7 12H1z'), S_('M8 6.5v3.2M8 11.8v.2')],
  // classification set (SCREENS.md Accessibility)
  sound: [['circle', { cx: 8, cy: 8, r: 7, fill: 'currentColor' }], S_('M4.5 8.2l2.4 2.4 4.6-4.8', { stroke: '#fff', 'stroke-width': 2 })],
  defensible: [['circle', { cx: 8, cy: 8, r: 6.5, fill: 'none', stroke: 'currentColor', 'stroke-width': 1.7 }], S_('M4.8 8.2l2.2 2.2 4.2-4.4')],
  'context-dependent': [S_('M8 14V8M8 8L3.5 3M8 8l4.5-5')],
  unsafe: [S_('M8 2l7 12H1z'), S_('M8 6.5v3.2M8 11.8v.2')],
  'terminal-unsafe': [S_('M5 1h6l4 4v6l-4 4H5l-4-4V5z'), S_('M5 8h6', { 'stroke-width': 2 })],
  'discussion-prompt': [S_('M2 3h12v8H7l-3 3v-3H2z')],
};
function icon(name, size = 16, cls = '') {
  const svg = document.createElementNS(SVGNS, 'svg');
  svg.setAttribute('width', size); svg.setAttribute('height', size); svg.setAttribute('viewBox', '0 0 16 16');
  svg.setAttribute('aria-hidden', 'true'); svg.setAttribute('focusable', 'false');
  if (cls) svg.setAttribute('class', cls);
  for (const [tag, attrs] of ICONS[name] || []) {
    const n = document.createElementNS(SVGNS, tag);
    for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
    svg.append(n);
  }
  return svg;
}
const $ = (id) => document.getElementById(id);
const clean = value => cleanText(value);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/** A soft, never blocking, warning under a text field when it looks like a patient identifier (RT2 P2). */
function idWarn(input, id) {
  const p = h('p', { class: 'idwarn', id, role: 'status', 'aria-live': 'polite' });
  const upd = () => { const w = identifierWarning(input.value); if (p.textContent !== w) p.textContent = w; };
  input.addEventListener('input', upd);
  const prior = input.getAttribute('aria-describedby');
  input.setAttribute('aria-describedby', `${prior ? `${prior} ` : ''}${id}`);
  return { p, upd };
}

// ───────────────────────── exact copy (docs/SCREENS.md) ─────────────────────────
const C = {
  sending: 'Sending…',
  saved: 'Answer saved · you can change it until responses lock',
  savedDup: 'Answer saved · already received',
  lockedSaved: 'Voting locked · your last saved answer stands',
  lockedNone: 'Voting locked · no answer was recorded from this phone',
  held: 'Paused · your answer is held',
  updating: 'Updating · checking the room…',
  rejected: 'Answer not saved · check your choice and try again',
  voided: 'Round cancelled · the facilitator will open a new round',
  manualRoom: 'Facilitator-led discussion · answers are off for now',
  removed: 'You were removed from this room',
  ended: 'This room has ended',
  waiting: 'Waiting for connection · your answer will send automatically',
  invalidCode: "That code isn't right · check it against the projector",
  closed: 'This room is not accepting new participants',
};
const CLASS_LABEL = {
  sound: 'Sound', defensible: 'Defensible', 'context-dependent': 'Context-dependent',
  unsafe: 'Unsafe · recoverable', 'terminal-unsafe': 'Terminal · needs a checkpoint reset', 'discussion-prompt': 'Discussion prompt',
};
// The phase pill (CASE-114): open green, locked amber, reveal petrol, consequence coral, paused slate.
const PHASE_CHIP = {
  waiting: ['Waiting to start', 'hourglass', 'reveal'], live: ['Live surface', 'eye', 'reveal'], decision_open: ['Team decision', 'people', 'open'],
  reviewing: ['Voting locked', 'lock', 'locked'], teaching: ['Teaching point', 'book', 'consequence'], paused: ['Discussion pause', 'pause', 'paused'], ended: ['Your private recap', 'flag', 'reveal'],
};
const HOW_CHOSEN = {
  majority: 'The facilitator followed the majority view', minority: 'The facilitator followed the minority view', override: 'The facilitator chose a different route',
};
const TEAM_CHOICE = {
  majority: 'Followed the majority view', minority: 'Followed a minority view', override: 'The facilitator chose a different route', manual_room: 'Chosen in the room, without phone votes',
};

const root = h('div', { class: 'phone-app' },
  h('header', { class: 'top' }, h('div', { class: 'who' }, h('span', { id: 'whoAv' }), h('div', { class: 'who-text' }, h('p', { class: 'brand', text: 'Case' }), h('p', { class: 'name', id: 'who', text: 'Join a room' }))),
    h('span', { id: 'phaseChip', class: 'pill', hidden: true }), h('button', { type: 'button', class: 'iconbtn', id: 'menuBtn', 'aria-expanded': 'false', 'aria-controls': 'menu', 'aria-label': 'Menu', hidden: true }, icon('people', 20))),
  h('div', { class: 'conn', id: 'conn', role: 'status', 'aria-live': 'polite' }), h('div', { id: 'menu', class: 'panel', hidden: true }),
  h('p', { class: 'note', id: 'note', role: 'status', 'aria-live': 'polite' }), h('p', { id: 'unsent', class: 'unsent', role: 'status', 'aria-live': 'polite' }),
  h('main', { id: 'main' }), h('p', { class: 'sr-only-live', id: 'announce', role: 'status', 'aria-live': 'polite' }),
  h('div', { class: 'bar', id: 'liveBar', hidden: true }, h('div', { class: 'inner' }, h('button', { type: 'button', class: 'btn primary block', id: 'liveBtn', text: 'Live surface' }))));
document.querySelector('main').replaceWith(root);
document.body.classList.add('phone-page');
document.documentElement.classList.add('phone-page');
const terminate=createPhoneTerminal({cleanup,active,show:(reason,complete)=>{
  const heading=!complete?'Answer storage unavailable':reason==='removed'?C.removed:reason==='recap_expiry'?'Your recap has expired':'Your saved place is unavailable';
  root.replaceChildren(h('main',{},h('section',{class:'card'},h('h1',{text:heading}),
    h('p',{text:complete?'To join a room that is still open, enter its code.':'Private storage could not be cleared. Close this page and reopen it in your browser.'}),
    complete?h('a',{href:joinEntryUrl(location.origin),class:'btn',text:'Enter a room code'}):null)));
}});

// ───────────────────────── connection ─────────────────────────
const route = parseRoute(location.href);
const JOIN_CODE_DRAFT = 'case:phone:join-code-draft'; // Public code only; no name or credential.
const participantTelemetry = createParticipantTelemetry({ createReporter: () => createTelemetry({ api: location.origin }) });
const link = connect({ role: 'participant', api: location.origin, sessionId: route?.sessionId ?? null, telemetryImpl: participantTelemetry });
const voteStore = openVoteStore();
let outbox = null, outboxOwner = null, binding = Promise.resolve(), enqueuing = false, expiryTimer = null;
async function updateUnsent() {
  if (disposed) return;
  try {
    const count = outbox ? await outbox.count() : link.hasToken && link.sessionId ? (await voteStore.read(link.sessionId)).filter(row => !row.superseded).length : 0;
    if (!disposed) $('unsent').textContent = count ? `Not sent yet · ${count}` : '';
  } catch { if (!disposed) $('unsent').textContent = 'Answer storage unavailable · keep this page open'; }
}
function restoreOutbox(view) {
  binding = binding.then(async () => {
    if (disposed || view !== S.view || view?.you?.removed || !view?.you?.id || !link.sessionId) return;
    const owner = view.you.id, roomId = link.sessionId;
    if (outboxOwner !== owner) {
      await outbox?.close();
      if (disposed || view !== S.view) return;
      // A newly confirmed participant must never restore an earlier owner's draft.
      await voteStore.update(roomId, rows => ({ rows: rows.filter(row => row.participantId === owner), result: null }));
      if (disposed || view !== S.view) return;
      outboxOwner = owner;
      participantTelemetry.confirm(view, roomId);
      onValidated();
      if(entryDocument){await onHandoff(roomId);return;}
      outbox = createOutbox({ store: voteStore, roomId, participantId: owner, send: async envelope => {
        const p = dec.pend?.body.clientEventId === envelope.clientEventId ? dec.pend : { roundId: envelope.roundId, response: envelope.response, body: envelope, state: 'sending' };
        const receipt = await link.sendFrame({ ...envelope, t: 'command' });
        if (!disposed) onReceipt(p, receipt.receipt === 'dropped' ? { ...receipt, receipt: 'timeout' } : receipt);
        return receipt;
      } });
    }
    await voteStore.update(roomId, rows => ({ rows: rows.filter(row => row.participantId !== owner || row.envelope.roundId === view.decision?.roundId), result: null }));
    if (disposed || view !== S.view) return;
    await outbox.setEpoch(S.snap?.epoch ?? 0);
    const pending = await restorePhoneVote({
      read: () => view.decision ? outbox.latest(view.decision.roundId) : null,
      current: () => !disposed && view === S.view,
      accepted: () => dec.accepted,
      version: () => dec.ver,
      restore: pending => {
        if (!dec.pend || dec.pend.body.clientEventId !== pending.clientEventId) {
          dec.pend = { roundId: pending.roundId, body: pending, response: pending.response, state: view.decision.status === 'held' ? 'held' : 'waiting' };
          dec.draft = draftFrom(view.decision, pending.response);
          refreshDecision();
        }
      },
    });
    if (disposed || view !== S.view) return;
    await updateUnsent();
    if(disposed || view!==S.view)return;
    if (pending && dec.accepted?.clientEventId !== pending.clientEventId && view.decision?.status === 'open' && !view.manual && S.conn === 'online') dispatchPending(dec.pend);
    if (view.recap?.expiresAt) {
      if (expiryTimer) globalThis.clearTimeout(expiryTimer);
      const remaining = Date.parse(view.recap.expiresAt) - Date.now();
      if (Number.isFinite(remaining)) expiryTimer = setTimeout(() => controller.teardown('recap_expiry'), Math.max(0, remaining));
    }
  }).catch(() => { if (!disposed) $('unsent').textContent = 'Answer storage unavailable · keep this page open'; });
  return binding;
}


const S = {
  mode: null, view: null, snap: null, conn: link.status, everOnline: false, removed: false,
  browseIndex: null, liveKey: undefined, liveSurface: null, phaseKey: undefined, note: '', joinedHere: false,
};
const main = $('main');
const el = {}; // persistent room containers
const wideQuery = globalThis.matchMedia?.('(min-width: 64rem)');
let wide = wideQuery?.matches ?? false, situationOpen = false;
listen(wideQuery ?? window, 'change', () => {
  if (disposed || wide === (wideQuery?.matches ?? false)) return;
  const focusedSurface = el.surface?.contains(document.activeElement);
  wide = wideQuery.matches;
  if (S.mode !== 'room') return;
  updateRoom();
  // Only restore the removed information control; answer inputs never rebuild here.
  if (focusedSurface) (el.surface.querySelector('summary, [data-focus-heading]'))?.focus({ preventScroll: true });
});

link.on('snapshot', (snap) => { if (disposed) return; if(snap.view?.you?.removed){void terminate('removed');return;} if(snap.view?.recap?.expiresAt && Date.parse(snap.view.recap.expiresAt)<=Date.now()){void terminate('recap_expiry');return;} S.conn = link.status; S.snap = snap; S.view = snap.view; if(!entryDocument)render(); restoreOutbox(snap.view); });
link.on('status', (st) => { if (disposed) return; S.conn = st; if (S.conn === 'online') S.everOnline = true; else { link.dropPending(); if (dec.pend) dec.pend.state = 'waiting'; } renderConn(); updateUnsent(); if (S.mode === 'room') { refreshDecision(); if (S.conn === 'online') restoreOutbox(S.view); } });
link.on('welcome', () => { if(!disposed)S.everOnline = true; });
link.on('error', (e) => {
  if (e === 'removed') { void terminate('removed'); }
  if (e === 'unauthorised') { void terminate('unauthorised'); }
});
listen(window, 'offline', () => { if (disposed) return; S.conn = 'lost'; link.dropPending(); if (dec.pend) dec.pend.state = 'waiting'; renderConn(); refreshDecision(); });
listen(document, 'visibilitychange', () => { if (!document.hidden && S.mode === 'room') refreshDecision(); });

// Print on white paper in either theme (card 36a, spec §11): the light tokens apply while the browser prints.
let printTheme = null;
const toPaper = () => { if (printTheme !== null) return; printTheme = document.documentElement.dataset.theme ?? ''; document.documentElement.dataset.theme = 'light'; };
const fromPaper = () => { if (printTheme === null) return; if (printTheme) document.documentElement.dataset.theme = printTheme; else delete document.documentElement.dataset.theme; printTheme = null; };
listen(window, 'beforeprint', toPaper); listen(window, 'afterprint', fromPaper);
const printQuery = globalThis.matchMedia?.('print');
const onPrintQuery = (event) => { if (event.matches) toPaper(); else fromPaper(); };
printQuery?.addEventListener?.('change', onPrintQuery);
listeners.push(() => { printQuery?.removeEventListener?.('change', onPrintQuery); fromPaper(); });

// ───────────────────────── mode switching ─────────────────────────
function pickMode() {
  const v = S.view;
  if (S.removed || v?.you?.removed) return 'removed';
  if (v?.you) return 'room';
  if (link.hasToken) return 'connecting';
  return 'join';
}

function render() {
  if (disposed) return;
  const mode = pickMode();
  if (mode !== S.mode) {
    const first = S.mode === null;
    S.mode = mode;
    mountMode(mode);
    if (!first) queueMicrotask(() => focusIfLost());
  }
  renderHeader();
  renderConn();
  if (mode === 'room') updateRoom();
}

function mountMode(mode) {
  stopSplashes();
  main.replaceChildren();
  for (const k of Object.keys(el)) delete el[k];
  resetDecision();
  $('liveBar').hidden = true;
  main.classList.remove('pad-bar', 'participant-room', 'participant-decision');
  if (mode === 'join') main.append(buildJoin());
  else if (mode === 'removed') main.append(h('section', { class: 'card', 'aria-labelledby': 'mh' }, h('h1', { id: 'mh', tabindex: '-1', text: C.removed })));
  else if (mode === 'connecting') main.append(h('section', { class: 'card', 'aria-labelledby': 'mh' }, h('h1', { id: 'mh', tabindex: '-1', text: 'Checking the room…' }), h('p', { class: 'muted', text: 'Your place in the room is saved on this phone.' })));
  else if (mode === 'room') buildRoomShell();
}

function focusIfLost() {
  const a = document.activeElement;
  if (a && a !== document.body && a.isConnected) return;
  const t = main.querySelector('[data-focus-heading]') || main.querySelector('h1, h2');
  t?.focus({ preventScroll: true });
}
function typingNow() {
  const a = document.activeElement;
  return !!a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA' || a.tagName === 'SELECT') && a.isConnected;
}
function say(text) { const a = $('announce'); a.textContent = ''; setTimeout(() => { a.textContent = text; }, 30); }

// ───────────────────────── header, connection chip, menu ─────────────────────────
function renderHeader() {
  const v = S.view;
  const who = $('who');
  const mode = S.mode;
  who.textContent = mode === 'room' ? (v.you.name || "You're in") : mode === 'join' ? 'Join a room' : mode === 'removed' ? 'Case' : 'Case room';
  const av = mode === 'room' ? `${v.you.avatarId ?? ''}|${v.you.name ?? ''}` : '';
  if ($('whoAv').dataset.k !== av) { $('whoAv').dataset.k = av; $('whoAv').replaceChildren(...(av ? [avatarEl(v.you.avatarId, { size: 32, name: v.you.name })] : [])); }
  const chip = $('phaseChip');
  if (mode === 'room' && PHASE_CHIP[v.phase]) {
    const [text, ic, ph] = PHASE_CHIP[v.phase];
    chip.hidden = false;
    chip.dataset.phase = ph;
    if (chip.dataset.k !== text) { chip.dataset.k = text; chip.replaceChildren(icon(ic), document.createTextNode(text)); }
  } else chip.hidden = true;
  $('menuBtn').hidden = !(mode === 'room' && v.phase !== 'waiting' && v.phase !== 'ended');
  if ($('menuBtn').hidden) closeMenu();
}
function renderConn() {
  const box = $('conn');
  let kind = null, text = '';
  if (S.mode === 'room' || S.mode === 'connecting') {
    if (S.conn === 'lost') { kind = 'lost'; text = 'Connection lost · follow the room'; }
    else if (S.conn !== 'online') { kind = 'wait'; text = S.everOnline ? 'Reconnecting…' : 'Connecting…'; }
  }
  const sig = `${kind}|${text}`;
  if (box.dataset.sig === sig) return;
  box.dataset.sig = sig;
  box.replaceChildren();
  if (!kind) return;
  box.append(h('div', { class: `banner ${kind}` }, icon(kind === 'lost' ? 'wifioff' : 'spinner', 18, kind === 'wait' ? 'spin' : ''), h('span', { text })));
}

let renameCtl = null;
$('menuBtn').addEventListener('click', () => {
  const m = $('menu');
  if (m.hidden) openMenu(); else closeMenu(true);
});
function openMenu() {
  const m = $('menu');
  m.hidden = false;
  $('menuBtn').setAttribute('aria-expanded', 'true');
  if (!m.firstChild) { renameCtl = buildRename('menu'); m.append(h('h2', { class: 'rename-heading', text: 'Your name and avatar' }), renameCtl.root); }
  renameCtl.sync();
  renameCtl.input.focus();
}
function closeMenu(returnFocus) {
  const m = $('menu');
  if (m.hidden) return;
  m.hidden = true;
  $('menuBtn').setAttribute('aria-expanded', 'false');
  if (returnFocus) $('menuBtn').focus();
}
listen(document, 'keydown', (e) => { if (e.key === 'Escape') closeMenu(true); });

/**
 * The name field (CASE-119): required, 3–20 letters, numbers, spaces, hyphens or apostrophes; duplicates
 * allowed. Checked as you type once you have typed, and again on submit; the server checks it too.
 */
function nameField(prefix, { value = '' } = {}) {
  const input = h('input', { type: 'text', id: `${prefix}-name`, maxlength: String(NAME_MAX + 10), autocomplete: 'nickname', autocapitalize: 'words', enterkeyhint: 'done', required: '', 'aria-describedby': `${prefix}-count ${prefix}-nerr` });
  input.value = value;
  const count = h('p', { class: 'counter', id: `${prefix}-count`, text: `${[...value].length} of ${NAME_MAX}` });
  const err = h('p', { class: 'err', id: `${prefix}-nerr`, role: 'status', 'aria-live': 'polite' });
  const warn = idWarn(input, `${prefix}-warn`);
  let touched = false;
  const problem = () => displayNameProblem(input.value);
  const show = (force) => {
    const pr = problem();
    const on = pr && (touched || force);
    err.replaceChildren(...(on ? [icon('alert', 16), document.createTextNode(NAME_PROBLEM_TEXT[pr])] : []));
    if (on) input.setAttribute('aria-invalid', 'true'); else input.removeAttribute('aria-invalid');
    return !pr;
  };
  input.addEventListener('input', () => { count.textContent = `${[...input.value.trim()].length} of ${NAME_MAX}`; if (touched) show(); });
  input.addEventListener('blur', () => { if (input.value.trim()) { touched = true; show(); } });
  const root = h('div', {}, h('label', { class: 'field', for: `${prefix}-name`, text: 'Your name' }), input, count, err, warn.p);
  return {
    root, input, valid: () => show(true), value: () => normaliseDisplayName(input.value),
    set(v) { input.value = v ?? ''; count.textContent = `${[...input.value].length} of ${NAME_MAX}`; touched = false; show(); warn.upd(); },
  };
}

/** Change of name or avatar (lobby inline and header menu): `Save changes` (CASE-121). Epoch-fenced, so a stale_epoch is retried once. */

function buildRename(prefix) {
  const name = nameField(prefix);
  const pick = customAvatarPicker(prefix);
  const msg = h('p', { class: 'small', id: `${prefix}-msg`, role: 'status', 'aria-live': 'polite' });
  const btn = h('button', { type: 'submit', class: 'btn block', text: 'Save changes' });
  let dirty = false;
  name.input.addEventListener('input', () => { dirty = true; });
  pick.onPick(() => { dirty = true; });
  const root = h('form', { class: 'stack', novalidate: '' }, name.root, pick.root, btn, msg);
  root.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    if (!name.valid()) { name.input.focus(); return; }
    if (!pick.valid()) return;
    const body = { displayName: name.value(), avatarId: pick.value() };
    btn.disabled = true;
    msg.textContent = S.conn === 'online' ? 'Saving…' : 'Waiting for connection · your changes will send automatically';
    let rb = await link.send('rename', body);
    if (disposed) return;
    if (rb.receipt === 'stale_epoch') { await sleep(700); if (disposed) return; rb = await link.send('rename', body); }
    if (disposed) return;
    btn.disabled = false;
    if (rb.receipt === 'accepted' || rb.receipt === 'already_accepted') {
      msg.textContent = 'Changes saved'; dirty = false;
      // Rename is quiet for phones; the server receipt confirms this phone's own saved appearance.
      applyProfileReceipt(rb, S.view, body, () => {
        if (prefix === 'menu') closeMenu(true);
        else { const details = root.closest('details'); if (details) { details.open = false; details.querySelector('summary')?.focus(); } }
      });
      render();
    }
    else if (rb.reason === 'unknown_participant') { void terminate('removed'); }
    else msg.textContent = 'Not saved · check your name and try again';
  });
  return {
    root, input: name.input,
    sync() { if (!dirty && !root.contains(document.activeElement)) { name.set(S.view?.you?.name ?? ''); pick.set(S.view?.you?.avatarId ?? null); } },
  };
}

// ───────────────────────── join flow ─────────────────────────
// Code and a required name, with an allowlisted avatar default, then `Join case` (CASE-119, CASE-121). There is no
// nameless join. Everything is checked here first, and again by the server (parseJoinRequest).
// Card 36a: a well-formed prefilled code is confirmed in one line (Change opens the existing input in place); the avatar
// is preassigned with the grid folded under Change avatar; the page draws the BRAND braid (this phone holds only a code,
// so no case is disclosed, CASE-164).
/** Draw splash art into `host` from the lazy chunk; a failed load leaves the plain ground (the art is decorative). */
async function paintSplash(host, opts) {
  let chunk;
  try { chunk = await import('./splash.mjs'); } catch { return; }
  if (disposed || !host.isConnected) return;
  splashes.add(chunk.mountCaseSplash(host, opts.art ?? null, opts));
}
function stopSplashes() { for (const splash of splashes) splash.stop(); splashes.clear(); }
function buildJoin() {
  let savedCode = '';
  try { savedCode = sessionStorage.getItem(JOIN_CODE_DRAFT) || ''; } catch { /* private browsing can deny storage */ }
  const code = h('input', { type: 'text', id: 'jcode', inputmode: 'text', autocomplete: 'off', autocapitalize: 'characters', autocorrect: 'off', spellcheck: 'false', maxlength: String(JOIN_CODE_LENGTH), minlength: String(JOIN_CODE_LENGTH), enterkeyhint: 'next', required: '', 'aria-describedby': 'jcode-hint jcode-err' });
  const codeHint = h('p', { class: 'hint', id: 'jcode-hint' });
  attachRoomCodeMask(code, codeHint, initialCode || savedCode);
  try { sessionStorage.removeItem(JOIN_CODE_DRAFT); } catch { /* denied */ }
  const codeErr = h('p', { class: 'err', id: 'jcode-err', role: 'alert' });
  const preset = normalizeCode(code.value, JOIN_CODE_LENGTH);
  const codeBoxes = mountCodeBoxes(code);
  const codeField = h('div', { id: 'jcode-field' }, h('label', { class: 'field', for: 'jcode', text: 'Room code' }), codeBoxes.root, codeHint, codeErr);
  const change = h('button', { type: 'button', class: 'btn tertiary', id: 'jcode-change', 'aria-label': 'Change code', 'aria-controls': 'jcode-field', 'aria-expanded': 'false', text: 'Change' });
  const roomText = h('p', { class: 'room-line-text' });
  roomText.append(document.createTextNode('Room '), h('span', { class: 'room-code', text: preset ? formatCode(preset) : '' }));
  const roomLine = h('div', { class: 'room-line' }, roomText, change);
  // The input is shown whenever there is no well-formed code, and whenever a refusal fills the error under it.
  const showCodeField = (focus) => { codeField.hidden = false; roomLine.hidden = true; change.setAttribute('aria-expanded', 'true'); if (focus) code.focus(); };
  codeField.hidden = !!preset; roomLine.hidden = !preset;
  change.addEventListener('click', () => showCodeField(true));
  const name = nameField('j');
  name.root.classList.add('join-name');
  name.root.append(h('p', { class: 'hint', text: 'Do not enter patient details.' }));
  // The avatar is preassigned (the allowlisted random default); the grid and Randomise sit under Change avatar.
  const pick = joinAvatarPicker('j');
  pick.ensureSelected();
  const avatarSlot = h('span', { class: 'avatar-slot' });
  const avatarNote = h('span', { class: 'avatar-note', text: 'Picked at random. You can change it now or later.' });
  const updAvatar = () => avatarSlot.replaceChildren(avatarEl(pick.value(), { size: 56, name: name.value() }));
  pick.onPick(() => { avatarNote.textContent = 'Your choice. You can change it now or later.'; updAvatar(); });
  name.input.addEventListener('input', updAvatar);
  updAvatar();
  const avatarRow = h('div', { class: 'avatar-row' }, avatarSlot, h('div', { class: 'avatar-text' }, h('span', { class: 'avatar-label', text: 'Your avatar' }), avatarNote));
  const avatarMore = h('details', { class: 'disclose' }, h('summary', { text: 'Change avatar' }), pick.root);
  const joinErr = h('p', { class: 'err', id: 'jerr', role: 'alert' });
  const joinBtn = h('button', { type: 'submit', class: 'btn primary block lg', text: 'Join case' });
  const status = h('p', { class: 'small muted', role: 'status', 'aria-live': 'polite' });
  const challengeArea=h('div',{'data-turnstile-challenge':''});
  const challenge=createTurnstileController(challengeArea,{onUnavailable:()=>{if(!disposed)status.textContent='Verification unavailable · check your code and try Join again';}});
  challenges.add(challenge);
  const privacy = h('a', { href: privacyUrl(location.origin), text: 'Privacy' });
  privacy.addEventListener('click', () => {
    try {
      sessionStorage.setItem(JOIN_CODE_DRAFT, code.value);
      onPrivacy();
    } catch { /* the link still works */ }
  });
  const form = h('form', { class: 'card splash-panel', novalidate: '', 'aria-labelledby': 'mh' },
    h('h1', { id: 'mh', tabindex: '-1', 'data-focus-heading': '', text: 'Join the case' }),
    missingSavedPlace ? h('p', { text: 'This browser no longer has your saved place. To rejoin a room that is still open, enter its code.' }) : null,
    missingSavedPlace ? h('p', { class: 'hint', text: "Open in your browser or use mobile data if this page won't load" }) : null,
    roomLine, codeField,
    name.root, avatarRow, avatarMore,
    joinErr, status, challengeArea, h('p', { class: 'hint', text: 'Your name and avatar appear on the projector in the lobby.' }), joinBtn,
    h('footer', { class: 'join-footer' }, privacy));
  const artHost = h('div', { class: 'splash-art', 'data-splash-art': '', 'aria-hidden': 'true' });
  void paintSplash(artHost, { brand: true, aspect: 0.5, focus: [0.02, 0.62, 0.98, 0.99] });

  async function go() {
    codeErr.textContent = ''; joinErr.textContent = ''; code.removeAttribute('aria-invalid');
    const norm = normalizeCode(code.value, JOIN_CODE_LENGTH);
    if (!norm) { code.setAttribute('aria-invalid', 'true'); codeErr.replaceChildren(icon('alert', 16), document.createTextNode(C.invalidCode)); showCodeField(true); return; }
    if (!name.valid()) { name.input.focus(); return; }
    pick.ensureSelected();
    joinBtn.disabled = true;
    status.textContent = 'Joining…';
    const res = await link.join(norm, name.value(), pick.value(), challenge.takeToken() ?? undefined);
    if (disposed) return;
    if (res.ok) { await restoreOutbox(link.snapshot?.view ?? S.view); if (disposed) return; if(entryDocument){status.textContent='Joined · checking the room…';return;} try { sessionStorage.removeItem(JOIN_CODE_DRAFT); } catch { /* no stored draft */ } status.textContent = 'Joined · checking the room…'; render(); return; }
    joinBtn.disabled = false;
    status.textContent = '';
    const e = res.error;
    if(e==='challenge_required'){if(res.siteKey){status.textContent='Verify to try another code';await challenge.challenge(res.siteKey);}else status.textContent='Verification unavailable · check your code and try Join again';return;}
    if(e==='challenge_failed'){status.textContent='Verification expired · try again';return;}
    if (e === 'unknown_code' || e === 'bad_code') { code.setAttribute('aria-invalid', 'true'); codeErr.replaceChildren(icon('alert', 16), document.createTextNode(C.invalidCode)); showCodeField(true); }
    else if (e === 'bad_display_name' || e === 'unsafe_characters') { joinErr.textContent = NAME_PROBLEM_TEXT.characters; name.input.focus(); }
    else if (e === 'bad_avatar') joinErr.textContent = 'Choose an avatar';
    else if (e === 'joining_closed') joinErr.textContent = C.closed;
    else if (e === 'room_full') joinErr.textContent = 'This room is full';
    else if (e === 'removed') { void terminate('removed'); }
    else if (e === 'network') joinErr.textContent = "Couldn't reach the room · check your connection and try again";
    else joinErr.textContent = "Couldn't join · check the code and try again";
  }
  form.addEventListener('submit', (ev) => { ev.preventDefault(); go(); });
  return h('div', { class: 'phone-splash' }, artHost, form);
}

// ───────────────────────── room shell ─────────────────────────
function buildRoomShell() {
  // Every room state has a level-one heading (axe page-has-heading-one); the lobby brings its own.
  el.title = h('h1', { class: 'sr-only', text: 'Case room' });
  el.banners = h('div', { class: 'stack' });
  el.browse = h('div', { class: 'stack' });
  el.lobby = h('section', { class: 'phone-splash', hidden: '' });
  el.surface = h('section', { class: 'stack participant-information' });
  el.decision = h('section', { class: 'card', hidden: '' });
  el.result = h('div', { class: 'participant-result' });
  el.recap = h('section', { class: 'card', hidden: '' });
  el.tl = h('section', { class: 'tl', 'aria-labelledby': 'tlh' });
  main.classList.add('participant-room');
  main.append(el.title, el.banners, el.browse, el.lobby, el.surface, el.decision, el.result, el.recap, el.tl);
  S.liveKey = undefined; S.liveSurface = null; S.phaseKey = undefined; S.browseIndex = null; S.note = '';
}
function setSection(node, sig, build) {
  if (node._sig === sig) return false;
  node._sig = sig;
  node.replaceChildren(...[].concat(build() ?? []));
  return true;
}

function updateRoom() {
  const disclosure = el.surface?.querySelector('details.ctx');
  if (disclosure) situationOpen = disclosure.open;
  const v = S.view;
  const live = v.liveSurface;
  const groupKey = entry => JSON.stringify([entry?.scene, entry?.assetIds, entry?.observations, entry?.points, entry?.investigations]);
  const liveKey = live ? `${live.surfaceId}@${live.at}:${groupKey(live)}` : '';
  const dKey = `${v.decision?.roundId ?? ''}|${v.decision?.status ?? ''}`;
  const phaseKey = `${v.phase}|${dKey}`;
  const liveChanged = S.liveKey !== undefined && liveKey !== S.liveKey;
  const accentGroup = liveChanged ? newlyPublicGroup(S.liveSurface, live) : null;
  const phaseChanged = S.phaseKey !== undefined && phaseKey !== S.phaseKey;
  if (liveChanged) {
    S.browseIndex = null; // the next shared reveal auto-advances every phone back to live
    S.note = v.phase === 'decision_open' ? 'Team decision open' : (v.phase === 'live' || v.phase === 'teaching') ? 'New material shared' : '';
    if (S.note) say(S.note);
  } else if (phaseChanged) S.note = '';
  S.liveKey = liveKey;
  S.liveSurface = live;
  S.phaseKey = phaseKey;

  const selected = publicTimelineEntry(v.timeline, S.browseIndex);
  const browsing = selected.browsing;
  if (!browsing) S.browseIndex = null;
  const entry = browsing ? selected.entry : live;

  const noteShown = browsing ? '' : S.note;
  if ($('note').textContent !== noteShown) $('note').textContent = noteShown;
  $('liveBar').hidden = !browsing;
  main.classList.toggle('pad-bar', browsing);
  el.browse.replaceChildren();
  if (browsing) el.browse.append(h('div', { class: 'banner info', role: 'note' }, icon('info', 18), h('span', { text: 'Earlier material · read-only' })));

  const lobby = v.phase === 'waiting';
  el.lobby.hidden = !lobby;
  el.title.hidden = lobby;
  if (lobby) updateLobby(v);

  const ended = v.phase === 'ended';
  const decisionShown = !!v.decision && !browsing;
  main.classList.toggle('participant-decision', decisionShown && !ended);
  if (liveChanged) situationOpen = false;

  // banners: manual, pause, cancelled round
  const cancelled = v.lastRound?.status === 'abandoned' && !v.decision && !ended && !lobby;
  const held = v.decision?.status === 'held';
  const bsig = JSON.stringify([browsing, v.manual, v.phase, held, cancelled]);
  const bchanged = setSection(el.banners, bsig, () => {
    if (browsing || lobby) return [];
    const out = [];
    if (v.manual) out.push(h('div', { class: 'banner manual', role: 'note' }, icon('people', 18), h('span', { text: 'Facilitator-led discussion · phone answers are off for now' })));
    if (v.phase === 'paused') out.push(h('div', { class: 'stack' }, h('h2', { id: 'pauseH', tabindex: '-1', 'data-focus-heading': '', text: 'Discussion pause' }), held ? null : h('div', { class: 'banner pause', role: 'note' }, icon('pause', 18), h('span', { text: 'Paused · the facilitator will resume the room' }))));
    if (cancelled) out.push(h('div', { class: 'banner alert', role: 'note' }, icon('alert', 18), h('span', { text: C.voided })));
    if (v.phase === 'reviewing' && v.manual) out.push(h('p', { class: 'muted small', text: 'Facilitator-led discussion · phone answers are off for now' }));
    return out;
  });
  if (bchanged && cancelled) say(C.voided);

  // surface
  const showSurface = !!entry && !lobby && !(ended && !browsing);
  const ssig = JSON.stringify([showSurface, entry?.surfaceId, entry?.at, groupKey(entry), browsing, v.phase, decisionShown, wide]);
  setSection(el.surface, ssig, () => (showSurface ? buildSurface(entry, { browsing, phase: v.phase, accentGroup: browsing ? null : accentGroup, collapse: !wide && !browsing && (decisionShown || (v.phase === 'reviewing' && !!v.decision)) }) : []));

  // decision card
  if (!ended) updateDecision(v, decisionShown); else { resetDecision(); el.decision.hidden = true; }

  // room result (CASE-080)
  const rsig = JSON.stringify([browsing, v.lastResult, v.decision?.roundId, ended]);
  setSection(el.result, rsig, () => (!browsing && !ended && v.lastResult && !v.decision ? buildResult(v.lastResult) : []));

  // recap
  el.recap.hidden = !(ended && !browsing);
  setSection(el.recap, JSON.stringify([ended, browsing, v.recap]), () => (ended && !browsing ? buildRecap(v) : []));

  // timeline
  const tsig = JSON.stringify([v.timeline.map((e) => [e.surfaceId, e.at, e.timelineKind, e.manual]), live?.surfaceId, S.browseIndex]);
  const hadFocus = el.tl.contains(document.activeElement) ? document.activeElement?.dataset?.entryIndex : null;
  if (setSection(el.tl, tsig, () => buildTimeline(v)) && hadFocus) el.tl.querySelector(`button[data-entry-index="${CSS.escape(hadFocus)}"]`)?.focus({ preventScroll: true });

  // focus: never steal it from someone who is typing
  if (phaseChanged || liveChanged) {
    if (!typingNow()) {
      const a = document.activeElement;
      const lost = !a || a === document.body || !a.isConnected;
      if (lost) {
        const t = (decisionShown && el.decision.querySelector('[data-focus-heading]')) || main.querySelector('[data-focus-heading]');
        t?.focus({ preventScroll: true });
      }
    }
  }
  renderHeader();
}

// ───────────────────────── surfaces, results, timeline, lobby ─────────────────────────
function buildSurface(entry, { browsing, phase, collapse, accentGroup = null }) {
  const parts = [];
  if (entry.manual) parts.push(h('div', { class: 'banner manual', role: 'note' }, icon('people', 18), h('span', { text: 'Facilitator-led discussion' })));
  const heading = h('h2', { id: 'surfH', tabindex: '-1', 'data-focus-heading': browsing || !collapse ? '' : null, text: entry.title });
  const obs = entry.observations?.length ? buildVitals(entry.observations) : null;
  const tile = (title, items) => (items?.length ? h('section', { class: 'card tile', 'aria-label': title }, h('p', { class: 'eyebrow', text: title }), h('ul', { class: 'points' }, items.map((t) => h('li', { text: t })))) : null);
  const findings = tile('Findings', entry.points);
  const inv = tile('Investigations', entry.investigations);
  const accent = (node, group) => { if (node && accentGroup === group) node.classList.add('presentation-new-group'); return node; };
  accent(obs, 'observations'); accent(findings, 'findings'); accent(inv, 'investigations');
  if (collapse) {
    // A decision is open: the situation folds away under the decision (it is one tap away).
    parts.push(h('details', { class: 'ctx', open: situationOpen ? '' : null }, h('summary', {}, icon('eye', 16), h('span', { text: `Situation: ${entry.title}` })), h('div', { class: 'inner' }, entry.scene ? h('p', { class: 'small', text: entry.scene }) : null, obs, findings, inv)));
  } else {
    // One scene card (CASE-116), then the bento tiles (CASE-117), stacked.
    parts.push(accent(h('section', { class: 'card scene', 'data-kind': entry.timelineKind ?? 'live', 'aria-labelledby': 'surfH' }, heading, entry.scene ? h('p', { class: 'prose', text: entry.scene }) : null,
      phase === 'teaching' && !browsing ? h('p', { class: 'banner info', text: 'Read this, then discuss with the room' }) : null), 'scene'), obs, findings, inv);
  }
  return parts.filter(Boolean);
}

/** Vitals (CASE-090): label, value and unit, then the arrow and the value the room last saw. Arrow = direction only, never a good/bad colour. */
function buildVitals(list) {
  const fmt = (o) => `${o.label} ${o.value}${o.unit ? (/^[%°]/.test(o.unit) ? '' : ' ') + o.unit : ''}`;
  return h('ul', { class: 'vitals', 'aria-label': 'Observations' }, list.map((o) => {
    const arrow = o.trend === 'up' ? '↑' : o.trend === 'down' ? '↓' : null;
    const spoken = arrow ? `${fmt(o)}, ${o.trend} from ${o.previous}` : fmt(o);
    return h('li', {},
      h('span', { class: 'vl', 'aria-hidden': 'true', text: o.label }),
      h('span', { class: 'vv', 'aria-hidden': 'true' }, String(o.value ?? ''), o.unit ? h('span', { class: 'vu', text: o.unit }) : null),
      arrow ? h('span', { class: 'arrow', 'aria-hidden': 'true', text: `${arrow} ${o.previous}` }) : null,
      h('span', { class: 'sr-only', text: spoken }));
  }));
}

// Option marks by position in the one authored order (CASE-088). Recap rounds carry `optionIds`;
// the remembered lists are a fallback for older snapshots.
const seenOptions = new Map();
function rememberOptions(decisionId, ids) { if (decisionId && ids?.length) seenOptions.set(decisionId, ids); }

function buildResult(r) {
  // Room-result copy (CASE-080, CASE-104): a tie reads as a split; multi-select and ranking say what
  // was counted; a free-text answer is never shown back or counted (CASE-105).
  rememberOptions(r.decisionId, r.counts.map((c) => c.optionId));
  const mine = (r.yourOptionIds ?? []).map((id) => r.counts.findIndex((c) => c.optionId === id)).filter((i) => i >= 0);
  const first = mine.length ? r.counts[mine[0]] : null;
  let line;
  if (!r.countMeaning) line = r.youAnswered ? 'Your answer went to the facilitator only' : 'You did not answer this one';
  else if (!r.yourAnswer) line = r.total ? 'You did not answer this one' : 'No one answered this one';
  else if (r.countMeaning === 'selected') line = `You selected ${r.yourAnswer} · ${r.total} answered`;
  else if (r.countMeaning === 'ranked_first') line = first ? `You ranked ${first.label} first · ${first.count} of ${r.total} did the same` : `You ranked ${r.yourAnswer}`;
  else line = first ? `You chose ${r.yourAnswer} · ${first.count} of ${r.total} chose the same` : `You chose ${r.yourAnswer} · ${r.total} answered`;
  const how = !r.total ? 'The facilitator chose the route' : r.split ? 'The room was split · The facilitator chose the route' : HOW_CHOSEN[r.howChosen] ?? '';
  const marks = r.countMeaning === 'ranked_first' ? mine.slice(0, 1) : mine;
  const ranking = r.rankCount && r.counts.every(row => Array.isArray(row.positionCounts))
    ? responseSummary({ ...r, type: 'ranking' }).rows : [];
  return h('section', { class: 'result', 'aria-label': 'Room result' },
    h('p', { class: 'eyebrow', text: 'Room result' }),
    h('p', { class: 'chose' }, marks.length ? h('span', { class: 'mk-wrap' }, marks.map((i) => markSvg(i, { size: 28, decorative: false }))) : null, h('span', { text: line })),
    h('p', { class: 'small muted', text: how }),
    ranking.length ? h('ul', { class: 'ranking-result', 'aria-label': 'Counts by ranking position' }, ranking.map(row =>
      h('li', {}, h('strong', { text: row.label }), h('ul', {}, row.positions.map(position => h('li', { text: position.words })))))) : null);
}

function buildTimeline(v) {
  const tl = v.timeline;
  if (!tl.length) return [];
  const label = (e, index) => (index === tl.length - 1 ? 'Live' : e.timelineKind === 'consequence' ? 'Shared consequence' : e.timelineKind === 'terminal' ? 'Teaching point' : 'Earlier');
  return [
    h('h3', { id: 'tlh', text: 'Timeline' }),
    h('ul', { class: 'strip', 'aria-label': 'Swipe through shared material' }, tl.map((e, i) => {
      const isLive = i === tl.length - 1;
      const current = isLive ? S.browseIndex === null : S.browseIndex === i;
      return h('li', {}, h('button', {
        type: 'button', 'data-entry-index': String(i), 'aria-current': current ? 'true' : null,
        onclick: () => { S.browseIndex = isLive ? null : i; updateRoom(); scrollTo({ top: 0 }); },
      }, h('span', { class: 'n', text: `${i + 1} · ${label(e, i)}${e.manual ? ' · Facilitator-led discussion' : ''}` }), h('span', { class: 't', text: e.title })));
    })),
  ];
}
$('liveBtn').addEventListener('click', () => { S.browseIndex = null; updateRoom(); scrollTo({ top: 0 }); $('main').querySelector('[data-focus-heading]')?.focus({ preventScroll: true }); });

function updateLobby(v) {
  if (!el.lobby._built) {
    el.lobby._built = true;
    el.lobby._line = h('p', { id: 'lobbyLine', class: 'nm' });
    el.lobby._av = h('span');
    el.lobby._rename = buildRename('lobby');
    // Full-splash case art around an opaque status panel (card 36a). The descriptor is the one the participant view
    // already carries (`art`, CASE-164); missing or invalid art draws the brand braid. No case title is added.
    el.lobby._art = h('div', { class: 'splash-art', 'data-splash-art': '', 'aria-hidden': 'true' });
    el.lobby.append(el.lobby._art, h('div', { class: 'card splash-panel' },
      h('h1', { id: 'lobbyH', tabindex: '-1', 'data-focus-heading': '', text: 'Waiting to start' }),
      h('p', { class: 'muted small', text: 'The case starts when the facilitator is ready. Keep this page open.' }),
      h('div', { class: 'preview' }, el.lobby._av, el.lobby._line),
      h('details', { class: 'ctx' }, h('summary', {}, h('span', { text: 'Change name or avatar' })), h('div', { class: 'inner' }, el.lobby._rename.root))));
    void paintSplash(el.lobby._art, { art: v.art ?? null, group: v.tint ?? 'neutral', aspect: 0.5, focus: [0.04, 0.36, 0.96, 0.96] });
  }
  const t = v.you.name ? `You're in as ${v.you.name}` : "You're in";
  if (el.lobby._line.textContent !== t) el.lobby._line.textContent = t;
  const k = `${v.you.avatarId}|${v.you.name}`;
  if (el.lobby._av.dataset.k !== k) { el.lobby._av.dataset.k = k; el.lobby._av.replaceChildren(avatarEl(v.you.avatarId, { size: 40, name: v.you.name })); }
  el.lobby._rename.sync();
}

// ───────────────────────── recap ─────────────────────────
function recapMarks(d) {
  const ids = d.optionIds ?? seenOptions.get(d.decisionId);
  const r = d.yourResponse;
  const mine = r?.option_id ? [r.option_id] : r?.option_ids ?? [];
  const idxs = ids ? mine.map((id) => ids.indexOf(id)).filter((i) => i >= 0) : [];
  return idxs.length ? h('span', { class: 'mk-wrap' }, idxs.map((i) => markSvg(i, { size: 26, decorative: false }))) : null;
}

/** Paint the recap cover from the lazy splash chunk; a failed load leaves the canvas empty (decorative). */
async function paintCover(canvas, art, group) {
  let chunk;
  try { chunk = await import('./splash.mjs'); } catch { return; }
  if (!disposed && canvas.isConnected) chunk.paintCaseCover(canvas, art, { size: 72, group });
}

function buildRecap(v) {
  const r = v.recap;
  if (!r) return [h('h2', { id: 'recH', tabindex: '-1', 'data-focus-heading': '', text: 'Your private recap' }), h('p', { class: 'muted', text: 'No recap is available for this phone.' })];
  const exp = r.expiresAt ? new Date(r.expiresAt) : null;
  const when = exp && !Number.isNaN(+exp) ? exp.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : null;
  // A 72 px canvas cover beside the heading: the room's descriptor from this same view (brand braid if it does not validate).
  const cover = h('canvas', { class: 'recap-cover', width: 1, height: 1 });
  void paintCover(cover, v.art ?? null, v.tint ?? 'neutral');
  const out = [
    // Print only: the page header for the paper copy (CASE, the title, the case title). Hidden on screen.
    h('div', { class: 'print-head' }, h('strong', { text: 'CASE' }), h('span', { text: 'Your private recap' }), h('span', { text: r.caseTitle })),
    h('div', { class: 'recap-head' }, cover, h('div', { class: 'recap-title' },
      h('h2', { id: 'recH', tabindex: '-1', 'data-focus-heading': '', text: 'Your private recap' }),
      h('p', { class: 'muted small', text: r.caseTitle }))),
    // The scope of the expiry: this phone, online access, and what a downloaded copy is.
    when
      ? (() => { const p = h('p'); p.append(document.createTextNode('Only this phone can see this. Online access ends '), h('strong', { text: when }), document.createTextNode("; clearing this browser's data ends it sooner.")); return p; })()
      : h('p', { text: "Only this phone can see this. Online access ends when the recap expires; clearing this browser's data ends it sooner." }),
    h('p', { class: 'small muted', text: 'A downloaded PDF is your own copy and does not expire.' }),
    h('div', { class: 'noprint recap-actions' }, h('button', { type: 'button', class: 'btn primary block', onclick: () => window.print(), text: 'Download recap (PDF)' }), h('button', { type: 'button', class: 'btn block', onclick: () => window.print(), text: 'Print recap' })),
    h('h3', { text: 'Your decisions' }),
  ];
  if (!r.rounds.length) out.push(h('p', { class: 'muted', text: 'No decisions were recorded in this room.' }));
  for (const d of r.rounds) {
    out.push(h('article', { class: 'recap-round' },
      h('h4', { text: d.prompt }),
      h('p', { class: 'small muted', text: `Round ${d.roundNo}` }),
      h('p', { class: 'chose' }, recapMarks(d), h('span', { text: d.yourAnswer ? `Your answer: ${d.yourAnswer}` : 'No answer' })),
      d.yourClassification ? h('p', { class: 'cls' }, icon(d.yourClassification, 18), CLASS_LABEL[d.yourClassification] ?? d.yourClassification) : null,
      d.why ? h('p', { text: `Why: ${d.why}` }) : null,
      d.doDifferently ? h('p', { text: d.doDifferently }) : null,
      d.teamChoice ? h('p', { text: `The room: ${TEAM_CHOICE[d.teamChoice] ?? d.teamChoice}` }) : null,
      d.whatHappened ? h('p', { text: `What happened: ${d.whatHappened}` }) : null));
  }
  if (r.teamPath?.length) out.push(h('h3', { text: 'The route the room took' }), h('ol', { class: 'plain' }, r.teamPath.map((t) => h('li', { text: t }))));
  out.push(h('h3', { text: 'Key learning points' }), r.learningPoints?.length ? h('ul', { class: 'plain' }, r.learningPoints.map((t) => h('li', { text: t }))) : h('p', { class: 'muted', text: 'None recorded.' }));
  return out;
}

// ───────────────────────── decision card + answer lifecycle ─────────────────────────
const dec = { ver: 0, roundId: null, layout: null, draft: null, pend: null, accepted: null, msg: null, locked: false, refs: null };

function resetDecision() {
  dec.ver++;
  dec.roundId = null; dec.layout = null; dec.draft = null; dec.pend = null; dec.accepted = null; dec.msg = null; dec.locked = false; dec.refs = null;
  if (el.decision) { el.decision.replaceChildren(); }
}
const ok = (text) => ({ kind: 'ok', text });
const alertMsg = (text) => ({ kind: 'alert', text });

function optionsOf(d) { return d.interaction.options; }
function enabledOptions(d) { return optionsOf(d).filter((o) => !o.disabled && !o.explored); }
function labelOfResponse(d, resp) {
  if (!resp) return null;
  const l = (id) => optionsOf(d).find((o) => o.id === id)?.label ?? id;
  if (resp.option_id) return l(resp.option_id);
  if (resp.option_ids) return resp.option_ids.map(l).join(', ');
  if (resp.order) return resp.order.map(l).join(' → ');
  return resp.text ?? null;
}
function draftFrom(d, resp) {
  const t = d.interaction.type;
  const en = new Set(enabledOptions(d).map((o) => o.id));
  if (t === 'single_choice') return { option_id: resp?.option_id && en.has(resp.option_id) ? resp.option_id : null };
  if (t === 'multi_select') return { option_ids: (resp?.option_ids ?? []).filter((x) => en.has(x)) };
  if (t === 'ranking') {
    if (resp?.order) return { order: resp.order.filter((x) => en.has(x)) };
    return { order: d.interaction.rankCount ? [] : enabledOptions(d).map((o) => o.id) };
  }
  return { text: resp?.text ?? '' };
}
function responseFromDraft(d) {
  const t = d.interaction.type;
  if (t === 'single_choice') return dec.draft.option_id ? { option_id: dec.draft.option_id } : null;
  if (t === 'multi_select') return dec.draft.option_ids.length ? { option_ids: [...dec.draft.option_ids] } : null;
  if (t === 'ranking') {
    const need = d.interaction.rankCount ?? enabledOptions(d).length;
    return dec.draft.order.length === need && need > 0 ? { order: [...dec.draft.order] } : null;
  }
  const text = clean(dec.draft.text);
  return text && text.length <= (d.interaction.maxLength ?? 280) ? { text } : null;
}
function sameResponse(a, b) {
  if (!a || !b) return false;
  const norm = (r) => (r.option_ids ? { option_ids: [...r.option_ids].sort() } : r);
  return JSON.stringify(norm(a)) === JSON.stringify(norm(b));
}
function savedOf(d) { return dec.accepted?.roundId === d.roundId ? dec.accepted.response : d.yourResponse; }

function updateDecision(v, show) {
  const d = v.decision;
  if (!d) { if (dec.roundId) resetDecision(); el.decision.hidden = true; return; }
  rememberOptions(d.decisionId, optionsOf(d).map((o) => o.id));
  if (d.roundId !== dec.roundId) {
    resetDecision();
    dec.roundId = d.roundId;
    dec.draft = draftFrom(d, d.yourResponse);
    if (d.yourResponse) dec.msg = ok(C.saved);
  }
  el.decision.hidden = !show;
  reconcilePending(v);
  const layout = d.status === 'locked' || dec.locked ? 'locked' : 'edit';
  if (layout !== dec.layout || !dec.refs) { dec.layout = layout; buildCard(d, layout); }
  refreshCard(d);
}
function refreshDecision() {
  if(disposed)return; if (S.view?.decision && dec.refs) { reconcilePending(S.view); refreshCard(S.view.decision); } }

function buildCard(d, layout) {
  const box = el.decision;
  const refs = { type: d.interaction.type };
  dec.refs = refs;
  const heading = d.roundNo > 1 ? `Responses reopened · round ${d.roundNo}` : 'Team decision';
  refs.rcpt = h('div', { class: 'rcpt', role: 'status', 'aria-live': 'polite' }, h('span', { class: 'ic' }), h('span', { class: 't' }));
  refs.rcptAlert = h('div', { class: 'rcpt alert', role: 'alert' }, h('span', { class: 'ic' }, icon('alert', 16)), h('span', { class: 't' }));
  const receipts = h('div', { class: 'receipts' }, refs.rcpt, refs.rcptAlert);
  refs.timer = h('p', { class: 'timer-line' });
  box.classList.add('decision');
  box.dataset.phase = layout === 'locked' ? 'locked' : 'open';
  const hEl = h('h2', { id: 'decH', class: 'eyebrow', tabindex: '-1', 'data-focus-heading': '', text: layout === 'locked' ? 'Team decision' : heading });

  if (layout === 'locked') {
    refs.saved = h('p', { class: 'saved-line' });
    box.replaceChildren(hEl, h('p', { class: 'held-prompt', text: d.prompt }),
      h('div', { class: 'banner pause', role: 'note' }, icon('lock', 18), h('span', { text: 'Voting locked · Awaiting the next shared surface' })),
      refs.saved, receipts);
    return;
  }

  const t = d.interaction.type;
  const fs = h('fieldset', {}, h('legend', { id: 'promptL', text: d.prompt }));
  refs.fs = fs;
  const hintTxt = t === 'multi_select' ? 'Choose all that apply' : t === 'ranking' ? `Rank ${d.interaction.rankCount ?? enabledOptions(d).length} options` : null;
  if (hintTxt) fs.append(h('p', { class: 'hint', id: 'hintP', text: hintTxt }));
  if (t === 'single_choice' || t === 'multi_select') fs.append(buildChoiceList(d, t));
  else if (t === 'ranking') { refs.rankMount = h('div'); fs.append(refs.rankMount); refs.live = h('p', { class: 'sr-only-live', role: 'status', 'aria-live': 'polite' }); fs.append(refs.live); renderRanking(d); }
  else fs.append(buildFreeText(d));

  refs.saved = h('p', { class: 'saved-line' });
  refs.hint = h('p', { class: 'small muted', id: 'sendHint' });
  refs.send = h('button', { type: 'button', class: 'btn primary block', 'aria-describedby': 'sendHint', onclick: onSend });
  box.replaceChildren(hEl, refs.timer, fs, refs.saved, receipts, refs.send, refs.hint);
}

function optionRow(o, i, input, multi) {
  const locked = o.disabled || o.explored;
  const tag = o.explored ? h('span', { class: 'tag' }, icon('lock', 12), 'Explored') : o.disabled ? h('span', { class: 'tag' }, icon('lock', 12), 'Not available') : null;
  const row = h('label', { class: `opt opt-tile${locked ? ' locked' : ''}${multi ? ' multi' : ''}` }, input,
    h('span', { class: 'mk' }, markSvg(i, { size: 36, decorative: true })),
    h('span', { class: 'lbl' }, h('span', { class: 'sr-only', text: markFor(i).name + ': ' }), o.label),
    h('span', { class: 'ind' }, icon('check', 16)),
    tag, o.explored ? h('span', { class: 'xnote', text: 'The room has already seen where this leads' }) : null);
  row.style.setProperty('--mk', markFor(i).fill);
  return row;
}
function buildChoiceList(d, t) {
  const list = h('div', { class: 'opts' });
  const name = `o-${d.roundId}`;
  for (const [i, o] of optionsOf(d).entries()) {
    const locked = o.disabled || o.explored;
    const input = h('input', { type: t === 'single_choice' ? 'radio' : 'checkbox', name, value: o.id, disabled: locked ? '' : null });
    if (!locked) {
      input.checked = t === 'single_choice' ? dec.draft.option_id === o.id : dec.draft.option_ids.includes(o.id);
      input.addEventListener('change', () => {
        if (t === 'single_choice') dec.draft.option_id = o.id;
        else dec.draft.option_ids = input.checked ? [...dec.draft.option_ids, o.id] : dec.draft.option_ids.filter((x) => x !== o.id);
        refreshCard(S.view.decision);
      });
    }
    list.append(optionRow(o, i, input, t === 'multi_select'));
  }
  return list;
}
function buildFreeText(d) {
  const max = d.interaction.maxLength ?? 280;
  const ta = h('textarea', { id: 'ftext', maxlength: String(max), 'aria-labelledby': 'promptL', 'aria-describedby': 'fcount', autocomplete: 'off', rows: '4' });
  ta.value = dec.draft.text;
  const count = h('p', { class: 'counter', id: 'fcount', text: `${ta.value.length} of ${max}` });
  ta.addEventListener('input', () => { dec.draft.text = ta.value; count.textContent = `${ta.value.length} of ${max}`; refreshCard(S.view.decision); });
  const warn = idWarn(ta, 'ftext-warn');
  warn.upd();
  return h('div', {}, ta, count, warn.p);
}

function renderRanking(d, focus) {
  const refs = dec.refs;
  const need = d.interaction.rankCount;
  const byId = new Map(optionsOf(d).map((o) => [o.id, o]));
  const idxOf = new Map(optionsOf(d).map((o, k) => [o.id, k]));
  const mkOf = (id) => h('span', { class: 'mk' }, markSvg(idxOf.get(id), { size: 32, decorative: true }));
  const order = dec.draft.order;
  const mount = refs.rankMount;
  const list = order.length ? h('ol', { class: 'rank', 'aria-label': 'Your ranking' }, order.map((id, i) => {
    const o = byId.get(id);
    const mv = (delta, verb) => rankingMoveControl({id, label:o.label, direction:verb,
      disabled:(delta < 0 && i === 0) || (delta > 0 && i === order.length - 1),
      onMove:() => { const j = i + delta; [order[i], order[j]] = [order[j], order[i]]; refs.live.textContent = `${o.label} moved to position ${j + 1} of ${order.length}`; renderRanking(d, { id, verb }); refreshCard(S.view.decision); },
    });
    const li = h('li', {}, h('div', { class: 'top-row' }, h('span', { class: 'pos', 'aria-hidden': 'true', text: String(i + 1) }), mkOf(id), h('span', { class: 'lbl wrap-anywhere' }, h('span', { class: 'sr-only', text: markFor(idxOf.get(id)).name + ': ' }), `${i + 1}. ${o.label}`)),
      h('div', { class: 'row-btns' }, mv(-1, 'up'), mv(1, 'down'),
        need ? rankingRemoveControl({label:o.label,onRemove:() => { dec.draft.order = order.filter((x) => x !== id); refs.live.textContent = `${o.label} removed from your ranking`; renderRanking(d); refreshCard(S.view.decision); }}) : null));
    li.style.setProperty('--mk', markFor(idxOf.get(id)).fill);
    return li;
  })) : h('p', { class: 'empty-rank', text: `Add ${need} options below, then put them in order.` });
  const pool = optionsOf(d).filter((o) => !order.includes(o.id) && (need || o.disabled || o.explored));
  const avail = pool.length ? h('ul', { class: 'avail', 'aria-label': need ? 'Options you can add' : 'Not available' }, pool.map((o) => {
    const locked = o.disabled || o.explored;
    const li = h('li', { class: locked ? 'locked' : '' },
      mkOf(o.id),
      h('span', { class: 'lbl wrap-anywhere' }, h('span', { class: 'sr-only', text: markFor(idxOf.get(o.id)).name + ': ' }), o.label, o.explored ? h('span', { class: 'xnote block-note', text: 'The room has already seen where this leads' }) : null),
      locked ? h('span', { class: 'tag' }, icon('lock', 12), o.explored ? 'Explored' : 'Not available')
        : h('button', { type: 'button', class: 'btn small', 'aria-label': `Add to ranking: ${o.label}`, text: 'Add', disabled: order.length >= need ? '' : null,
          onclick: () => { dec.draft.order = [...order, o.id]; refs.live.textContent = `${o.label} added at position ${order.length + 1} of ${need}`; renderRanking(d); refreshCard(S.view.decision); } }));
    li.style.setProperty('--mk', markFor(idxOf.get(o.id)).fill);
    return li;
  })) : null;
  mount.replaceChildren(list, avail);
  if (focus) {
    const btn = mount.querySelector(`button[data-id="${CSS.escape(focus.id)}"][data-act="${focus.verb}"]:not(:disabled)`) || mount.querySelector(`button[data-id="${CSS.escape(focus.id)}"]:not(:disabled)`);
    btn?.focus({ preventScroll: true });
  }
}

function currentMsg(d) {
  const p = dec.pend;
  if (p) {
    if (p.state === 'held') return { kind: 'pause', text: C.held };
    if (p.state === 'refetch') return { kind: 'info', text: C.updating };
    if (p.state === 'waiting' || S.conn !== 'online') return { kind: 'info', text: C.waiting, spin: true };
    return { kind: 'info', text: C.sending, spin: true };
  }
  if (d.status === 'held') return { kind: 'pause', text: C.held };
  if (dec.layout === 'locked' && dec.msg?.kind !== 'alert') return null;
  return dec.msg;
}

function refreshCard(d) {
  const refs = dec.refs;
  if (!refs) return;
  const saved = savedOf(d);
  const savedLabel = labelOfResponse(d, saved);
  const m = currentMsg(d);
  // receipt regions: status vs alert, text only
  const useAlert = m?.kind === 'alert';
  const rc = refs.rcpt, ra = refs.rcptAlert;
  const setText = (box, text, kind, spin) => {
    const t = box.querySelector('.t');
    if (t.textContent !== (text ?? '')) t.textContent = text ?? '';
    box.className = `rcpt ${kind ?? ''}`.trim();
    const ic = box.querySelector('.ic');
    const want = !text ? '' : kind === 'ok' ? 'check' : kind === 'pause' ? 'pause' : spin ? 'spinner' : 'info';
    if (box !== ra && ic.dataset.k !== want) { ic.dataset.k = want; ic.replaceChildren(...(want ? [icon(want, 16, want === 'spinner' ? 'spin' : '')] : [])); }
  };
  if (useAlert) { setText(rc, '', ''); setText(ra, m.text, 'alert'); }
  else { setText(ra, '', 'alert'); setText(rc, m?.text ?? '', m?.kind ?? '', m?.spin); }

  if (dec.layout === 'locked') {
    refs.saved.textContent = savedLabel ? `Your answer (locked): ${savedLabel}` : 'No answer recorded from this phone';
  } else {
    refs.saved.textContent = savedLabel ? `Your answer: ${savedLabel}` : '';
    const held = d.status === 'held';
    refs.fs.disabled = held;
    const online = S.conn === 'online';
    const draftResp = responseFromDraft(d);
    const sending = !!dec.pend;
    const unchanged = !!saved && sameResponse(draftResp, saved) || !!dec.pend && sameResponse(draftResp, dec.pend.response);
    const btn = refs.send;
    btn.replaceChildren();
    const inFlight = enqueuing || sending && dec.pend.state === 'sending' && online;
    if (inFlight) { btn.append(icon('spinner', 18, 'spin'), document.createTextNode(' Sending…')); btn.setAttribute('aria-busy', 'true'); }
    else { btn.append(document.createTextNode(saved ? 'Change answer' : 'Send answer')); btn.removeAttribute('aria-busy'); }
    btn.disabled = inFlight || held || !draftResp || unchanged;
    let hint = '';
    if (!online) hint = 'Your answer will be kept on this phone and sent when the connection returns';
    else if (!draftResp && refs.type === 'ranking') hint = `Rank exactly ${d.interaction.rankCount ?? enabledOptions(d).length} options to send`;
    else if (!draftResp && refs.type === 'multi_select') hint = 'Choose at least one option to send';
    else if (!draftResp && refs.type === 'single_choice') hint = 'Choose an option to send';
    else if (!draftResp) hint = 'Write an answer to send';
    if (refs.hint.textContent !== hint) refs.hint.textContent = hint;
  }
  renderTimer();
}

async function onSend() {
  const d = S.view?.decision;
  if (!d || d.status !== 'open' || S.view.manual || enqueuing || dec.pend?.state === 'sending' && S.conn === 'online') return;
  const response = responseFromDraft(d);
  if (!response) return;
  enqueuing = true; dec.ver++; refreshDecision();
  try {
    await binding;
    if (!outbox || disposed || S.view?.decision?.roundId !== d.roundId) return;
    const body = await outbox.enqueue({ roundId: d.roundId, epoch: S.snap?.epoch ?? 0, response });
    if (disposed) return;
    if (S.view?.decision?.roundId !== d.roundId) { await voteStore.update(link.sessionId, rows => ({ rows: rows.filter(row => row.envelope.clientEventId !== body.clientEventId), result: null })); return; }
    dec.ver++; dec.pend = { roundId: d.roundId, body, response, state: S.conn === 'online' ? 'sending' : 'waiting' };
    dec.msg = null; await updateUnsent(); dispatchPending(dec.pend);
  } catch { if (disposed) return; dec.msg = alertMsg('Answer not queued · storage is unavailable or the queue is full'); }
  finally { enqueuing = false; if (!disposed) refreshDecision(); }
}
function dispatchPending(p) {
  if (!p || disposed || !outbox || S.conn !== 'online' || S.view?.manual || S.view?.decision?.status !== 'open') return;
  p.state = 'sending'; refreshDecision();
  void settlePhoneDelivery({flush:()=>outbox.flush(),current:()=>!disposed,
    failed:()=>{if(dec.pend!==p)return;p.state='waiting';dec.msg=alertMsg('Answer storage unavailable · keep this page open');},
    settled:()=>{void updateUnsent();refreshDecision();}});
}
function resend(p) {
  if (!outbox || disposed) return;
  outbox.setEpoch(S.snap?.epoch ?? p.body.epoch).then(() => dispatchPending(p)).catch(() => { if (disposed) return; dec.msg = alertMsg('Answer storage unavailable · keep this page open'); refreshDecision(); });
}

function onReceipt(p, rb) {
  if (disposed || dec.pend !== p) return; // dropped (round changed) or superseded
  dec.ver++;
  const d = S.view?.decision;
  switch (rb.receipt) {
    case 'accepted': case 'already_accepted':
      dec.pend = null;
      dec.accepted = { roundId: p.roundId, response: p.response, clientEventId: p.body.clientEventId };
      dec.msg = ok(rb.receipt === 'accepted' ? C.saved : C.savedDup);
      break;
    case 'locked': {
      dec.pend = null; dec.locked = true;
      const had = d ? savedOf(d) : null;
      dec.msg = alertMsg(had ? C.lockedSaved : C.lockedNone);
      break;
    }
    case 'paused_held':
      p.state = 'held'; // keep the same clientEventId; resent when decision.status returns to open
      break;
    case 'stale_epoch':
      p.state = 'refetch';
      link.refetch(); // fresh snapshot, then reconcilePending resends under the new epoch
      setTimeout(() => { if (dec.pend === p && p.state === 'refetch') reconcilePending(S.view, true); }, 3000);
      break;
    case 'rejected': {
      dec.pend = null;
      const r = rb.reason;
      if (r === 'round_voided') dec.msg = alertMsg(C.voided);
      else if (r === 'manual_room') dec.msg = alertMsg(C.manualRoom);
      else if (r === 'unknown_participant') { void terminate('removed'); return; }
      else if (r === 'room_ended') dec.msg = alertMsg(C.ended);
      else dec.msg = alertMsg(C.rejected); // client_event_id_reused, bad_response, unknown_round: the snapshot refetch follows
      break;
    }
    case 'timeout':
      p.state = 'waiting'; // bus gave up after MAX_TRIES: say so, keep the answer, retry with the same id
      setTimeout(() => { if (dec.pend === p && p.state === 'waiting') dispatchPending(p); }, 1000);
      break;
    default:
      dec.pend = null; dec.msg = alertMsg(C.rejected);
  }
  if (S.mode === 'room') { reconcilePending(S.view); refreshDecision(); }
}

function reconcilePending(v, force = false) {
  const p = dec.pend;
  if (!p || !v) return;
  const d = v.decision;
  if (!d || d.roundId !== p.roundId) { dec.ver++; dec.pend = null; return; }
  if (d.status === 'locked') { // the round locked while the answer was held or in flight
    if (p.state !== 'sending') { dec.ver++; dec.pend = null; dec.msg = alertMsg(savedOf(d) ? C.lockedSaved : C.lockedNone); }
    return;
  }
  if (p.state === 'held' && d.status === 'open') { resend(p); return; }
  if (p.state === 'refetch' && S.snap) {
    if (S.snap.epoch !== p.body.epoch || force) {
      if (d.status === 'open') resend(p); else p.state = 'held';
    }
  }
}

// ───────────────────────── advisory timer (text only, no pulse, polite at 60 / 10 / 0) ─────────────────────────
// ONE rounding with the console and the projector (src/shared/timer.mjs; walkthrough bug 3).
const announced = new Set();
function renderTimer() {
  const refs = dec.refs, v = S.view;
  if (!refs?.timer) return;
  const t = v?.decision && v.timer;
  if (!t) { refs.timer.textContent = ''; return; }
  const r = timerRemainingS(t, Date.now());
  const text = timerWords(r);
  if (refs.timer.textContent !== text) refs.timer.textContent = text;
  if (!t.paused) {
    for (const th of TIMER_ANNOUNCE_AT) {
      const k = `${v.decision.roundId}:${t.endsAt}:${th}`;
      if (r <= th && !announced.has(k)) {
        // Only announce a threshold while it is current (a late joiner does not hear the ones already passed).
        announced.add(k);
        const next = th === 60 ? 10 : th === 10 ? 0 : -1;
        if (r > next) say(text);
      }
    }
  }
}
setInterval(() => { if (S.mode === 'room') renderTimer(); }, 1000);

// ───────────────────────── go ─────────────────────────
render();
const clearMemory = () => {
  disposed = true;
  stopSplashes();
  for(const challenge of challenges)challenge.close();challenges.clear();
  for (const remove of listeners) remove();
  for (const id of timeouts) globalThis.clearTimeout(id);
  for (const id of intervals) globalThis.clearInterval(id);
  link.dropPending(); link.close(); outbox?.close(); outbox=null;outboxOwner=null;voteStore.close().catch(() => {});
  S.view = null; S.snap = null; dec.draft = null; dec.pend = null; dec.accepted = null; dec.refs = null; dec.msg = null; dec.roundId = null; renameCtl = null; seenOptions.clear(); announced.clear(); S.browseIndex = null; S.liveKey = undefined; S.liveSurface = null; S.phaseKey = undefined;
  for (const key of Object.keys(el)) delete el[key];
  main.replaceChildren();
  root.replaceChildren(); document.body.classList.remove('phone-page'); document.documentElement.classList.remove('phone-page');
};
const controller = { cancel: clearMemory, get sessionId() { return link.sessionId; },
  teardown: (reason='token_loss') => terminate(reason),
};
updateUnsent();
return controller;

}
