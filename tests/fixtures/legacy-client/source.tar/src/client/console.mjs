// The facilitator document (/cases): sign-in, the case catalogue (card 29, library.mjs) and the
// facilitator room lifetime. Room rendering and its capability stay in console-room.mjs, never in web
// storage or the URL. Shared-computer approval lives in the room's Room tab (CASE-166), not here.
import { mountAccount, accountRequest, node } from './auth-ui.mjs';
import { isUuidV7, normalizeCode } from '../shared/ids.mjs';
import { mountConsoleRoom } from './console-room.mjs';
import { ConsoleManualRoom, savedManualKey } from './console-manual.mjs';
import * as roomOwnership from './console-ownership.mjs';
import { ACTIVE_ROOM_KEY } from './teardown.mjs';
import { casesUrl, localNotesObjectUrl } from '../shared/urls.mjs';
import { consolePage } from './console-pages.mjs';
import { mountSiteHeader } from './site-header.mjs';

export function mount({ magicCallback = null } = {}) {
  const main = document.querySelector('main'); main.replaceChildren();
  main.classList.add('facilitator-console');
  main.removeAttribute('aria-labelledby');
  const header = mountSiteHeader(document.body, { context: 'Cases', current: 'cases' });
  const intro = node('div', null, 'facilitator-intro');
  intro.append(node('h1', 'Facilitator sign in', 'case-catalog-heading'),
    node('p', 'Participants never need an account.', 'muted'));
  const catalog = node('section', null, 'case-catalog');
  const savedPanel = node('section', null, 'console-saved-notes');
  const status = node('p', null, 'case-catalog-status');
  status.setAttribute('role', 'status');
  const panel = node('div', null, 'auth-panel');
  panel.append(intro, status); main.append(panel, savedPanel, catalog);
  const authSplash = on => import('./splash.mjs').then(c => c.setAuthSplash(main, on)); // signed out: the brand braid behind one panel
  authSplash(true);
  let roomToken = null, generation = 0, activeRoom = null, library = null, hooks;
  // Card 38: the browser asks "Leave site?" on Back, reload or close while a room is live.
  const leave = event => { event.preventDefault(); event.returnValue = ''; };
  const live = on => on ? addEventListener('beforeunload', leave) : removeEventListener('beforeunload', leave);
  function savedSegment() {
    const key = savedManualKey();
    return key ? { key, sessionId: key.slice('case-lab:segment:'.length),
      saved: ConsoleManualRoom.saved(key.slice('case-lab:segment:'.length)) } : null;
  }
  function downloadSavedNotes() {
    const entry = savedSegment();
    if (!entry?.saved) { savedPanel.replaceChildren(); return; }
    const blob = new Blob([ConsoleManualRoom.notesFromSaved(entry.saved)], { type: 'text/plain;charset=utf-8' });
    const url = localNotesObjectUrl(blob);
    const anchor = node('a'); anchor.href = url; anchor.download = 'case-manual-notes.txt';
    anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 0);
  }
  function showSavedNotes() {
    savedPanel.replaceChildren();
    if (!savedSegment()?.saved) return;
    const download = node('button', 'Download saved manual notes', 'btn'); download.type = 'button';
    download.addEventListener('click', downloadSavedNotes);
    savedPanel.append(node('h2', 'Saved manual notes'),
      node('p', 'Notes stay on this tab. Reconnecting to the room needs a fresh sign-in and ownership check.'), download);
  }
  showSavedNotes();
  function openRoom(auth, room, restoredSaved = null) {
    if (!isUuidV7(room?.sessionId) || normalizeCode(room?.joinCode, 6) !== room.joinCode ||
        typeof room.facilitatorToken !== 'string' || !room.facilitatorToken) throw new Error('invalid_room');
    roomToken = room.facilitatorToken;
    try {
      if (activeRoom) roomOwnership.releaseRoom();
      activeRoom?.close();
      activeRoom = null;
      main.classList.remove('room-active'); document.body.classList.remove('room-active');
      activeRoom = mountConsoleRoom(catalog, { auth, sessionId: room.sessionId,
        joinCode: room.joinCode, facilitatorToken: roomToken, restoredSaved,
        onEnded({ localOnly = false, reason = null } = {}) {
          // Card 38: room end clears room state only; the facilitator stays signed in, back in the library.
          live(false); roomOwnership.releaseRoom(); activeRoom = null;
          main.classList.remove('room-active'); document.body.classList.remove('room-active');
          const endedGeneration = generation;
          void auth.teardown('room_end').then(() => {
            if (endedGeneration === generation) return hooks.onSignedIn(auth, reason === 'access_lost'
              ? 'Console access ended. The room may still be running.'
              : localOnly ? 'Local presentation ended. Check the server room is closed when online.' : '');
          }).catch(() => {});
        } });
      // Invalidate catalog requests only after the local mount has succeeded.
      // A failed prerequisite leaves the Start action and its error recoverable.
      generation++; library?.close(); library = null;
      main.classList.add('room-active'); document.body.classList.add('room-active');
      try { sessionStorage.setItem(ACTIVE_ROOM_KEY, room.sessionId); } catch {}
      void roomOwnership.holdRoom(room.sessionId);
      live(true);
    } catch (error) { roomOwnership.releaseRoom(); throw error; }
    finally { roomToken = null; }
    savedPanel.replaceChildren();
    status.textContent = 'Room ready';
  }
  const account = mountAccount(main, hooks = { magicCallback, idleText: 'Sign in to run and manage cases.',
    preserveSessionKeys: () => {
      const key = savedManualKey();
      return key ? [key] : [];
    },
    onSignedOut(reason) {
      generation++; roomToken = null; live(false); roomOwnership.releaseRoom();
      main.classList.remove('room-active', 'signed-in'); document.body.classList.remove('room-active');
      activeRoom?.close({ preserveSegment: reason === 'pagehide' }); activeRoom = null;
      library?.close(); library = null; header.setAccount(null);
      catalog.replaceChildren(); savedPanel.replaceChildren();
      status.textContent = ''; authSplash(true);
    },
    async onSignedIn(auth, notice = '') {
      const current = ++generation; authSplash(false);
      // A magic-link callback lands on the root; the catalogue's own address is /cases.
      if (location.pathname === '/') history.replaceState(null, '', casesUrl(location.origin));
      main.classList.add('signed-in');
      library?.close(); library = null;
      catalog.replaceChildren(); status.textContent = 'Loading published cases…';
      try {
        const me = await accountRequest(auth, ['me'], { query: new URLSearchParams({ limit: '20' }) });
        if (current !== generation) return;
        const firstMembershipPage = consolePage('memberships', me, null);
        header.setAccount({ email: me.account?.email ?? null, administration: me.account?.administration === true,
          signOut: () => account.signOut.click() });
        if (me.account?.email) account.status.textContent = `Signed in as ${me.account.email}`;
        // Rejoin a running room (card 38): a lazy chunk; the same tab reopens its room without a press.
        try {
          const chunk = await import('./account-session.mjs');
          if (current !== generation) return;
          await chunk.offerRejoin({ ownership: roomOwnership, panel: savedPanel, status, saved: savedSegment(),
            request: (parts, options) => accountRequest(auth, parts, options),
            open: (room, saved) => openRoom(auth, room, saved), current: () => current === generation });
        } catch { if (current === generation) status.textContent = 'Running rooms could not be checked.'; }
        if (current !== generation) return;
        status.textContent = notice || (firstMembershipPage.rows.length ? '' : 'No workspaces are assigned to this account.');
        // The catalogue is its own chunk (CASE-166), loaded once signed in.
        const { mountLibrary } = await import('./library.mjs');
        if (current !== generation) return;
        library = mountLibrary(catalog, { auth, me: { memberships: firstMembershipPage.rows },
          async onStart({ workspaceId, versionId }) {
            const room = await accountRequest(auth, ['sessions'], { method: 'POST', body: {
              workspaceId, caseVersionId: versionId, ttlMinutes: 60,
            } });
            if (current !== generation) return;
            openRoom(auth, room);
          } });
        // One page per click: workspaces are never auto-looped (console-pages.mjs).
        const moreWorkspaces = after => {
          if (!after || current !== generation) return;
          const more = node('button', 'More workspaces', 'btn tertiary library-more-workspaces'); more.type = 'button';
          more.addEventListener('click', async () => {
            more.disabled = true;
            try {
              const next = await accountRequest(auth, ['me'], { query: new URLSearchParams({ limit: '20', after }) });
              if (current !== generation) return;
              const page = consolePage('memberships', next, after);
              library?.addMemberships(page.rows); more.remove(); moreWorkspaces(page.nextAfter);
            } catch { if (current === generation) { status.textContent = 'The next workspaces could not be loaded. Try again.'; more.disabled = false; } }
          });
          catalog.querySelector('.library-title')?.append(more);
        };
        moreWorkspaces(firstMembershipPage.nextAfter);
      } catch { if (current === generation) status.textContent = 'Published cases are unavailable. Try again.'; }
    },
  });
  const form = main.querySelector('form.auth-form');
  if (form) panel.insertBefore(form, status);
}
