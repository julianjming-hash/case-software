// src/client/mosaic.mjs: paints a case's braid art from its numbers-only descriptor (card 28, CASE-164).
//
// Two outputs over one geometry core (src/shared/mosaic-geometry.mjs):
//   • covers: a canvas bitmap, cached per (renderer, structure, attempt, theme, size, group, shade seed),
//     drawn on an OffscreenCanvas where available and painted one cover per task so a library of covers
//     never holds the main thread for long;
//   • splash: SVG built node by node with createElementNS, so tiles can move (assemble, ripple, shimmer)
//     under reduced-motion and visibility guards.
// Text never enters the art: no innerHTML, no DOMParser, no labels. Covers carry only the generic
// accessible name; splash art is decorative. The descriptor arrives already validated; anything that is
// not the exact numbers-only shape paints nothing.
import { buildScene, CANONICAL, GROUPS, hash, rng } from '../shared/mosaic-geometry.mjs';
import { validArtDescriptor, structureKey, ART_LABEL } from '../shared/art-descriptor.mjs';

const SVG = 'http://www.w3.org/2000/svg';
const MIN_TILE_CSS_PX = 5.5;
const CACHE_LIMIT = 64;
const EASE = 'cubic-bezier(.2,.7,.2,1)';
const cache = new Map();

export { ART_LABEL };

/** 'light' or 'dark' for a document: an explicit data-theme wins, else the OS preference. */
export function currentTheme(doc = globalThis.document) {
  const t = doc?.documentElement?.getAttribute('data-theme');
  if (t === 'dark' || t === 'light') return t;
  return globalThis.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

/** True only when the device allows motion. */
export const motionOK = () => typeof globalThis.matchMedia === 'function' && !globalThis.matchMedia('(prefers-reduced-motion: reduce)').matches;

const groupOf = (group) => (typeof group === 'string' && Object.hasOwn(GROUPS, group) ? group : 'neutral');

/** The cover cache key: numbers and fixed keywords only (no title, no id). */
export function coverKey(art, { theme = 'light', size = 0, group = 'neutral', contentSeed = '' } = {}) {
  return [art.renderer, structureKey(art), art.attempt, art.summarised ? 1 : 0, theme === 'dark' ? 'dark' : 'light',
    Math.round(size), groupOf(group), hash(String(contentSeed))].join('|');
}

function drawScene(g, scene, px) {
  const k = px / Math.min(scene.width, scene.height);
  const ox = (px - scene.width * k) / 2, oy = (px - scene.height * k) / 2;
  g.fillStyle = scene.grout; g.fillRect(0, 0, px, px);
  g.lineJoin = 'round'; g.lineWidth = scene.groutWidth * k; g.strokeStyle = scene.grout;
  for (const sh of scene.shapes) {
    g.beginPath();
    for (let i = 0; i < sh.poly.length; i++) { const x = ox + sh.poly[i][0] * k, y = oy + sh.poly[i][1] * k; if (i) g.lineTo(x, y); else g.moveTo(x, y); }
    g.closePath(); g.fillStyle = sh.fill; g.fill(); g.stroke();
  }
}

function coverInputs(art, { cssSize = 216, dpr = globalThis.devicePixelRatio || 1, theme = 'light', group = 'neutral', contentSeed = '' } = {}) {
  const px = Math.max(1, Math.round(cssSize * dpr));
  return { px, cssSize, theme, group: groupOf(group), contentSeed: String(contentSeed), key: coverKey(art, { theme, size: px, group, contentSeed }) };
}
function cached(key) {
  const hit = cache.get(key);
  if (!hit) return null;
  cache.delete(key); cache.set(key, hit);
  return { ...hit, ms: 0, cached: true };
}
function coverScene(art, c) {
  return buildScene(art, { theme: c.theme, group: c.group, contentSeed: c.contentSeed, tile: MIN_TILE_CSS_PX * CANONICAL / Math.max(1, c.cssSize) });
}
function drawCover(scene, c) {
  let image;
  if (typeof OffscreenCanvas === 'function') {
    const off = new OffscreenCanvas(c.px, c.px);
    drawScene(off.getContext('2d'), scene, c.px);
    image = off.transferToImageBitmap();
  } else {
    image = globalThis.document.createElement('canvas');
    image.width = c.px; image.height = c.px;
    drawScene(image.getContext('2d'), scene, c.px);
  }
  const entry = { image, px: c.px };
  cache.set(c.key, entry);
  while (cache.size > CACHE_LIMIT) { const [oldest, old] = cache.entries().next().value; cache.delete(oldest); old.image.close?.(); }
  return entry;
}

/**
 * Render one cover bitmap (device pixels, square). Cached; returns { image, px, ms, cached }.
 * `cssSize` is the displayed edge in CSS px; tiles never fall below 5.5 CSS px.
 */
export function renderCover(art, opts = {}) {
  if (!validArtDescriptor(art)) return null;
  const c = coverInputs(art, opts);
  const hit = cached(c.key);
  if (hit) return hit;
  const t0 = performance.now();
  const scene = coverScene(art, c);
  if (scene.refused) return null;
  const entry = drawCover(scene, c);
  return { ...entry, ms: performance.now() - t0, cached: false };
}

function show(canvas, out) {
  canvas.setAttribute('role', 'img');
  canvas.setAttribute('aria-label', ART_LABEL);
  if (!out) { canvas.width = 1; canvas.height = 1; return null; }
  canvas.width = out.px; canvas.height = out.px;
  canvas.getContext('2d').drawImage(out.image, 0, 0);
  return out;
}

/** Paint a cover into a canvas element: generic accessible name, no visible text, never a label. */
export function paintCover(canvas, art, opts = {}) {
  const cssSize = opts.cssSize || canvas.getBoundingClientRect().width || 216;
  return show(canvas, renderCover(art, { ...opts, cssSize }));
}

const nextTask = () => new Promise((resolve) => {
  if (globalThis.scheduler?.postTask) globalThis.scheduler.postTask(resolve, { priority: 'background' });
  else setTimeout(resolve, 0);
});

/**
 * Paint many covers so input stays responsive while a library renders: each uncached cover takes two
 * short tasks (geometry, then drawing), with a yield before each.
 * @param {{canvas: HTMLCanvasElement, art: object, group?: string, contentSeed?: string}[]} items
 */
export async function paintCovers(items, opts = {}) {
  const results = [];
  const current = canvas => canvas.isConnected !== false && (!opts.isCurrent || opts.isCurrent(canvas));
  for (const item of items) {
    await nextTask();
    if (!current(item.canvas)) { results.push(null); continue; }
    if (!validArtDescriptor(item.art)) { results.push(show(item.canvas, null)); continue; }
    const cssSize = opts.cssSize || item.canvas.getBoundingClientRect().width || 216;
    const c = coverInputs(item.art, { ...opts, cssSize, group: item.group ?? opts.group, contentSeed: item.contentSeed ?? opts.contentSeed });
    const hit = cached(c.key);
    if (hit) { results.push(show(item.canvas, hit)); continue; }
    const t0 = performance.now();
    const scene = coverScene(item.art, c);
    if (scene.refused) { results.push(show(item.canvas, null)); continue; }
    const built = performance.now() - t0;
    await nextTask();
    if (!current(item.canvas)) { results.push(null); continue; }
    const t1 = performance.now();
    const entry = drawCover(scene, c);
    results.push(show(item.canvas, { ...entry, ms: built + performance.now() - t1, cached: false }));
  }
  return results;
}

/** Drop every cached bitmap (for example after a theme change). */
export function clearCoverCache() { for (const { image } of cache.values()) image.close?.(); cache.clear(); }

// ── splash ────────────────────────────────────────────────────────────────
/**
 * Build decorative SVG splash art. The stored attempt is tried at the splash aspect; if it cannot be
 * drawn there without dropping a route, the solved square cover geometry is used, scaled to fill.
 * Returns the <svg> element (aria-hidden, no text).
 */
export function buildSplash(doc, art, { aspect = 1.6, focus = null, theme = 'light', group = 'neutral', contentSeed = '' } = {}) {
  const svg = doc.createElementNS(SVG, 'svg');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  svg.setAttribute('preserveAspectRatio', 'xMidYMid slice');
  if (!validArtDescriptor(art)) { svg.setAttribute('viewBox', '0 0 1 1'); return svg; }
  const opts = { theme, group: groupOf(group), contentSeed: String(contentSeed) };
  let scene = buildScene(art, { ...opts, aspect, focus });
  if (scene.refused) { svg.setAttribute('viewBox', '0 0 1 1'); return svg; }
  if (scene.problems.length) scene = buildScene(art, opts);
  const f1 = (n) => (Math.round(n * 10) / 10).toString();
  svg.setAttribute('viewBox', `0 0 ${f1(scene.width)} ${f1(scene.height)}`);
  svg.style.display = 'block'; svg.style.width = '100%'; svg.style.height = '100%'; svg.style.background = scene.grout;
  const g = doc.createElementNS(SVG, 'g');
  g.setAttribute('stroke', scene.grout);
  g.setAttribute('stroke-width', f1(Math.max(0.6, scene.groutWidth)));
  g.setAttribute('stroke-linejoin', 'round');
  for (const sh of scene.shapes) {
    const p = doc.createElementNS(SVG, 'polygon');
    p.setAttribute('points', sh.poly.map((q) => f1(q[0]) + ',' + f1(q[1])).join(' '));
    p.setAttribute('fill', sh.fill);
    p.dataset.l = sh.l;
    p.dataset.s = sh.s.toFixed(2);
    g.append(p);
  }
  svg.append(g);
  return svg;
}

function centres(svg) {
  if (svg.__centres) return svg.__centres;
  svg.__centres = [...svg.querySelectorAll('polygon')].map((p) => {
    const nums = p.getAttribute('points').split(/[ ,]/).map(Number);
    let x = 0, y = 0; for (let i = 0; i < nums.length; i += 2) { x += nums[i]; y += nums[i + 1]; }
    return { p, x: x / (nums.length / 2), y: y / (nums.length / 2), l: p.dataset.l, s: Number(p.dataset.s || 0) };
  });
  return svg.__centres;
}

/** First paint: spine settles first, then plaits, then the ground. Motion-gated. */
export function assemble(svg) {
  if (!motionOK()) return 0;
  const r = rng('assemble');
  let n = 0;
  for (const t of centres(svg)) {
    const delay = t.l === 'm' ? 120 + t.s * 900 : t.l === 'o' ? 80 + t.s * 900 : t.l === 'b' ? 520 + t.s * 600 : r() * 520;
    const from = t.l === 'g' ? { opacity: 0 } : { opacity: 0, transform: 'scale(.35)' };
    t.p.style.transformBox = 'fill-box'; t.p.style.transformOrigin = 'center';
    t.p.animate([from, { opacity: 1, transform: 'scale(1)' }], { duration: t.l === 'g' ? 700 : 520, delay, easing: EASE, fill: 'backwards' });
    n++;
  }
  return n;
}

/** A wave from a client point (or the centre). Motion-gated. */
export function ripple(svg, x = null, y = null) {
  if (!motionOK()) return 0;
  const vb = svg.viewBox.baseVal, box = svg.getBoundingClientRect();
  const k = Math.max(box.width / vb.width, box.height / vb.height) || 1;
  const ox = (box.width - vb.width * k) / 2, oy = (box.height - vb.height * k) / 2;
  const px = x == null ? vb.width / 2 : (x - box.left - ox) / k, py = y == null ? vb.height / 2 : (y - box.top - oy) / k;
  const reach = Math.hypot(vb.width, vb.height) * 0.55, speed = reach / 820;
  let n = 0;
  for (const t of centres(svg)) {
    const d = Math.hypot(t.x - px, t.y - py); if (d > reach) continue;
    const fall = 1 - d / reach;
    t.p.style.transformBox = 'fill-box'; t.p.style.transformOrigin = 'center';
    t.p.animate([{ transform: 'scale(1)', opacity: 1 }, { transform: `scale(${(1 - 0.22 * fall).toFixed(3)})`, opacity: (1 - 0.3 * fall).toFixed(2) }, { transform: 'scale(1)', opacity: 1 }], { duration: 620, delay: d / speed, easing: EASE });
    n++;
  }
  return n;
}

/**
 * Idle shimmer: six tiles every 1.3 s, only while motion is allowed, the page is visible and the art
 * is on screen. Returns a stop function.
 */
export function shimmer(svg, { doc = globalThis.document } = {}) {
  let visible = true;
  const io = typeof IntersectionObserver === 'function' ? new IntersectionObserver((e) => { visible = e[0].isIntersecting; }) : null;
  io?.observe(svg);
  const r = rng('shimmer:' + hash(String(Date.now())));
  const tick = () => {
    if (!svg.isConnected) { stop(); return; }
    if (!motionOK() || doc.hidden || !visible) return;
    const pool = centres(svg).filter((t) => t.l === 'g' || t.l === 'o' || t.l === 'm');
    for (let i = 0; i < 6; i++) {
      const t = pool[Math.floor(r() * pool.length)]; if (!t) continue;
      t.p.animate([{ opacity: 1 }, { opacity: t.l === 'm' ? 0.72 : 0.5 }, { opacity: 1 }], { duration: 2400, easing: 'ease-in-out', delay: r() * 900 });
    }
  };
  const timer = setInterval(tick, 1300);
  function stop() { clearInterval(timer); io?.disconnect(); }
  return stop;
}

/**
 * Mount splash art into a host element (replacing its children). Motion: 'assemble' on first paint,
 * 'shimmer' while idle; both are off under prefers-reduced-motion and pause while hidden.
 * Returns { svg, ripple(x, y), stop() }.
 */
export function mountSplash(host, art, { motion = ['assemble'], ...opts } = {}) {
  const doc = host.ownerDocument;
  const svg = buildSplash(doc, art, { theme: currentTheme(doc), ...opts });
  host.replaceChildren(svg);
  // Reduced motion switched on mid-animation stops everything at once.
  const media = globalThis.matchMedia?.('(prefers-reduced-motion: reduce)');
  const halt = () => { if (media?.matches) for (const a of svg.getAnimations({ subtree: true })) a.cancel(); };
  media?.addEventListener?.('change', halt);
  if (motion.includes('assemble')) assemble(svg);
  const stopShimmer = motion.includes('shimmer') ? shimmer(svg, { doc }) : () => {};
  return {
    svg,
    ripple: (x, y) => ripple(svg, x, y),
    stop() { stopShimmer(); media?.removeEventListener?.('change', halt); for (const a of svg.getAnimations({ subtree: true })) a.cancel(); },
  };
}
