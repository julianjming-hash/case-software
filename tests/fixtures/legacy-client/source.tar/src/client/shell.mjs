import { watchUpdate } from './update.mjs';

export function serviceWorkerScriptURL(trusted = globalThis.trustedTypes) {
  if (!trusted) return '/sw.mjs';
  return trusted.createPolicy('case-default', {
    createScriptURL(value) { if (value !== '/sw.mjs') throw new TypeError('unsupported_script'); return value; },
  }).createScriptURL('/sw.mjs');
}

/** The shell writes no web-storage or IndexedDB key. Only its service worker creates shell caches. */
export async function startShell() {
  if (!globalThis.isSecureContext || !navigator.serviceWorker) return;
  try {
    let promptEvents;
    const scriptURL = serviceWorkerScriptURL();
    const registration = await navigator.serviceWorker.register(scriptURL, { scope: '/', updateViaCache: 'none' });
    watchUpdate({ registration, serviceWorker: navigator.serviceWorker, reload: () => location.reload(), offer({ accept, decline }) {
      const dialog = document.getElementById('updateDialog');
      if (!dialog) return;
      promptEvents?.abort(); promptEvents = new AbortController();
      document.getElementById('updateAccept').addEventListener('click', () => { dialog.close(); promptEvents.abort(); accept(); }, { signal: promptEvents.signal });
      document.getElementById('updateLater').addEventListener('click', () => { dialog.close(); promptEvents.abort(); decline(); }, { signal: promptEvents.signal });
      dialog.showModal();
    } });
  } catch { /* Unsupported/blocked service workers leave the online shell available. */ }
}
export function shellNotice(title) {
  document.getElementById('surfaceTitle').textContent = title;
  document.getElementById('surfaceNotice').textContent = 'This room surface is being prepared. Use the network check before your session.';
}
