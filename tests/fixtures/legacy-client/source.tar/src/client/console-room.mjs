// The facilitator's served room surface. The room capability, mirror and case
// pack remain in this closure; the local projector receives display frames only.
import { connect } from './transport.mjs';
import { keepScreenAwake } from './device.mjs';
import { primaryAction, dockControl, refusedCommandNotice } from './console-actions.mjs';
import { markFor, markSvg } from './projector-marks.mjs';
import { consolePublicSurface, presentationNav } from './presentation-nav.mjs';
import { presentationKeyAction } from './presentation-keys.mjs';
import { createDisplayCheck, createProjectorHandshake } from './console-device.mjs';
import { phaseModel } from './console-view.mjs';
import { consoleRankingRows, renderRankedControls } from './console-ranking.mjs';
import { projectorFrame, publishProjectorFrame } from './console-projection.mjs';
import { ConsoleManualRoom } from './console-manual.mjs';
import { createManualRecovery } from './console-recovery.mjs';
import { samePcProjectorUrl, joinUrl, localNotesObjectUrl } from '../shared/urls.mjs';
import { formatCode, isUuidV7, uuidv7 } from '../shared/ids.mjs';
import { cleanText } from '../shared/text.mjs';
import { timerRemainingS, timerWords } from '../shared/timer.mjs';
import { focusAfterConsoleUpdate, patchChildren, helloNeedsRender } from './console-focus.mjs';
import { observeDisplayTopology } from './console-screen.mjs';

const MAX_TEXT = 2_000;
const CLASSIFICATION = Object.freeze({
  sound: '● Sound', defensible: '◯ Defensible',
  'context-dependent': '⑂ Context-dependent', unsafe: '▲ Unsafe · recoverable',
  'terminal-unsafe': '⬣ Terminal · needs a checkpoint reset',
  'discussion-prompt': '▤ Discussion prompt',
});
function el(tag, text, className) {
  const item = document.createElement(tag);
  if (text != null) item.textContent = cleanText(text, MAX_TEXT);
  if (className) item.className = className;
  return item;
}
function button(label, action, className = 'btn') {
  const item = el('button', label, className);
  item.type = 'button';
  item.dataset.focusKey = label;
  item.onclick = action; // a property, so a kept node takes the fresh render's handler (console-focus.mjs)
  return item;
}
function section(title, className = 'console-card') {
  const item = el('section', null, className);
  item.append(el('h2', title));
  return item;
}
function addTextList(parent, items, className = '') {
  if (!items?.length) return;
  const list = el('ul', null, className);
  for (const text of items) list.append(el('li', text));
  parent.append(list);
}

// Card 36b Run columns. The Only you renderer stays in this module, which the projector and phone graphs
// never reach (tests/surface-parity-36b.test.mjs; CASE-092/093).
function column(className, heading) {
  const col = el('section', null, `console-col ${className}`), label = el('h2', heading, 'console-zone-label');
  label.id = `${className}-label`; col.setAttribute('aria-labelledby', label.id); col.append(label);
  return col;
}
/** The violet private zone: notes, the beat's cue and the media notice; null when there is none. */
function renderOnlyYou(view) {
  const notes = view.liveSurface?.notes, cue = view.beat?.cue, media = view.presentation?.mediaUnavailable;
  if (!notes && !cue && !media) return null;
  const zone = el('div', null, 'console-private');
  if (notes) zone.append(el('p', 'Private notes · not shown to the room', 'eyebrow'), el('p', notes));
  if (cue) zone.append(el('p', 'Facilitator cue · not shown to the room', 'eyebrow'), el('p', cue));
  if (media) zone.append(el('p', 'This case references media that cannot be displayed in this version.'));
  return zone;
}

// Card 37: options as the room sees them (the phone's tile, mark, mark name and authored order, CASE-088), with
// the facilitator-only route detail as Only you callouts. Rendered here only, from the facilitator projection.
const OPTION_PHASES = ['responses_open', 'responses_locked', 'path_selected'];
/** One option tile; `tail` is a numbers-only suffix (count and share, or rank counts). */
function optionTile(option, index, tail = '') {
  const tile = el('div', null, `opt-tile console-option${option.disabled || option.explored ? ' locked' : ''}`);
  tile.style.setProperty('--mk', markFor(index).fill);
  tile.append(markSvg(index, { size: 36, decorative: true }), el('span', `${markFor(index).name}: `, 'sr-only'), el('span', option.label, 'lbl'));
  if (tail) { const count = document.createElement('span'); count.className = 'console-option-count'; count.textContent = tail; tile.append(count); }
  if (option.explored) tile.append(el('span', 'Explored', 'tag'));
  else if (option.disabled) tile.append(el('span', 'Not available', 'tag'));
  return tile;
}
const routeLine = path => `${path.label} · ${CLASSIFICATION[path.classification] ?? '◇ Authored route'}${path.recommended ? ' · Recommended' : ''}`;
function routeCallout(paths) {
  if (!paths.length) return null;
  const callout = el('div', null, 'console-private console-callout');
  callout.append(el('p', 'Only you', 'eyebrow'));
  for (const path of paths) {
    callout.append(el('p', routeLine(path), 'console-callout-route'));
    if (path.rationale) callout.append(el('p', path.rationale));
  }
  return callout;
}
function renderOptions(view) {
  const from = view.phase === 'discussion_paused' ? view.resumePhase : view.phase;
  const options = view.decision?.interaction?.options ?? [];
  if (!options.length || !OPTION_PHASES.includes(from)) return null;
  const card = section('Options', 'console-card console-options');
  const list = el('ol', null, 'console-option-list');
  const paths = view.decision.paths ?? [];
  options.forEach((option, index) => {
    const item = el('li');
    item.append(optionTile(option, index));
    const callout = routeCallout(paths.filter(path => path.optionIds?.includes(option.id)));
    if (callout) item.append(callout);
    list.append(item);
  });
  card.append(list);
  // A route no option maps to (an override-only or rule-chosen route) is listed once, under the tiles.
  const unmapped = routeCallout(paths.filter(path => !path.optionIds?.length));
  if (unmapped) card.append(unmapped);
  return card;
}

export function mountConsoleRoom(host, { auth, sessionId, joinCode, facilitatorToken,
  restoredSaved = null, readyNotice = '', onEnded = () => {} } = {}) {
  let token = facilitatorToken;
  let local, check, hello, wake, link;
  try {
    // All local prerequisites must exist before a capability-bearing transport
    // starts. A failed channel cannot leave a live room connection behind.
    local = new BroadcastChannel('case-room-local');
    check = createDisplayCheck();
    hello = createProjectorHandshake(sessionId);
    wake = keepScreenAwake();
    link = connect({ role: 'facilitator', api: location.origin, sessionId, token });
  } catch (error) {
    try { link?.close(); } catch {}
    try { wake?.dispose(); } catch {}
    try { local?.close(); } catch {}
    throw error;
  }
  token = null; facilitatorToken = null;
  let snapshot = null, pack = null, manual = null, recovery = null, roomStatus = 'connecting';
  let pendingSaved = restoredSaved;
  restoredSaved = null;
  let tab = 'run', wantLobby = false, pickedPathId = null, armedUntil = 0, showFallback = false;
  let projectorWordShown = false;
  let busy = false, closed = false, statusText = readyNotice;
  let projectorOptions = false, displayApprovalPending = false;
  let muteRequestId = null, muteTimer = null, muteStatus = '';
  // CASE-171: console UI tones. Off until this console's own sound toggle is pressed (that press is the gesture).
  let uiAudio = null, uiSoundOn = false;
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  let uiTones = null; // loaded on first toggle: a lazy chunk (console-tones.mjs) that only this console ever imports
  let renderedPhase = null, renderedTab = null, deferred = false;
  let coverCanvas = null, splash = null; // splash.mjs: the shared lazy art chunk (CASE-173)
  let armTimer = null, fallbackTimer = null;
  const root = el('section', null, 'console-room');
  host.replaceChildren(root);
  // Card 29: room-scoped shared-computer approval, only on a console that holds the facilitator's account.
  let sharedComputer = null; // created by the Room tab chunk on first use, then kept across re-renders
  let consoleList = null; // card 35b: the starter's console list, fetched when the Room tab first renders
  let pointerActivation = null;
  const onPointerDown = event => {
    if (closed || event.button !== 0 || event.isPrimary === false) return;
    const target = event.target.closest?.('button');
    if (target && !target.disabled && root.contains(target)) pointerActivation = { id: event.pointerId, target };
  };
  const finishPointerActivation = () => {
    if (!pointerActivation) return;
    pointerActivation = null;
    if (!closed) render();
  };
  const onPointerUp = event => {
    if (pointerActivation?.id !== event.pointerId) return;
    // A release on this control is followed by click. Keep its listener alive
    // until that click has bubbled through the control's own handler.
    if (pointerActivation.target.disabled || !pointerActivation.target.isConnected ||
        !pointerActivation.target.contains(event.target)) finishPointerActivation();
  };
  const onPointerCancel = event => {
    if (pointerActivation?.id === event.pointerId) finishPointerActivation();
  };
  root.addEventListener('pointerdown', onPointerDown, true);
  root.addEventListener('click', finishPointerActivation);
  const onUiClick = event => { const control = event.target.closest?.('button'); if (control && !control.disabled) void uiTones?.press(control); };
  root.addEventListener('click', onUiClick);
  window.addEventListener('pointerup', onPointerUp, true);
  window.addEventListener('pointercancel', onPointerCancel, true);
  window.addEventListener('blur', finishPointerActivation);
  let topology = null;
  // Bumped on every display this console approves, so a new or replacement
  // display is a pairing change that clears the display check (CASE-165).
  let pairingGeneration = 0;
  // Reads count and screen identity live from the observer (CASE-167).
  const updateDisplaySafety = () => {
    if (closed || !topology) return;
    const previouslyConfirmed = !check.needsCheck();
    check.update({ connected: hello.alive(Date.now()), displayCount: topology.count,
      pairingId: `pairing-${pairingGeneration}`, screenId: topology.fingerprint });
    if (previouslyConfirmed && check.needsCheck()) {
      statusText = 'The projector connection changed. Check the room screen if needed.';
      render();
    }
  };
  topology = observeDisplayTopology({ onChange: updateDisplaySafety });
  updateDisplaySafety();
  topology.ready.then(() => { if (!closed && topology.canRequestScreens) render(); });
  const displayTimer = setInterval(updateDisplaySafety, 2000);

  function currentView() { return manual ? manual.view() : snapshot?.view ?? null; }
  function restoreVerifiedSegment() {
    if (!pendingSaved || !snapshot?.mirror || !pack) return;
    const saved = pendingSaved; pendingSaved = null;
    if (snapshot.mirror.sessionId !== sessionId) return;
    manual = ConsoleManualRoom.restore(snapshot.mirror, pack, saved, { channel: local });
    if (manual) recovery = createManualRecovery(manual, body => link.uploadSegment(body));
    else {
      try { sessionStorage.removeItem(`case-lab:segment:${sessionId}`); } catch {}
      statusText = 'The saved manual room no longer matches this room. Downloaded notes remain on your device.';
    }
  }
  function publish() {
    const frame = projectorFrame(snapshot, pack);
    if (!manual || snapshot?.view.phase === 'ended') publishProjectorFrame(local, frame, sessionId);
  }
  function close({ preserveSegment = false } = {}) {
    if (closed) return;
    closed = true;
    sharedComputer?.close();
    pointerActivation = null;
    root.removeEventListener('pointerdown', onPointerDown, true);
    root.removeEventListener('click', finishPointerActivation);
    root.removeEventListener('click', onUiClick);
    uiSoundOn = false; uiAudio?.close().catch(() => {});
    window.removeEventListener('pointerup', onPointerUp, true);
    window.removeEventListener('pointercancel', onPointerCancel, true);
    window.removeEventListener('blur', finishPointerActivation);
    clearTimeout(armTimer); clearTimeout(fallbackTimer); clearTimeout(muteTimer);
    muteRequestId = null; muteStatus = '';
    clearInterval(displayTimer); topology.dispose();
    window.removeEventListener('pagehide', onPageHide);
    window.removeEventListener('keydown', onPresentationKey);
    closeConsoleResources({ sessionId, manual, local, link, wake, preserveSegment });
    manual = null; recovery = null;
    snapshot = null; pack = null; pendingSaved = null; pickedPathId = null; armedUntil = 0;
    root.replaceChildren();
  }
  function onPageHide() { close({ preserveSegment: true }); }
  window.addEventListener('pagehide', onPageHide, { once: true });
  function onPresentationKey(event) {
    if (closed || tab !== 'run') return;
    const view = currentView();
    if (!view) return;
    const nav = presentationNav(view);
    const action = presentationKeyAction(event, {
      hasMoreGroup: view.actions?.includes('advance') && Boolean(view.presentation?.nextGroup),
      replaying: nav.replaying, canReplayForward: nav.canForward, canReplayBack: nav.canBack,
    });
    if (!action) return;
    event.preventDefault();
    if (action === 'reveal_group') roomCommand('advance');
    else if (action === 'replay_back') roomCommand('replay', { entryIndex: nav.backTarget });
    else if (action === 'replay_forward') roomCommand('replay', { entryIndex: nav.forwardTarget });
  }
  window.addEventListener('keydown', onPresentationKey);

  local.onmessage = ({ data }) => {
    if (closed) return;
    if (data?.t === 'projector_muted') {
      if (muteRequestId && Object.keys(data).length === 3 && data.sessionId === sessionId &&
          isUuidV7(data.requestId) && data.requestId === muteRequestId) {
        clearTimeout(muteTimer); muteTimer = null; muteRequestId = null;
        muteStatus = 'Projector sound muted.'; render();
      }
      return;
    }
    if (hello.accept(data, Date.now())) {
      // Card 37: a hello every 4 s re-renders only if what the console shows about the display changed.
      const before = displayState(), firstHello = !projectorWordShown;
      showFallback = false; clearTimeout(fallbackTimer);
      updateDisplaySafety();
      if (!projectorWordShown) {
        local.postMessage({ t: 'show_projector', sessionId });
        projectorWordShown = true;
      }
      publish();
      if (firstHello || helloNeedsRender(before, displayState())) render();
    }
  };
  function displayState() { return { needsCheck: check.needsCheck(), fallback: showFallback }; }
  function muteProjector() {
    if (closed) return;
    clearTimeout(muteTimer);
    const requestId = uuidv7();
    muteRequestId = requestId;
    muteStatus = 'Asking the same-PC projector to mute…';
    try { local.postMessage({ t: 'mute_projector', sessionId, requestId }); }
    catch {
      muteRequestId = null;
      muteStatus = 'The projector could not be reached. Use its Room sound chip to mute it.';
      render(); return;
    }
    muteTimer = setTimeout(() => {
      if (closed || muteRequestId !== requestId) return;
      muteRequestId = null;
      muteStatus = 'No projector acknowledgement. Use its Room sound chip to mute it.';
      render();
    }, 3_000);
    render();
  }
  link.on('snapshot', next => {
    if (closed || next?.view?.sessionId !== sessionId || next.view.role !== 'facilitator') return;
    snapshot = next;
    if (next.view.phase === 'ended') {
      publish(); close(); onEnded(); return;
    }
    restoreVerifiedSegment(); publish(); render();
  });
  link.on('case_pack', next => { if (!closed) { pack = next; restoreVerifiedSegment(); publish(); render(); } });
  link.on('status', next => { if (!closed) { roomStatus = next; render(); } });
  link.on('error', error => {
    if (closed) return;
    if (['unauthorised', 'removed', 'unknown_room', 'room_deleted'].includes(error)) {
      close(); onEnded({ reason: 'access_lost' }); return;
    }
    statusText = 'Connection interrupted. Keep this tab open.'; render();
  });

  async function send(type, payload = {}) {
    if (closed || busy || manual) return;
    // Disabled controls cannot keep focus through a pending rebuild. Capture
    // only this new presentation control, and never override a later user move.
    const rankedFocus = type === 'ranked_page' && document.activeElement?.closest('.ranked-controls') ?
      document.activeElement.dataset.focusKey : null;
    busy = true; statusText = '';
    let refused = false;
    if (rankedFocus) root.querySelectorAll('.ranked-controls button, .ranked-controls select')
      .forEach(control => { control.disabled = true; });
    render();
    try {
      const result = await link.send(type, payload);
      if (closed) return;
      if (!['accepted', 'already_accepted'].includes(result?.receipt)) {
        refused = true;
        statusText = refusedCommandNotice(result?.reason, result?.receipt);
        if (type === 'show_lobby') wantLobby = false;
        void link.resync();
      }
    } catch { if (!closed) statusText = 'Connection interrupted. Keep this tab open.'; if (type === 'show_lobby') wantLobby = false; }
    finally {
      busy = false;
      if (!closed) {
        const active = document.activeElement;
        const restoreRankedFocus = rankedFocus && (active === document.body || !active ||
          active.disabled || active.dataset?.focusKey === rankedFocus);
        render();
        if (refused) if (type === 'ranked_page') showRankedChoice();
        if (restoreRankedFocus) [...root.querySelectorAll('[data-focus-key]')]
          .find(control => control.dataset.focusKey === rankedFocus && !control.disabled)?.focus({ preventScroll: true });
      }
    }
  }

  /** The ranked select is a kept node holding the facilitator's pick; after a refusal it shows the room's choice. */
  function showRankedChoice() {
    const select = root.querySelector('.ranked-controls select'), chosen = select?.querySelector('option[selected]');
    if (chosen) select.value = chosen.value;
  }

  function roomCommand(type, payload = {}) {
    if (closed || busy || recovery?.pending) return;
    if (!manual) { void send(type, payload); return; }
    let refused = true;
    try {
      const receipt = manual.command(type, payload);
      refused = receipt.receipt !== 'accepted';
      if (refused) statusText = 'Manual room could not apply that action.';
      else if (type === 'end') {
        // This ends the local presentation. During an outage the server has not
        // acknowledged room closure; its clock and recap expiry remain authoritative.
        close(); onEnded({ localOnly: true }); return;
      } else statusText = manual.persistenceOk === false ?
        'Manual changes are only in memory. Keep this tab open and download your notes.' : '';
    } catch { statusText = 'Manual room could not apply that action.'; }
    render();
    if (refused) if (type === 'ranked_page') showRankedChoice();
  }

  function doPrimary() {
    const view = currentView();
    const action = dockControl(view, { pickedPathId, armedUntil, pending: recovery?.pending });
    if (!action || action.disabled || busy || recovery?.pending) return;
    if (action.local === 'focus_resolution') {
      // A press the facilitator made: focus the routes, then bring them into view.
      const route = root.querySelector('.console-routes button');
      route?.focus({ preventScroll: true }); route?.scrollIntoView({ block: 'nearest' }); return;
    }
    if (action.local === 'arm_reveal') {
      armedUntil = Date.now() + 3_000;
      clearTimeout(armTimer);
      armTimer = setTimeout(() => { armedUntil = 0; render(); }, 3_000);
      render(); return;
    }
    armedUntil = 0;
    if (manual) { const receipt = manual.command(action.command, action.payload);
      if (receipt.receipt !== 'accepted') statusText = 'Manual room could not apply that action.';
      else if (manual.persistenceOk === false) statusText = 'Manual changes are only in memory. Keep this tab open and download your notes.';
      render(); return; }
    void send(action.command, action.payload);
  }

  function openProjector() {
    const url = samePcProjectorUrl(sessionId, location.origin);
    hello.opened(Date.now()); showFallback = false; projectorWordShown = false;
    window.open(url, '_blank', 'noopener,noreferrer');
    local.postMessage({ t: 'show_projector', sessionId });
    clearTimeout(fallbackTimer);
    fallbackTimer = setTimeout(() => {
      if (!closed && hello.fallbackRequired(Date.now())) { showFallback = true; render(); }
    }, 3_000);
    render();
  }

  async function enterManual() {
    if (closed || manual || !snapshot?.mirror || !pack ||
        !currentView()?.actions?.includes('enter_manual')) return;
    const phase = currentView().phase;
    const warning = ['responses_open', 'responses_locked'].includes(phase) ?
      'Entering manual room mode will discard the current response round. Continue?' :
      'Enter manual room mode? Changes stay on this tab until you rejoin online.';
    if (!window.confirm(warning)) return;
    link.dropPending();
    manual = new ConsoleManualRoom(snapshot.mirror, pack, { channel: local });
    const receipt = manual.enter();
    if (receipt.receipt !== 'accepted') { manual = null; statusText = 'Manual room is unavailable at this phase.'; }
    else if (manual.persistenceOk === false) statusText = 'Manual changes are only in memory. Keep this tab open and download your notes.';
    if (manual) recovery = createManualRecovery(manual, body => link.uploadSegment(body));
    render();
  }

  async function resumeOnline() {
    if (!manual || !recovery || roomStatus !== 'online' || busy) return;
    busy = true; render();
    try {
      const result = await recovery.resume();
      if (closed) return;
      if (result.kind === 'applied') {
        manual = null; recovery = null;
        await link.refetch();
        statusText = 'Manual changes rejoined the room.';
      } else if (result.kind === 'refused') statusText = 'The room moved on. Download your notes, then follow the room.';
      else if (result.kind === 'not_ready') statusText = 'Reveal or clear the selection first.';
      else statusText = 'Manual changes were not uploaded. Retry the same segment or download your notes.';
    } catch { if (!closed) statusText = 'Manual changes were not uploaded. Keep this tab open and download your notes.'; }
    finally { busy = false; if (!closed) render(); }
  }

  function downloadNotes() {
    if (!manual) return;
    const blob = new Blob([manual.notesText()], { type: 'text/plain;charset=utf-8' });
    const url = localNotesObjectUrl(blob);
    const linkEl = el('a'); linkEl.href = url; linkEl.download = 'case-manual-notes.txt';
    linkEl.click(); setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  function renderSurface(view) {
    const current = consolePublicSurface(view);
    const card = el('div', null, 'console-scene');
    if (!current) { card.append(el('p', view.phase === 'lobby' ? 'The case has not started.' : 'Waiting for the next surface.')); return card; }
    if (presentationNav(view).replaying)
      card.append(el('p', `Projector replay · ${current.title}`, 'console-replay-notice'));
    card.append(el('h3', current.title));
    if (current.scene) card.append(el('p', current.scene, 'console-scene-text'));
    for (const [title, values] of [['Findings', current.points], ['Investigations', current.investigations]]) {
      if (!values?.length) continue;
      const tile = section(title, 'console-tile');
      addTextList(tile, values); card.append(tile);
    }
    if (current.observations?.length) {
      const tile = section('Vitals', 'console-tile');
      addTextList(tile, current.observations.map(o =>
        `${o.label}: ${o.value}${o.unit ? ' ' + o.unit : ''}${o.trend ? ` ${o.trend} from ${o.previous}` : ''}`));
      card.append(tile);
    }
    return card;
  }

  function renderRoutes(view, parent) {
    if (!view.decision?.paths?.length || !view.actions?.includes('select_path')) return;
    const routes = section('Choose an authored route', 'console-card console-routes');
    for (const path of view.decision.paths) {
      const row = el('div', null, 'console-route');
      row.dataset.path = path.id; // what the Select handler captures, so an unchanged row is never kept stale
      const indices = (view.decision.interaction?.options ?? []).flatMap((option, index) => path.optionIds?.includes(option.id) ? [index] : []);
      if (indices.length) {
        const marks = el('span', null, 'console-route-marks');
        marks.append(...indices.map(index => markSvg(index, { size: 24, decorative: true })),
          el('span', `Options: ${indices.map(index => markFor(index).name).join(', ')}`, 'sr-only'));
        row.append(marks);
      }
      row.append(el('strong', path.label),
        el('span', CLASSIFICATION[path.classification] ?? '◇ Authored route', 'console-classification'),
        el('p', `If revealed: ${path.revealPreview}`));
      if (path.rationale) row.append(el('p', `Private note: ${path.rationale}`));
      if (path.cue) row.append(el('p', path.cue.startsWith('Ask:') ? path.cue : `Ask: ${path.cue}`));
      if (path.explored) row.append(el('span', 'Already explored'));
      else {
        const choose = button('Select this route', () => {
          pickedPathId = path.id;
          if (manual) { const receipt = manual.command('select_path', { pathId: path.id });
            statusText = receipt.receipt === 'accepted' ? '' : 'The route could not be selected.';
            if (manual.persistenceOk === false) statusText = 'Manual changes are only in memory. Keep this tab open.';
            render(); }
          else void send('select_path', { pathId: path.id });
        });
        choose.setAttribute('aria-label', `Select this route: ${cleanText(path.label, 200)}`);
        choose.dataset.focusKey = `route-${path.id}`;
        row.append(choose);
      }
      routes.append(row);
    }
    parent.append(routes);
  }

  function renderDisplayCheck(always = false) {
    if (!always && !check.needsCheck() && currentView()?.phase !== 'lobby') return null;
    const card = section('Projector', 'notice console-display-check');
    if (hello.alive(Date.now())) card.append(el('p', 'Projector connected.'));
    card.append(button('Open projector', openProjector));
    if (showFallback) {
      card.append(el('p', 'Projector not connected. Allow pop-ups or open it manually.'));
      const fallback = el('a', 'Open projector manually', 'btn');
      fallback.href = samePcProjectorUrl(sessionId, location.origin);
      fallback.target = '_blank'; fallback.rel = 'noopener noreferrer'; card.append(fallback);
    }
    const options = button('Other setup options', () => { projectorOptions = !projectorOptions; render(); }, 'btn tertiary');
    options.setAttribute('aria-expanded', String(projectorOptions));
    options.setAttribute('aria-controls', 'projector-options'); card.append(options);
    if (projectorOptions) {
      const extra = el('div', null, 'console-projector-options'); extra.id = 'projector-options';
      extra.append(el('p', 'Keep these controls off the room screen. Use extended displays, or connect another device.'));
      extra.append(el('p', 'On a separate display, use its Room sound chip to mute it.', 'console-sound-hint'));
      if (check.needsCheck()) extra.append(button('Dismiss display reminder', () => { check.confirm(); projectorOptions = false; render(); root.querySelector('.console-primary')?.focus({ preventScroll: true }); }, 'btn tertiary'));
      else extra.append(button('Check display', () => { check.samePc(); render(); }, 'btn tertiary'));
      if (topology.canRequestScreens) extra.append(button('Identify screens', () => {
        topology.requestScreens().then(granted => {
          if (closed) return;
          if (granted) statusText = 'Case can now tell your screens apart.';
          render();
        });
      }, 'btn tertiary'));
      const label = el('label', 'Display pairing code');
      const input = el('input'); input.type = 'text'; input.maxLength = 11;
      input.dataset.focusKey = 'display-code'; input.autocomplete = 'off'; label.append(input);
      const approve = button('Connect projector', async event => {
        if (closed || displayApprovalPending) return;
        const value = event.currentTarget.closest('.console-projector-options').querySelector('[data-focus-key="display-code"]').value;
        displayApprovalPending = true; render();
        let result;
        try { const chunk = await import('./console-room-tab.mjs'); if (closed) return; result = await chunk.approveDisplayCode(link, value); }
        catch { result = { ok: false }; }
        if (closed) return;
        displayApprovalPending = false;
        statusText = result.ok ? 'Projector connected.' : 'That display code could not be approved. Check the code and try again.';
        if (result.ok) { pairingGeneration += 1; updateDisplaySafety(); }
        render();
      });
      approve.setAttribute('aria-disabled', String(displayApprovalPending));
      if (displayApprovalPending) approve.setAttribute('aria-busy', 'true');
      extra.append(label, approve);
      if (displayApprovalPending) extra.append(el('p', 'Connecting projector…'));
      card.append(extra);
    }
    return card;
  }

  function renderAggregate(view, phase) {
    if (!phase.aggregate) return null;
    const total = phase.aggregate.total;
    if (!Number.isInteger(total) || total < 0) return null;
    const card = section(`Responses · ${total} ${total === 1 ? 'answer' : 'answers'}`,
      'console-card console-aggregate');
    if (view.decision?.interaction?.type === 'free_text') card.append(el('p',
      'Free-text responses are reviewed privately; only their total is shown here.'));
    else if (consoleRankingRows(view.decision, phase.aggregate)) {
      const rows = consoleRankingRows(view.decision, phase.aggregate), options = view.decision.interaction.options;
      const list = el('ol', null, 'console-option-list');
      rows.forEach((line, index) => { const item = el('li'); item.append(optionTile(options[index], index, line.slice(options[index].label.length))); list.append(item); });
      card.append(list);
    } else {
      const list = el('ol', null, 'console-option-list');
      (view.decision?.interaction?.options ?? []).forEach((option, index) => {
        // The room stores only positive counters. A missing authored option is zero.
        const count = Object.hasOwn(phase.aggregate.counts ?? {}, option.id)
          ? phase.aggregate.counts[option.id] : 0;
        if (!Number.isInteger(count) || count < 0) return;
        const share = total ? Math.round(count / total * 100) : 0;
        const item = el('li'); item.append(optionTile(option, index, ` · ${count} · ${share}%`)); list.append(item);
      });
      card.append(list);
    }
    if (phase.suggestion) {
      const path = view.decision?.paths?.find(candidate => candidate.id === phase.suggestion.pathId);
      card.append(el('p', `Suggested by responses: ${path?.label ?? 'No route suggested'} · ${phase.suggestion.reason ?? ''} · you choose the route`));
    }
    return card;
  }

  function renderRun(view, dock) {
    const panel = el('section', null, 'console-run'); panel.id = 'console-run';
    if (view.phase === 'lobby') {
      panel.classList.add('is-lobby');
      const lobby = section('Lobby', 'console-lobby');
      lobby.append(el('p', `${view.participants?.filter(p => !p.removed).length ?? 0} in the room · Waiting to start`));
      lobby.append(el('p', 'Join code', 'eyebrow'), el('p', formatCode(joinCode), 'mono console-code'));
      const url = el('a', 'Open join page', 'btn'); url.href = joinUrl(joinCode, location.origin);
      lobby.append(url);
      if (view.nextBeat) lobby.append(el('p', `Opens with: ${view.nextBeat.title}`));
      panel.append(lobby);
    } else {
      const phase = phaseModel(view);
      const scene = renderSurface(view);
      const detail = section(phase.heading, 'console-card console-phase');
      detail.dataset.phase = view.phase;
      if (phase.count) detail.append(el('p', phase.count));
      if (phase.reopened) detail.append(el('p', phase.reopened));
      if (view.decision?.prompt && ['responses_open','responses_locked'].includes(view.phase))
        detail.append(el('p', view.decision.prompt));
      if (view.phase === 'path_selected') detail.append(el('p', 'Phones and the projector have not changed'));
      if (view.nextBeat) detail.append(el('p', `Next: ${view.nextBeat.title}`));
      // Card 36b: Room sees | Only you. Commands and their availability are unchanged.
      const sees = column('console-room-sees', 'Room sees'), only = column('console-only-you', 'Only you');
      sees.append(scene);
      const options = renderOptions(view);
      if (options) sees.append(options);
      const privateMaterial = renderOnlyYou(view);
      if (privateMaterial) only.append(privateMaterial);
      only.append(detail);
      const aggregate = renderAggregate(view, phase);
      if (aggregate) only.append(aggregate);
      renderRoutes(view, only);
      if (view.actions?.includes('replay')) {
        const strip = section('Presentation', 'console-card console-presentation');
        strip.setAttribute('aria-label', 'Presentation');
        const nav = presentationNav(view);
        if (nav.replaying) strip.append(el('p', 'Presentation replay · phones remain on live surface', 'console-replay-notice'));
        const controls = el('div', null, 'console-presentation-controls');
        // data-target records what each handler captures, so an unchanged control is never kept stale (card 37).
        const step = (label, target) => { const item = button(label, () => roomCommand('replay', { entryIndex: target })); item.dataset.target = String(target); return item; };
        controls.append(nav.canBack ? step('Back', nav.backTarget) : el('span', 'Back', 'console-presentation-unavailable'));
        controls.append(nav.replaying ? step('Live surface', null) : el('span', 'Live surface', 'console-presentation-unavailable'));
        controls.append(nav.canForward ? step('Forward', nav.forwardTarget) : el('span', 'Forward', 'console-presentation-unavailable'));
        strip.append(controls);
        const rows = el('ol', null, 'console-presentation-rows');
        for (const row of nav.rows) {
          const item = el('li');
          const label = `${row.entryIndex + 1}. ${row.title ?? 'Shared surface'}${row.live ? ' · Live' : ''}`;
          const select = button(label, () => roomCommand('replay', { entryIndex: row.live ? null : row.entryIndex }));
          select.dataset.focusKey = `presentation-row-${row.entryIndex}`;
          if (row.selected) select.setAttribute('aria-current', 'step');
          item.append(select); rows.append(item);
        }
        strip.append(rows, el('p', 'Left and Right arrows browse public rows. Right Arrow, Space or Enter reveals the next shared group when focus is outside controls.', 'console-presentation-help'));
        sees.append(strip);
      }
      const secondary = el('div', null, 'console-secondary');
      // While the lobby screen holds the dock (CASE-176), the phase's own private step stays here, in the Run view.
      const lobbyStep = view.display?.lobby === true ? primaryAction(view, { pickedPathId, armedUntil: 0 }) : null;
      if (lobbyStep?.command) secondary.append(button(lobbyStep.label, () => roomCommand(lobbyStep.command, lobbyStep.payload)));
      // Every primary control lives in the dock (card 37): when the dock is the Hide, it is not repeated here.
      if (view.actions?.includes('show_results') && dock?.command !== 'show_results') secondary.append(button(
        view.resultsShown === false ? 'Show responses on projector' : 'Hide responses on projector',
        () => roomCommand('show_results', { on: view.resultsShown === false })));
      if (view.actions?.includes('show_results') && view.resultsShown !== false) secondary.append(el('p',
        'Hide responses on projector before showing the next case context.'));
      const rankedControls = renderRankedControls(view, { el, button, send: roomCommand, disabled: busy || Boolean(recovery?.pending) });
      if (rankedControls) secondary.append(rankedControls);
      if (!view.rankedPresentation && view.actions?.includes('results_page')) {
        const page = view.resultsPage ?? 0, pages = view.resultsPageCount;
        const previous = button('Previous results page', () => roomCommand('results_page', { page: page - 1 })); previous.disabled = busy || recovery?.pending || page === 0;
        const next = button('Next results page', () => roomCommand('results_page', { page: page + 1 })); next.disabled = busy || recovery?.pending || page === pages - 1;
        secondary.append(el('p', `Results page ${page + 1} of ${pages}`), previous, next);
      }
      for (const [action, label, payload] of [
        ['pause', 'Pause for discussion', {}], ['reopen', 'Reopen as new round', {}],
        ['void_round', 'Void round', {}], ['back_to_review', 'Back to review', {}],
      ]) {
        if (!view.actions?.includes(action)) continue;
        secondary.append(button(label, () => {
          if (action === 'void_round' && !window.confirm('Cancel this round? Its answers are discarded and never used.')) return;
          if (manual) { manual.command(action, payload); render(); }
          else void send(action, payload);
        }));
      }
      only.append(secondary);
      panel.append(sees, only);
    }
    const displayCheck = renderDisplayCheck();
    if (displayCheck) panel.append(displayCheck);
    return panel;
  }

  // The Room tab renders from a lazy chunk (CASE-174), preloaded at mount; until it arrives the tab says so.
  function renderRoom(view) {
    let panel = roomTab?.renderRoomTab?.(view, roomTabContext);
    if (!panel) {
      loadRoomTab();
      panel = el('section', null, 'console-room-tab'); panel.id = 'console-room-tab';
      panel.append(el('p', 'Loading the room controls…', 'console-status'));
    }
    // The outage path (manual room, take over, End room) renders here, never from the lazy chunk.
    const manualCard = section('Manual room');
    if (view.actions?.includes('enter_manual') && !manual)
      manualCard.append(button('Enter manual room mode', enterManual));
    if (manual) {
      manualCard.append(el('p', 'Manual room mode. Keep this tab open during an outage.'));
      manualCard.append(button('Download your notes', downloadNotes));
      if (!busy && !recovery?.pending && view.actions?.includes('manual_marker')) manualCard.append(button('Add spoken marker', () => {
        if (closed || busy || recovery?.pending || !manual) return;
        const text = window.prompt('Marker for your local notes (never uploaded)');
        if (text == null) return;
        const result = manual.command('manual_marker', { text });
        statusText = result.receipt === 'accepted' ? '' : 'The marker could not be saved.';
        if (manual.persistenceOk === false) statusText = 'Manual changes are only in memory. Keep this tab open and download your notes.';
        render();
      }));
      if (recovery?.refused) manualCard.append(button('Follow current room without manual changes', async () => {
        if (!window.confirm('The manual changes were not applied. Download your notes before following the room. Continue?')) return;
        manual.close(); manual.forget(); manual = null; recovery = null;
        await link.refetch(); statusText = 'Following the current room. Manual changes were not applied.'; render();
      }));
      else if (recovery?.pending || view.actions?.includes('resume_online')) {
        const rejoin = button(recovery?.pending ? 'Retry manual upload' : 'Rejoin online at the next decision', resumeOnline);
        rejoin.disabled = roomStatus !== 'online' || busy;
        manualCard.append(rejoin);
      }
    }
    panel.append(manualCard);
    const thisConsole = section('This console');
    if (view.actions?.includes('takeover') && !manual) thisConsole.append(button('Take over this room', () => {
      if (window.confirm('Take over this room? Other facilitator controls will stop.')) roomCommand('takeover');
    }));
    if (view.actions?.includes('end')) thisConsole.append(button('End room', () => {
      const warning = manual ?
        'End this local presentation? If offline, the server room may remain active. Sign in when online to confirm its closure.' :
        'End room? Participant recaps remain available for 24 hours.';
      if (window.confirm(warning)) roomCommand('end');
    }, 'btn danger'));
    panel.append(thisConsole);
    return panel;
  }

  // Imported at mount (precached, AS-076). A failed import is not retried: the browser keeps a failed module URL
  // failed for this document, and the outage controls do not depend on the chunk.
  let roomTab = null; // a promise until console-room-tab.mjs loads
  const loadRoomTab = () => { roomTab ||= import('./console-room-tab.mjs').then(m => { roomTab = m; if (!closed) render(); }, () => {}); };
  const roomTabContext = { el, button, section, roomCommand, render, check, sessionId, joinCode,
    sharedComputer: () => (auth ? sharedComputer ??= roomTab.createSharedComputer({ auth, sessionId, joinCode }) : null),
    // Card 35b (P-27): only a console that holds the starter's account lists and stops shared computers.
    consoles: () => (auth ? consoleList ??= roomTab.createConsoles({ auth, sessionId,
      render: () => { if (!closed) render(); }, setStatus: text => { statusText = text; } }) : null),
    get link() { return link; }, openProjector, projectorSetup: () => renderDisplayCheck(true),
    state: () => ({ manual, closed, showFallback }),
    setStatus: text => { statusText = text; }, showRun: () => { tab = 'run'; },
    displayApproved: () => { pairingGeneration += 1; updateDisplaySafety(); } };

  /** The persistent 32 px cover slot reserves space while the shared brand/case renderer loads. */
  function coverSlot(view) {
    coverCanvas ??= el('canvas', null, 'console-cover');
    splash?.paintCaseCover?.(coverCanvas, view.art, { size: 32, group: view.tint });
    if (!splash) splash = import('./splash.mjs').then(m => { splash = m; if (!closed) render(); }, () => {});
    const slot = el('span', null, 'console-cover-slot'); slot.dataset.keep = 'cover'; slot.setAttribute('aria-hidden', 'true');
    return slot;
  }

  // Card 37 item 4 (CASE-176): the console's Lobby view while the projector shows the lobby join screen.
  function renderLobbyView(view) {
    const panel = el('section', null, 'console-run is-lobby console-lobby-view'); panel.id = 'console-lobby-view';
    const lobby = section('Lobby', 'console-lobby');
    const roster = view.participants?.filter(p => !p.removed) ?? [];
    lobby.append(el('p', 'Projector: join screen', 'console-projector-pill'),
      el('p', `${roster.length} in the room · phones stay on the case`));
    lobby.append(el('p', 'Join code', 'eyebrow'), el('p', formatCode(joinCode), 'mono console-code'));
    const url = el('a', 'Open join page', 'btn'); url.href = joinUrl(joinCode, location.origin);
    lobby.append(url);
    if (view.joiningClosed) lobby.append(el('p', 'Joining is closed · the projector shows no join route'));
    if (view.actions?.includes('close_joining')) lobby.append(button(view.joiningClosed ? 'Reopen joining' : 'Close joining',
      () => roomCommand('close_joining', { closed: !view.joiningClosed })));
    const people = section('Arrivals', 'console-lobby-roster');
    const list = el('ol', null, 'console-lobby-arrivals');
    // Newest first, so a late joiner is at the top.
    for (const person of [...roster].sort((a, b) => String(b.joinedAt).localeCompare(String(a.joinedAt))))
      list.append(el('li', person.name || 'Unnamed'));
    people.append(roster.length ? list : el('p', 'No one has joined yet'));
    panel.append(lobby, people);
    const displayCheck = renderDisplayCheck();
    if (displayCheck) panel.append(displayCheck);
    return panel;
  }

  function render() {
    if (closed) return;
    const view = currentView();
    if (!view) { root.replaceChildren(el('p', 'Connecting to the room…', 'console-status')); return; }
    const lobbyShown = view.display?.lobby === true;
    // Showing the lobby opens the Lobby view once the room confirms it; returning restores the Run view (CASE-176).
    if (lobbyShown && wantLobby) { tab = 'lobby'; wantLobby = false; }
    if (tab === 'lobby' && !lobbyShown) tab = 'run';
    const active = root.contains(document.activeElement) ? document.activeElement : null;
    const nextFocus = focusAfterConsoleUpdate({ activeTag: active?.tagName,
      phase: renderedPhase, nextPhase: view.phase, tab: renderedTab, nextTab: tab,
      focusKey: active?.dataset?.focusKey });
    if (nextFocus.kind === 'defer' ||
        (pointerActivation && renderedPhase === view.phase && renderedTab === tab)) {
      const status = root.querySelector('.console-action-dock [role="status"]');
      if (status) status.textContent = busy ? 'Sending to the room…' : statusText;
      const connection = root.querySelector('.console-connection');
      if (connection) connection.textContent = roomStatus === 'online' ? '● Live' : '◌ Reconnecting';
      const roomTab = root.querySelector('[data-focus-key="tab-room"]');
      if (roomTab) roomTab.textContent = `Room · ${view.participants?.filter(p => !p.removed).length ?? 0}`;
      if (!deferred && nextFocus.kind === 'defer') {
        deferred = true;
        // A synchronous rebuild on blur would remove the button being clicked
        // before its click event fires. Let that interaction finish first.
        active.addEventListener('blur', () => {
          deferred = false; setTimeout(() => { if (!closed) render(); }, 0);
        }, { once: true });
      }
      return;
    }
    // Card 36b: the bar line, then the beat line.
    const header = el('header', null, 'console-orientation');
    const bar = el('div', null, 'console-bar');
    bar.append(coverSlot(view), el('span', view.caseTitle ?? 'Case', 'console-case-title'));
    // The lobby screen toggle (CASE-176): offered whenever the authority offers show_lobby.
    if (!lobbyShown && view.actions?.includes('show_lobby')) {
      const toggle = button('Show join code', () => {
        wantLobby = !lobbyShown;
        roomCommand('show_lobby', { on: !lobbyShown });
      }, 'btn console-lobby-toggle');
      bar.append(toggle);
    }
    // The audio chip is the existing mute request; it claims no unacknowledged projector state.
    const chip = button('Mute same-PC projector', muteProjector, 'btn console-audio-chip');
    bar.append(chip);
    const uiSound = button(uiSoundOn ? 'Console sounds: on' : 'Console sounds: off', async () => {
      try { uiAudio ??= new AudioContext(); await uiAudio.resume();
        uiTones ??= (await import('./console-tones.mjs')).createUiTonePlayer({ enabled: () => uiSoundOn, reduced: () => reducedMotion.matches, hidden: () => document.hidden, getContext: () => uiAudio }); uiSoundOn = !uiSoundOn && uiAudio.state === 'running'; } catch { uiSoundOn = false; }
      render();
    }, 'btn tertiary console-ui-sound');
    uiSound.dataset.tone = 'none'; uiSound.setAttribute('aria-pressed', String(uiSoundOn)); bar.append(uiSound);
    bar.append(el('span', roomStatus === 'online' ? '● Live' : '◌ Reconnecting', 'console-connection'));
    const beat = el('div', null, 'console-beat');
    const heading = el('h1', view.beat?.title ?? (view.phase === 'lobby' ? 'Lobby' : 'Case'));
    heading.tabIndex = -1;
    beat.append(el('p', 'Case · facilitator', 'eyebrow'), heading, el('span', phaseModel(view).heading, 'console-phase-pill'));
    if (lobbyShown) beat.append(el('span', 'Projector: join screen', 'console-projector-pill'));
    if (manual) beat.append(el('span', recovery?.pending ? 'Manual upload pending' : 'Manual room mode', 'console-manual-pill'));
    if (view.timer) beat.append(el('span', timerWords(timerRemainingS(view.timer)), 'console-timer'));
    const sound = el('div', null, 'console-sound-line');
    const soundStatus = el('span', muteStatus, 'console-sound-status');
    soundStatus.setAttribute('role', 'status');
    sound.append(soundStatus);
    header.append(bar, beat, sound);
    const tabs = el('div', null, 'console-tabs'); tabs.setAttribute('role', 'tablist');
    const names = [['run', 'Run'], ['room', `Room · ${view.participants?.filter(p => !p.removed).length ?? 0}`], ...(lobbyShown ? [['lobby', 'Lobby']] : [])];
    for (const [name, label] of names) {
      const item = button(label, () => { tab = name; wantLobby = false; render(); }, 'btn console-tab');
      item.dataset.focusKey = `tab-${name}`;
      item.dataset.tone = tab === name ? 'press' : name === 'run' ? 'close' : 'open';
      item.setAttribute('role', 'tab'); item.setAttribute('aria-selected', String(tab === name));
      item.setAttribute('aria-controls', { run: 'console-run', room: 'console-room-tab', lobby: 'console-lobby-view' }[name]);
      item.tabIndex = tab === name ? 0 : -1;
      item.onkeydown = event => {
        if (!['ArrowRight', 'ArrowLeft'].includes(event.key)) return;
        event.preventDefault();
        const at = names.findIndex(([n]) => n === tab), step = event.key === 'ArrowRight' ? 1 : names.length - 1;
        tab = names[(at + step) % names.length][0]; render();
        root.querySelector(`[aria-selected="true"]`)?.focus({ preventScroll: true });
      };
      tabs.append(item);
    }
    const control = dockControl(view, { pickedPathId, armedUntil, pending: recovery?.pending });
    const content = tab === 'run' ? renderRun(view, control) : tab === 'lobby' ? renderLobbyView(view) : renderRoom(view);
    content.setAttribute('role', 'tabpanel');
    const status = el('p', null, 'console-status');
    const dock = el('div', null, 'console-action-dock');
    if (control) {
      // Never blank (card 37): the primary action, the explicit Hide, Back to the case, or a disabled reason.
      // While a command awaits its receipt the next action stays visible but disabled, with plain feedback.
      const main = button(control.label, doPrimary, 'btn primary console-primary');
      main.dataset.focusKey = 'primary-action';

      main.disabled = false;
      if (control.disabled) main.setAttribute('aria-disabled', 'true');
      // aria-disabled keeps the control focusable through the round trip; doPrimary ignores it while busy.
      if (busy && !main.disabled) { main.setAttribute('aria-disabled', 'true'); main.setAttribute('aria-busy', 'true'); }
      dock.append(main);
      const feedback = el('span', busy ? 'Sending to the room…' : statusText || control.note || '');
      feedback.setAttribute('role', 'status'); dock.append(feedback);
    }
    // Card 37: patch the live surface from the fresh one. Unchanged sections keep their nodes, so a vote or a
    // projector hello never replaces the scene, moves the scroll position or restarts anything.
    const fresh = el('section');
    fresh.append(header, tabs, content, status, dock);
    patchChildren(root, fresh);
    const cover = root.querySelector('[data-keep="cover"]');
    if (cover && coverCanvas.parentNode !== cover) cover.replaceChildren(coverCanvas);
    const shared = root.querySelector('[data-keep="shared-computer"]');
    if (shared && sharedComputer && sharedComputer.section.parentNode !== shared) shared.replaceChildren(sharedComputer.section);
    renderedPhase = view.phase; renderedTab = tab;
    // Every programmatic focus passes preventScroll: a background update never scrolls the console.
    const focused = document.activeElement;
    if (nextFocus.kind === 'heading' ||
        (nextFocus.kind === 'none' && active?.matches('.console-orientation h1') && !active.isConnected)) {
      const live = root.querySelector('.console-orientation h1');
      if (live !== focused) live?.focus({ preventScroll: true });
    } else if (nextFocus.kind === 'key' && !(focused?.isConnected && focused.dataset?.focusKey === nextFocus.key)) {
      [...root.querySelectorAll('[data-focus-key]')]
        .find(item => item.dataset.focusKey === nextFocus.key)?.focus({ preventScroll: true });
    }
  }

  render();
  loadRoomTab();
  return { close, get link() { return link; } };
}

// Every cleanup step is independent. A closed BroadcastChannel must never
// prevent facilitator credential and transport cleanup.
export function closeConsoleResources({ sessionId, manual, local, link, wake, preserveSegment = false }) {
  for (const step of [
    () => wake?.dispose(),
    () => manual?.close(),
    () => { if (!preserveSegment) manual?.forget(); },
    () => local?.postMessage({ t: 'local_end', sessionId }),
    () => local?.close(),
    () => link?.dropPending(),
    () => link?.forget(),
    () => link?.close(),
  ]) try { step(); } catch { /* continue clearing the remaining resources */ }
}
