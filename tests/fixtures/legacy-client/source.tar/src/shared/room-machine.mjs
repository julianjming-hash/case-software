// src/shared/room-machine.mjs: the executable spec of a live Case room (CASE-057).
//
// ONE pure module. The Durable Object, the facilitator/display/participant clients, the
// prototypes and the tests all run this same reducer, so they cannot disagree.
//
//   initialState({ sessionId, joinCode, caseDoc })  → state
//   reduce(state, event)                             → { state, effects }   (pure; no idempotency)
//   dispatch(state, event, ledger)                   → reduce + idempotency through a receipt ledger
//   applySegment(state, events, ledger)              → all-or-nothing replay of a manual segment
//   project(state, role, participantId?)             → what that role may see, and nothing more
//
// Pure: no I/O, no clock, no randomness. Time (`at`, ISO-8601) and ids arrive inside events.
// The input state is never mutated.
//
// Event: { type, epoch, actor: { role, id? }, at, clientEventId?, ...payload }
// Effects:
//   { type: 'receipt', clientEventId, receipt, reason? }   answer to the sender (idempotent)
//   { type: 'journal', seq, epoch, kind, payload, at }     append to the session journal
//   { type: 'broadcast', revision }                        role projections changed
//   { type: 'display', displayRevision }                   projector-only change (replay)
//
// Rules carried from docs/HANDOFF.md and docs/DECISIONS.md:
//   • a vote never chooses the path; the facilitator selects an authored path (CASE-042)
//   • manual room, presentation replay and the lobby screen are layers, not phases (CASE-037, CASE-176)
//   • manual mode starts only at a stable boundary; inside a decision only after void (CASE-035)
//   • every authority change bumps `epoch`; older-epoch commands change nothing (CASE-037)
//   • terminal paths reset to a snapshot checkpoint and grey the explored option (CASE-041)
//   • nothing unrevealed, no cue or private suggestion reaches public projections

import { indexCaseDocument, suggestPath } from './case-document.mjs';
import { identifierKinds } from './identifiers.mjs';
import { isAvatarId } from './participant.mjs';
import { cleanText } from './text.mjs';
import { sanitizeArt } from './art-descriptor.mjs';
import { tintOf } from './tints.mjs';
import { buildRankedGroups } from './ranked-groups.mjs';
import { rankedPage, rankedLayout } from './ranked-presentation.mjs';
import { populatedPresentationGroups, publicPresentationSurface } from './presentation-groups.mjs';
export { cleanText } from './text.mjs';

export const PHASES = Object.freeze([
  'lobby', 'surface_live', 'responses_open', 'responses_locked', 'path_selected',
  'consequence_revealed', 'terminal_teaching', 'discussion_paused', 'ended',
]);
export const ROLES = Object.freeze(['facilitator', 'display', 'participant']);
export const RECEIPTS = Object.freeze(['accepted', 'already_accepted', 'locked', 'paused_held', 'stale_epoch', 'rejected']);

/** Phases where manual room mode may begin (HANDOFF §Manual room and recovery contract).
 *  A pause counts only if it was taken from one of these too: never from inside a decision. */
export const STABLE_PHASES = Object.freeze(['lobby', 'surface_live', 'consequence_revealed', 'discussion_paused', 'terminal_teaching']);
export const isStableBoundary = (state) => STABLE_PHASES.includes(state.phase)
  && (state.phase !== 'discussion_paused' || STABLE_PHASES.includes(state.resumePhase));

/** Facilitator commands, the participant commands, and who may send each. */
export const COMMANDS = Object.freeze({
  join: ['participant'],
  rename: ['participant', 'facilitator'],
  vote: ['participant'],
  remove_participant: ['facilitator'],
  start: ['facilitator'],
  advance: ['facilitator'],
  lock: ['facilitator'],
  reopen: ['facilitator'],
  void_round: ['facilitator'],
  select_path: ['facilitator'],
  back_to_review: ['facilitator'],
  reveal: ['facilitator'],
  reset_checkpoint: ['facilitator'],
  pause: ['facilitator'],
  resume: ['facilitator'],
  show_names: ['facilitator'],
  show_results: ['facilitator'],
  results_page: ['facilitator'],
  ranked_page: ['facilitator'],
  set_timer: ['facilitator'],
  replay: ['facilitator'],
  show_lobby: ['facilitator'],
  enter_manual: ['facilitator'],
  manual_marker: ['facilitator'],
  resume_online: ['facilitator'],
  takeover: ['facilitator'],
  close_joining: ['facilitator'],
  end: ['facilitator'],
});

/** Facilitator commands that may carry `expectRevision` (a precondition fence for stale tabs). */
/** Commands that publish to or change the projector: refused as `lobby_shown` while the lobby screen is up (CASE-176). */
const LOBBY_BLOCKED = new Set(['advance', 'reveal', 'reset_checkpoint', 'replay', 'show_results', 'results_page', 'ranked_page', 'show_names']);
/** The projector is on the lobby join screen mid-case (CASE-176). A stored room without the field reads as off. */
const lobbyShown = (state) => state.display?.lobby === true && state.phase !== 'lobby' && state.phase !== 'ended' && !state.manual;

const FENCEABLE = new Set(['start', 'advance', 'lock', 'reopen', 'void_round', 'select_path', 'back_to_review', 'reveal', 'reset_checkpoint', 'enter_manual', 'resume_online', 'end', 'ranked_page']);

const NAME_MAX = 40;
/** Participant entries a room keeps (removed ones included): bounds the stored state and every
 *  facilitator snapshot, so a join flood cannot make the room unwritable (runtime red team P0-1). */
export const MAX_PARTICIPANTS = 300;
const FREE_TEXT_MAX = 280;
const TIME_MIN = Date.UTC(2020, 0, 1);
const TIME_MAX = Date.UTC(2100, 0, 1);
export const RECAP_TTL_MS = 24 * 60 * 60 * 1000; // CASE-043
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

const indexCache = new WeakMap();
function idx(state) {
  let i = indexCache.get(state.caseDoc);
  if (!i) { i = indexCaseDocument(state.caseDoc); indexCache.set(state.caseDoc, i); }
  return i;
}

function groupsForEntry(state, entry) {
  if (!entry) return [];
  const surface = idx(state).surfaces.get(entry.surfaceId);
  if (!surface) return [];
  const variant = entry.variant >= 0 ? surface.variants[entry.variant] : surface;
  return populatedPresentationGroups({
    scene: variant.scene ?? surface.scene ?? null,
    assetIds: surface.asset_ids ?? [],
    observations: surface.observations ?? [],
    points: variant.points ?? surface.points ?? [],
    investigations: variant.investigations ?? surface.investigations ?? [],
  });
}

/** Preserve pre-progress rooms' already-public text without trusting malformed new progress. */
export function normalizePresentationState(state) {
  const legacy = state.presentationVersion === undefined;
  if (!legacy && state.presentationVersion !== 1) throw new TypeError('invalid_presentation_version');
  if (!Array.isArray(state.revealed)) throw new TypeError('invalid_presentation_progress');
  let changed = legacy;
  const revealed = state.revealed.map((entry) => {
    if (!entry || !idx(state).surfaces.has(entry.surfaceId)) throw new TypeError('invalid_presentation_progress');
    const total = groupsForEntry(state, entry).length;
    if (entry.groupsShown === undefined) {
      changed = true;
      return { ...entry, groupsShown: legacy ? total : 0 };
    }
    if (!Number.isSafeInteger(entry.groupsShown) || entry.groupsShown < 0 || entry.groupsShown > total) {
      throw new TypeError('invalid_presentation_progress');
    }
    return entry;
  });
  return changed ? { ...state, presentationVersion: 1, revealed } : state;
}

export function initialState({ sessionId, joinCode = null, caseDoc, caseVersionNo = null, art = null, tint = null }) {
  return {
    v: 1,
    presentationVersion: 1,
    sessionId,
    joinCode,
    caseVersionNo,
    // The published version's numbers-only art descriptor (CASE-164), fixed for the room's life.
    art: sanitizeArt(art),
    // The group tint at start (CASE-168 (4)); a retint never reaches the room.
    tint: tintOf(tint),
    caseDoc,
    epoch: 0,
    revision: 0,
    phase: 'lobby',
    resumePhase: null,
    beatId: null,
    nextBeatId: caseDoc.start_beat_id,
    decisionId: null,
    liveSurfaceId: null,
    round: null,           // current round: { id, decisionId, no, status, openedAt, lockedAt, responses{pid→…}, aggregate, suggestion }
    rounds: [],            // closed rounds (summary only, no per-person answers)
    selectedPathId: null,
    resolutionKind: null,
    terminalPathId: null,
    flags: [],
    checkpoints: {},       // beatId → { flags }
    exploredTerminal: [],  // terminal path ids already explored (greyed)
    disabledOptions: {},   // decisionId → optionIds
    revealed: [],          // timeline: { surfaceId, beatId, pathId, kind, variant, manual, at, groupsShown }
    participants: {},      // pid → { name, avatarId, joinedAt, removedAt }
    namesShown: false,
    arrivalCount: 0,
    resultsShown: true,
    resultsPage: 0,
    rankedSelection: { group: 0, position: 0 },
    manual: null,          // { segmentId, startedAt, markers: [] }
    manualSegments: [],
    timer: null,           // { durationS, startedAt, remainingS } advisory only
    display: { revision: 0, cursor: null, lobby: false }, // lobby: the mid-case lobby screen layer (CASE-176)
    joiningClosed: false,
    lastAt: null,          // monotonic clock: every event time is clamped to ≥ lastAt
    endedAt: null,
  };
}

/** @returns {{ state: object, effects: object[] }} */
export function reduce(prev, event) {
  prev = normalizePresentationState(prev);
  const effects = [];
  const fail = (receipt, reason) => {
    effects.length = 0; // a rejected command emits nothing but its receipt
    if (event?.clientEventId) effects.push({ type: 'receipt', clientEventId: event.clientEventId, receipt, reason });
    return { state: prev, effects };
  };

  // ── envelope ──
  if (!event || typeof event !== 'object' || typeof event.type !== 'string') return fail('rejected', 'malformed_event');
  const allowedRoles = COMMANDS[event.type];
  if (!allowedRoles) return fail('rejected', 'unknown_command');
  if (!event.actor || !allowedRoles.includes(event.actor.role)) return fail('rejected', 'forbidden');
  const t = typeof event.at === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(event.at) ? Date.parse(event.at) : NaN;
  if (!Number.isFinite(t) || t < TIME_MIN || t > TIME_MAX) return fail('rejected', 'bad_time');
  if (event.clientEventId !== undefined && !UUID.test(event.clientEventId)) return fail('rejected', 'bad_client_event_id');
  // Joining is not epoch-fenced: a phone that has never seen the room cannot know its epoch.
  if (event.type !== 'join' && event.epoch !== prev.epoch) return fail('stale_epoch', `room is at epoch ${prev.epoch}`);
  if (prev.phase === 'ended') return fail('rejected', 'room_ended');
  if (event.type === 'ranked_page' && event.expectRevision === undefined) return fail('rejected', 'missing_expect_revision');
  if (event.expectRevision !== undefined) {
    if (!FENCEABLE.has(event.type)) return fail('rejected', 'unexpected_expect_revision');
    if (event.expectRevision !== prev.revision) return fail('rejected', 'stale_revision');
  }
  // Monotonic, normalised time: a device clock can never move the room backwards or emit an invalid date.
  const at = new Date(Math.max(t, prev.lastAt ? Date.parse(prev.lastAt) : t)).toISOString();

  // ── copy-on-write (the case document is shared, never copied) ──
  const { caseDoc, ...rest } = prev;
  const s = structuredClone(rest);
  s.caseDoc = caseDoc;
  s.lastAt = at;
  const I = idx(s);
  let revisionBumped = false;
  let displayBumped = false;

  const journal = (kind, payload = {}) => {
    s.revision += 1;
    revisionBumped = true;
    effects.push({ type: 'journal', seq: s.revision, epoch: s.epoch, kind, payload, at });
  };
  const reject = (reason, receipt = 'rejected') => fail(receipt, reason);
  const isFac = event.actor.role === 'facilitator';

  const result = handle();
  if (result) return result; // a rejection

  if (event.clientEventId) effects.unshift({ type: 'receipt', clientEventId: event.clientEventId, receipt: 'accepted' });
  // A participant's own view does not change when someone else votes or joins, so those
  // broadcasts skip phones (red team: fan-out cost). The voter learns from its receipt.
  if (revisionBumped) {
    // A participant renaming themselves changes no other phone's view either (runtime red team P2-6), and the
    // lobby screen layer is the projector's alone (CASE-176).
    const quiet = ['vote', 'join', 'show_lobby'].includes(event.type) || (event.type === 'rename' && !isFac);
    effects.push({ type: 'broadcast', revision: s.revision, roles: quiet ? ['facilitator', 'display'] : [...ROLES] });
  }
  if (displayBumped) effects.push({ type: 'display', displayRevision: s.display.revision });
  return { state: s, effects };

  // Returns undefined on success, or a { state, effects } rejection.
  function handle() {
    if (LOBBY_BLOCKED.has(event.type) && lobbyShown(s)) return reject('lobby_shown');
    switch (event.type) {
      case 'join': {
        const pid = event.actor.id;
        if (!UUID.test(pid || '')) return reject('bad_participant_id');
        const existing = s.participants[pid];
        if (existing?.removedAt) return reject('removed');
        if (existing) return undefined; // idempotent rejoin: nothing changes
        if (s.joiningClosed) return reject('joining_closed');
        if (Object.keys(s.participants).length >= MAX_PARTICIPANTS) return reject('room_full');
        s.participants[pid] = { name: cleanName(event.displayName), avatarId: avatarOf(event.avatarId), joinedAt: at, removedAt: null };
        s.arrivalCount = (s.arrivalCount ?? Object.keys(prev.participants).length) + 1;
        journal('participant_joined', { participantId: pid });
        return undefined;
      }
      case 'rename': {
        const pid = isFac ? event.participantId : event.actor.id;
        const p = s.participants[pid];
        if (!p || p.removedAt) return reject('unknown_participant');
        p.name = cleanName(event.displayName);
        if (event.avatarId !== undefined) p.avatarId = avatarOf(event.avatarId); // optional on a rename (CASE-119)
        journal('participant_renamed', { participantId: pid });
        return undefined;
      }
      case 'remove_participant': {
        const p = s.participants[event.participantId];
        if (!p || p.removedAt) return reject('unknown_participant');
        p.removedAt = at;
        if (s.round?.responses[event.participantId]) delete s.round.responses[event.participantId];
        journal('participant_removed', { participantId: event.participantId });
        return undefined;
      }

      case 'vote': return vote();

      case 'start':
        if (s.phase !== 'lobby') return reject('not_in_lobby');
        return enterBeat(s.nextBeatId);

      case 'advance': {
        if (!['surface_live', 'consequence_revealed', 'terminal_teaching'].includes(s.phase)) return reject('cannot_advance_now');
        if (responsesBlockPublication(I, s)) return reject('hide_responses_first');
        const current = s.revealed.at(-1);
        const total = groupsForEntry(s, current).length;
        if (current && current.groupsShown < total) {
          current.groupsShown += 1;
          journal('presentation_group_revealed', { surfaceId: current.surfaceId, groupIndex: current.groupsShown });
          return undefined;
        }
        if (s.phase === 'terminal_teaching') return reject('no_next_group');
        // A decision beat whose round was voided (or not yet opened) opens a fresh round.
        if (s.decisionId && s.phase === 'surface_live') {
          if (s.manual) return reject('manual_select_path_instead');
          return openRound();
        }
        if (!s.nextBeatId) return reject('no_next_beat');
        return enterBeat(s.nextBeatId);
      }

      case 'lock': {
        if (s.phase !== 'responses_open') return reject('not_open');
        const decision = I.decisions.get(s.round.decisionId);
        const responses = Object.values(s.round.responses).map((r) => r.response);
        const sug = suggestPath(decision, responses);
        s.round.status = 'locked';
        s.round.lockedAt = at;
        s.round.aggregate = { counts: sug.counts, total: sug.total };
        if (decision.interaction.type === 'ranking') {
          const eligibleOptionIds = decision.interaction.options.filter(option => !(s.disabledOptions[decision.id] ?? []).includes(option.id)).map(option => option.id);
          const rankCount = decision.interaction.rank_count ?? eligibleOptionIds.length;
          const positionCounts = Object.fromEntries(decision.interaction.options.map(option => [option.id, Array(rankCount).fill(0)]));
          for (const response of responses) response.order.forEach((optionId, position) => { positionCounts[optionId][position]++; });
          Object.assign(s.round.aggregate, { rankCount, eligibleOptionIds, positionCounts,
            completeOrders: buildRankedGroups(decision.interaction.options, responses, { rankCount, eligibleOptionIds }) });
        }
        s.round.suggestion = { pathId: sug.path_id, reason: sug.reason, kind: sug.kind };
        s.timer = null;
        s.phase = 'responses_locked';
        if (s.resultsShown !== false) s.namesShown = false;
        journal('responses_locked', { roundId: s.round.id, total: sug.total });
        return undefined;
      }

      case 'reopen': {
        if (s.phase !== 'responses_locked') return reject('not_locked');
        closeRound('superseded');
        return openRound();
      }

      case 'void_round': {
        if (!['responses_open', 'responses_locked'].includes(s.phase)) return reject('no_round_to_void');
        closeRound('abandoned');
        s.timer = null;
        s.phase = 'surface_live'; // decisionId kept: `advance` opens a fresh round
        return undefined;
      }

      case 'select_path': {
        const manualPending = s.manual && s.decisionId && s.phase === 'surface_live';
        if (s.phase !== 'responses_locked' && !manualPending) return reject('cannot_select_now');
        const current = s.revealed.at(-1);
        if (manualPending && current && current.groupsShown < groupsForEntry(s, current).length) return reject('presentation_context_pending');
        const path = I.paths.get(event.pathId);
        if (!path || path.decision_id !== s.decisionId) return reject('path_not_in_decision');
        if (s.exploredTerminal.includes(path.id)) return reject('path_already_explored');
        s.selectedPathId = path.id;
        s.resolutionKind = s.manual ? 'manual_room' : resolutionKind(path.id);
        s.phase = 'path_selected';
        journal('path_selected', { decisionId: s.decisionId, pathId: path.id, resolutionKind: s.resolutionKind });
        return undefined;
      }

      case 'back_to_review': {
        if (s.phase !== 'path_selected') return reject('nothing_selected');
        s.selectedPathId = null;
        s.resolutionKind = null;
        s.phase = s.round && s.round.status === 'locked' ? 'responses_locked' : 'surface_live';
        journal('selection_cleared', { decisionId: s.decisionId });
        return undefined;
      }

      case 'reveal': {
        if (s.phase !== 'path_selected') return reject('nothing_selected');
        if (responsesBlockPublication(I, s)) return reject('hide_responses_first');
        const path = I.paths.get(s.selectedPathId);
        const decisionId = s.decisionId;
        if (s.round) {
          s.round.selectedPathId = path.id;
          s.round.resolutionKind = s.resolutionKind;
          closeRound('resolved');
        }
        applyFlags(path.set_flags, path.clear_flags);
        const terminal = path.classification === 'terminal-unsafe';
        revealSurface(path.reveal_surface_id, { pathId: path.id, kind: terminal ? 'terminal' : 'consequence' });
        journal('consequence_revealed', { decisionId, pathId: path.id, resolutionKind: s.resolutionKind, terminal });
        s.selectedPathId = null;
        if (terminal) {
          s.terminalPathId = path.id;
          s.phase = 'terminal_teaching';
          s.nextBeatId = null;
        } else {
          s.decisionId = null;
          s.nextBeatId = path.next_beat_id;
          s.phase = 'consequence_revealed';
        }
        s.resolutionKind = null;
        return undefined;
      }

      case 'reset_checkpoint': {
        if (s.phase !== 'terminal_teaching') return reject('not_terminal');
        if (responsesBlockPublication(I, s)) return reject('hide_responses_first');
        const path = I.paths.get(s.terminalPathId);
        const cp = path.terminal.checkpoint_beat_id;
        const snap = s.checkpoints[cp];
        s.flags = snap ? [...snap.flags] : [];
        s.exploredTerminal.push(path.id);
        const greyed = new Set([...(s.disabledOptions[path.decision_id] || []), ...(path.option_ids || [])]);
        s.disabledOptions[path.decision_id] = [...greyed];
        s.terminalPathId = null;
        s.decisionId = null;
        journal('checkpoint_reset', { pathId: path.id, checkpointBeatId: cp });
        return enterBeat(cp);
      }

      case 'pause': {
        if (['lobby', 'discussion_paused'].includes(s.phase)) return reject('cannot_pause_now');
        s.resumePhase = s.phase;
        s.phase = 'discussion_paused';
        if (s.timer && s.timer.remainingS === null) {
          const elapsed = Math.max(0, (Date.parse(at) - Date.parse(s.timer.startedAt)) / 1000);
          s.timer.remainingS = Math.max(0, Math.round(s.timer.durationS - elapsed));
        }
        journal('discussion_paused', { resumePhase: s.resumePhase });
        return undefined;
      }

      case 'resume': {
        if (s.phase !== 'discussion_paused') return reject('not_paused');
        s.phase = s.resumePhase;
        s.resumePhase = null;
        if (s.timer && s.timer.remainingS !== null) s.timer = { durationS: s.timer.remainingS, startedAt: at, remainingS: null };
        journal('discussion_resumed', { phase: s.phase });
        return undefined;
      }

      case 'show_names': {
        if (typeof event.on !== 'boolean') return reject('bad_payload');
        if (event.on && responsesBlockPublication(I, s)) return reject('hide_responses_first');
        s.namesShown = event.on;
        journal('names_shown', { on: event.on });
        return undefined;
      }

      case 'show_results': {
        if (typeof event.on !== 'boolean') return reject('bad_payload');
        if (!closedResponseRound(I, s) || s.display.cursor !== null) return reject('no_closed_result');
        s.resultsShown = event.on;
        if (event.on) s.namesShown = false;
        journal('results_shown', { on: event.on });
        return undefined;
      }

      case 'results_page': {
        if (!Number.isInteger(event.page) || event.page < 0 || event.page > 3) return reject('bad_payload');
        const result = responseResult(I, s);
        if (!result || result.type !== 'ranking' || result.counts.length <= 2
          || event.page >= Math.ceil(result.counts.length / 2)) return reject('no_closed_result');
        s.resultsPage = event.page;
        journal('results_page', { page: event.page });
        return undefined;
      }

      case 'ranked_page': {
        if (!UUID.test(event.closedRoundId ?? '') || !Number.isSafeInteger(event.group) || event.group < 0 || event.group >= 300
          || !Number.isSafeInteger(event.position) || event.position < 0 || event.position >= 8) return reject('bad_payload');
        const result = responseResult(I, s);
        const round = closedResponseRound(I, s);
        if (!result?.ranked || !round || result.ranked.totalGroups === 0) return reject('no_closed_result');
        if (event.closedRoundId !== round.id) return reject('stale_closed_round');
        const page = rankedPage(I.decisions.get(round.decisionId), round.aggregate, { group: event.group, position: event.position });
        if (!page || page.groupStart !== event.group || page.positionStart !== event.position) return reject('bad_page');
        s.rankedSelection = { group: event.group, position: event.position };
        journal('ranked_page', { group: event.group, position: event.position });
        return undefined;
      }

      case 'set_timer': {
        if (s.phase !== 'responses_open') return reject('no_open_round');
        if (event.seconds !== null && !(Number.isInteger(event.seconds) && event.seconds >= 10 && event.seconds <= 600)) return reject('bad_payload');
        s.timer = event.seconds === null ? null : { durationS: event.seconds, startedAt: at, remainingS: null };
        journal('timer_set', { seconds: event.seconds });
        return undefined;
      }

      case 'replay': {
        if (event.entryIndex !== undefined && event.surfaceId !== undefined) return reject('ambiguous_replay_target');
        let target = null;
        if (event.entryIndex !== undefined) {
          if (event.entryIndex !== null && !(Number.isSafeInteger(event.entryIndex) && event.entryIndex >= 0 && event.entryIndex < s.revealed.length)) return reject('not_revealed');
          target = event.entryIndex;
        } else if (event.surfaceId !== undefined && event.surfaceId !== null) {
          target = s.revealed.findLastIndex((r) => r.surfaceId === event.surfaceId);
          if (target < 0) return reject('not_revealed');
        }
        s.display.cursor = target === s.revealed.length - 1 ? null : target;
        s.display.revision += 1;
        displayBumped = true;
        return undefined;
      }

      case 'show_lobby': {
        // The projector returns to the lobby join screen mid-case (CASE-176): a display layer over the phase.
        // Only display.lobby and display.revision change; phones are not told (their view is identical).
        if (typeof event.on !== 'boolean') return reject('bad_payload');
        if (s.phase === 'lobby') return reject('already_in_lobby');
        if (s.manual) return reject('manual_room');
        if (event.on === lobbyShown(s)) return reject('no_change');
        s.display.lobby = event.on;
        s.display.revision += 1;
        displayBumped = true;
        journal('lobby_shown', { on: event.on });
        return undefined;
      }

      case 'enter_manual': {
        if (s.manual) return reject('already_manual');
        if (!UUID.test(event.segmentId || '')) return reject('bad_payload');
        if (s.manualSegments.some((m) => m.segmentId === event.segmentId)) return reject('segment_reused');
        // Inside an open or locked round, entering manual mode voids that round first, as ONE
        // command: the facilitator may be offline and cannot send void_round separately (CASE-071).
        const inRound = ['responses_open', 'responses_locked'].includes(s.phase)
          || (s.phase === 'discussion_paused' && ['responses_open', 'responses_locked'].includes(s.resumePhase));
        if (inRound) {
          closeRound('abandoned');
          s.timer = null;
          if (s.phase === 'discussion_paused') s.resumePhase = 'surface_live';
          else s.phase = 'surface_live';
        }
        if (!isStableBoundary(s)) return reject('not_a_stable_boundary');
        // An outage tool: the same-PC projector follows the manual projection, so the lobby layer ends (CASE-176).
        if (s.display.lobby) { s.display.lobby = false; s.display.revision += 1; displayBumped = true; }
        s.epoch += 1;
        s.manual = { segmentId: event.segmentId, startedAt: at, markers: [] };
        journal('manual_entered', { segmentId: event.segmentId });
        return undefined;
      }

      case 'manual_marker': {
        if (!s.manual) return reject('not_manual');
        // The console keeps marker text on the device and uploads it empty (SCREENS §Manual room
        // mode); an empty marker is still a marker, counted by ordinal.
        const text = cleanText(event.text, 200) || null;
        s.manual.markers.push({ text, at });
        // Free text never enters the journal (it outlives the 24 h purge); only its ordinal does.
        journal('manual_marker', { segmentId: s.manual.segmentId, markerNo: s.manual.markers.length });
        return undefined;
      }

      case 'resume_online': {
        if (!s.manual) return reject('not_manual');
        if (s.phase === 'path_selected' || s.resumePhase === 'path_selected') return reject('reveal_or_clear_selection_first');
        s.manualSegments.push({ segmentId: s.manual.segmentId, startedAt: s.manual.startedAt, endedAt: at, markers: s.manual.markers.length });
        journal('manual_exited', { segmentId: s.manual.segmentId });
        s.manual = null;
        s.epoch += 1;
        return undefined;
      }

      case 'takeover': {
        // A new facilitator device claims the room; every older tab is fenced out.
        s.epoch += 1;
        journal('facilitator_takeover', {});
        return undefined;
      }

      case 'close_joining': {
        if (typeof event.closed !== 'boolean') return reject('bad_payload');
        s.joiningClosed = event.closed;
        journal('joining_closed', { closed: event.closed });
        return undefined;
      }

      case 'end': {
        if (s.round && ['open', 'locked'].includes(s.round.status)) closeRound('abandoned');
        if (s.manual) {
          s.manualSegments.push({ segmentId: s.manual.segmentId, startedAt: s.manual.startedAt, endedAt: at, markers: s.manual.markers.length });
          s.manual = null;
        }
        s.rankedSelection = { group: 0, position: 0 };
        s.phase = 'ended';
        s.resumePhase = null;
        s.timer = null;
        s.endedAt = at;
        journal('room_ended', {});
        return undefined;
      }
    }
    return reject('unknown_command');
  }

  function vote() {
    const pid = event.actor.id;
    const p = s.participants[pid];
    if (!event.clientEventId) return reject('missing_client_event_id');
    if (!p || p.removedAt) return reject('unknown_participant');
    if (s.manual) return reject('manual_room');
    const known = s.round?.id === event.roundId ? s.round : null;
    if (!known) {
      const old = s.rounds.find((r) => r.id === event.roundId);
      if (old?.status === 'abandoned') return reject('round_voided');
      return old ? reject('round_closed', 'locked') : reject('unknown_round');
    }
    if (s.phase === 'discussion_paused' && s.resumePhase === 'responses_open') return reject('paused', 'paused_held');
    if (s.phase !== 'responses_open') return reject('round_locked', 'locked');
    const decision = I.decisions.get(known.decisionId);
    const response = normaliseResponse(decision, event.response, s.disabledOptions[decision.id] || []);
    if (!response) return reject('bad_response');
    const prior = known.responses[pid];
    if (!prior && !UUID.test(event.responseId || '')) return reject('missing_response_id'); // minted by the server (wire.buildEvent)
    // A free-text answer that looks like a patient identifier is flagged for the facilitator (spec red
    // team 2, P2). The flag carries kinds only, never the matched text, and changes nothing else.
    const idFlags = response.text !== undefined ? identifierKinds(response.text) : [];
    known.responses[pid] = {
      id: prior?.id ?? event.responseId,
      response,
      clientEventId: event.clientEventId ?? null,
      firstAt: prior?.firstAt ?? at,
      lastAt: at,
      ...(idFlags.length ? { idFlags } : {}),
    };
    journal('response_recorded', { roundId: known.id, participantId: pid });
    return undefined;
  }

  function enterBeat(beatId) {
    const beat = I.beats.get(beatId);
    if (!beat) return reject('unknown_beat');
    for (const k of beat.requires_flags || []) if (!s.flags.includes(k)) return reject('entry_flags_unmet');
    s.checkpoints[beat.id] = { flags: [...s.flags] };
    s.rankedSelection = { group: 0, position: 0 };
    s.beatId = beat.id;
    revealSurface(beat.surface_id, { kind: 'live' });
    if (beat.kind === 'decision') {
      s.decisionId = beat.decision_id;
      s.nextBeatId = null;
      journal('beat_entered', { beatId: beat.id, decisionId: beat.decision_id });
      // A decision first presents its authored context; even a direct start/advance cannot open
      // responses until the facilitator has deliberately revealed every populated group.
      s.phase = 'surface_live';
    } else {
      s.decisionId = null;
      s.nextBeatId = beat.next_beat_id ?? null;
      s.phase = 'surface_live';
      journal('beat_entered', { beatId: beat.id });
    }
    return undefined;
  }

  function openRound() {
    const decision = I.decisions.get(s.decisionId);
    const no = s.rounds.filter((r) => r.decisionId === decision.id).length + 1;
    if (!UUID.test(event.roundId || '')) return reject('missing_round_id');
    s.round = { id: event.roundId, decisionId: decision.id, no, status: 'open', openedAt: at, lockedAt: null, responses: {}, aggregate: null, suggestion: null };
    s.resultsShown = true;
    s.resultsPage = 0;
    s.rankedSelection = { group: 0, position: 0 };
    s.timer = decision.timer_s ? { durationS: decision.timer_s, startedAt: at, remainingS: null } : null;
    s.phase = 'responses_open';
    journal('responses_opened', { roundId: s.round.id, decisionId: decision.id, roundNo: no });
    return undefined;
  }

  function closeRound(status) {
    const r = s.round;
    if (status === 'abandoned') s.rankedSelection = { group: 0, position: 0 };
    s.rounds.push({
      id: r.id, decisionId: r.decisionId, no: r.no, status, openedAt: r.openedAt, lockedAt: r.lockedAt,
      closedAt: at, aggregate: status === 'abandoned' ? null : r.aggregate,
      selectedPathId: r.selectedPathId ?? null, resolutionKind: r.resolutionKind ?? null,
      // per-participant answers survive for the private recap only; never projected publicly
      answers: status === 'abandoned' ? {} : Object.fromEntries(Object.entries(r.responses).map(([pid, x]) => [pid, x.response])),
    });
    journal('round_closed', { roundId: r.id, status });
    s.round = null;
  }

  function revealSurface(surfaceId, { pathId = null, kind }) {
    const surface = I.surfaces.get(surfaceId);
    const variant = (surface.variants || []).findIndex((v) => v.when_flags.every((k) => s.flags.includes(k)));
    const entry = { surfaceId, beatId: s.beatId, pathId, kind, variant, manual: Boolean(s.manual), at, groupsShown: 0 };
    entry.groupsShown = Math.min(1, groupsForEntry(s, entry).length);
    s.revealed.push(entry);
    s.liveSurfaceId = surfaceId;
  }

  function applyFlags(set = [], clear = []) {
    s.flags = [...new Set([...s.flags, ...set])].filter((k) => !clear.includes(k));
  }

  function resolutionKind(pathId) {
    // `majority` only when votes actually favoured this path; a fallback (no votes, tie) is not a majority.
    if (s.round?.suggestion?.pathId === pathId && ['plurality', 'rules'].includes(s.round.suggestion.kind)) return 'majority';
    const decision = I.decisions.get(s.decisionId);
    const path = I.paths.get(pathId);
    const anyone = Object.values(s.round?.responses || {}).some(({ response }) => {
      if (decision.interaction.type === 'single_choice') return (path.option_ids || []).includes(response.option_id);
      return suggestPath(decision, [response]).path_id === pathId;
    });
    return anyone ? 'minority' : 'override';
  }
}

// ─── idempotency and manual segments ────────────────────────────────────────

/**
 * Stable key and payload fingerprint for idempotency. The key is scoped to the sender, so one
 * participant can never collide with another's client_event_id.
 */
export function ledgerKey(event) {
  return `${event.actor?.role}:${event.actor?.id ?? ''}:${event.clientEventId}`;
}
function fingerprint(event) {
  const { at, epoch, actor, clientEventId, responseId, roundId, expectRevision, ...payload } = event;
  return stableStringify(payload);
}
function stableStringify(v) {
  if (Array.isArray(v)) return `[${v.map(stableStringify).join(',')}]`;
  if (v && typeof v === 'object') return `{${Object.keys(v).sort().map((k) => `${JSON.stringify(k)}:${stableStringify(v[k])}`).join(',')}}`;
  return JSON.stringify(v);
}

/**
 * reduce() plus idempotency. `ledger` is any { get(key), set(key, value) } store: a Map in
 * tests, the Durable Object's `receipts` table in production (pruned by age, not by count).
 * Receipts live OUTSIDE reducer state, so state stays small and cheap to copy.
 *   • same client_event_id and same payload → the original outcome (`already_accepted`)
 *   • same client_event_id, different payload → `rejected: client_event_id_reused`
 *   • only `accepted` is remembered; other outcomes may legitimately be retried
 */
export function dispatch(state, event, ledger) {
  if (!event?.clientEventId) return reduce(state, event);
  const key = ledgerKey(event);
  const seen = ledger.get(key);
  if (seen) {
    const same = seen.fingerprint === fingerprint(event);
    return { state, effects: [{ type: 'receipt', clientEventId: event.clientEventId, receipt: same ? 'already_accepted' : 'rejected', ...(same ? {} : { reason: 'client_event_id_reused' }) }] };
  }
  const r = reduce(state, event);
  if (r.effects[0]?.receipt === 'accepted') ledger.set(key, { fingerprint: fingerprint(event), at: r.state.lastAt });
  return r;
}

/**
 * Replays a facilitator's manual segment all-or-nothing (HANDOFF §Manual room and recovery).
 * Every event must be accepted; otherwise nothing is applied and the first failure is named.
 * @returns {{ ok: boolean, state: object, effects: object[], failedAt?: number, reason?: string }}
 */
export function applySegment(state, events, ledger) {
  let s = state;
  const effects = [];
  const staged = new Map();
  const view = { get: (k) => staged.get(k) ?? ledger.get(k), set: (k, v) => staged.set(k, v) };
  for (let i = 0; i < events.length; i++) {
    // Presentation targets a particular frozen closure. Server participant activity
    // may advance the session revision during an outage; only this manual command
    // uses the staged revision. Epoch, target identity and receipts still fence it.
    const event = events[i].type === 'ranked_page' && s.manual ?
      { ...events[i], expectRevision: s.revision } : events[i];
    const r = dispatch(s, event, view);
    const receipt = r.effects.find((e) => e.type === 'receipt');
    if (receipt && !['accepted', 'already_accepted'].includes(receipt.receipt)) {
      return { ok: false, state, effects: [], failedAt: i, reason: receipt.reason ?? receipt.receipt };
    }
    s = r.state;
    effects.push(...r.effects);
  }
  for (const [k, v] of staged) ledger.set(k, v);
  return { ok: true, state: s, effects };
}

function cleanName(n) {
  return cleanText(n, NAME_MAX) || null;
}
/** Only an allow-listed avatar id is ever stored (CASE-119); the wire refuses anything else first. */
function avatarOf(id) {
  return isAvatarId(id) ? id : null;
}

/** Validates a participant response against the decision; returns the normalised response or null. */
export function normaliseResponse(decision, response, disabled = []) {
  if (!response || typeof response !== 'object') return null;
  const it = decision.interaction;
  const options = new Set((it.options || []).map((o) => o.id).filter((id) => !disabled.includes(id)));
  switch (it.type) {
    case 'single_choice':
      return options.has(response.option_id) ? { option_id: response.option_id } : null;
    case 'multi_select': {
      const ids = response.option_ids;
      if (!Array.isArray(ids) || ids.length === 0 || new Set(ids).size !== ids.length || !ids.every((o) => options.has(o))) return null;
      return { option_ids: [...ids] };
    }
    case 'ranking': {
      const order = response.order;
      const need = it.rank_count ?? options.size;
      if (!Array.isArray(order) || order.length === 0 || order.length !== need || new Set(order).size !== order.length || !order.every((o) => options.has(o))) return null;
      return { order: [...order] };
    }
    case 'free_text': {
      const text = cleanText(response.text, FREE_TEXT_MAX);
      if (!text || text.length > it.max_length) return null;
      return { text };
    }
  }
  return null;
}

// ─── projections ─────────────────────────────────────────────────────────────

function surfaceView(I, entry, { state = null, facilitator = false } = {}) {
  const s = I.surfaces.get(entry.surfaceId);
  const v = entry.variant >= 0 ? s.variants[entry.variant] : s;
  const prev = state ? previousObservations(I, state, entry) : null;
  const view = {
    surfaceId: s.id, kind: s.kind, title: s.title,
    // These authored groups are assembled here; the public projection below releases them
    // one group at a time. The facilitator keeps the complete surface in memory.
    scene: v.scene ?? s.scene ?? null, points: [...v.points], investigations: [...(v.investigations ?? s.investigations ?? [])],
    ...(facilitator ? { notes: v.notes ?? s.notes ?? null } : {}),
    observations: (s.observations ?? []).map((o) => {
      const t = trend(prev?.get(o.label), o.value);
      // `previous` is the value the room last saw, shown beside the arrow (CASE-090).
      return { ...o, trend: t, previous: t ? String(prev.get(o.label)).replace(/\s*\(.*\)$/, '') : null }; // `14 (E3 V5 M6)` → `14`
    }),
    assetIds: s.asset_ids ?? [],
    timelineKind: entry.kind, manual: entry.manual, at: entry.at,
  };
  return facilitator ? view : publicPresentationSurface(view, entry.groupsShown);
}

/**
 * The entries on the path the room is now on, up to (not including) index `end`. A checkpoint reset
 * re-enters a beat the room already saw; everything revealed after that beat's earlier entry was the
 * abandoned branch, so it is dropped (walkthrough bug: the trend compared against the arrest scene).
 */
function pathBefore(revealed, end) {
  const path = [];
  const cut = (e) => {
    if (e.kind !== 'live' || !e.beatId) return;
    for (let j = path.length - 1; j >= 0; j--) if (path[j].kind === 'live' && path[j].beatId === e.beatId) { path.length = j; return; }
  };
  for (let k = 0; k < end; k++) { cut(revealed[k]); path.push(revealed[k]); }
  if (end < revealed.length) cut(revealed[end]);
  return path;
}

/** The observations of the last scene the room saw before `entry`, on the restored path (CASE-090 trend arrows). */
function previousObservations(I, state, entry) {
  const i = state.revealed.indexOf(entry);
  const path = pathBefore(state.revealed, i < 0 ? state.revealed.length : i);
  for (let k = path.length - 1; k >= 0; k--) {
    const prior = path[k];
    const observationIndex = groupsForEntry(state, prior).indexOf('observations');
    if (observationIndex < 0 || prior.groupsShown <= observationIndex) continue;
    const obs = I.surfaces.get(prior.surfaceId).observations;
    if (obs?.length) return new Map(obs.map((o) => [o.label, o.value]));
  }
  return null;
}

/** 'up' | 'down' | null, from the leading number (systolic for a BP, the total for a GCS). */
function trend(before, now) {
  const n = (x) => Number.parseFloat(String(x ?? '').replace(/^[^0-9.-]*/, ''));
  const a = n(before);
  const b = n(now);
  if (!Number.isFinite(a) || !Number.isFinite(b) || a === b) return null;
  return b > a ? 'up' : 'down';
}

function lastEntryFor(state, surfaceId) {
  for (let i = state.revealed.length - 1; i >= 0; i--) if (state.revealed[i].surfaceId === surfaceId) return state.revealed[i];
  return null;
}

function publicDecision(I, state) {
  if (!state.decisionId) return null;
  const d = I.decisions.get(state.decisionId);
  const disabled = state.disabledOptions[d.id] || [];
  const explored = new Set(d.paths.filter((p) => state.exploredTerminal.includes(p.id)).flatMap((p) => p.option_ids || []));
  // ONE order for every screen (CASE-088): clients mark options by position with a shared glyph
  // and colour, so the projector and every phone agree on "the blue diamond".
  const options = (d.interaction.options || []).map((o) => ({ id: o.id, label: o.label, disabled: disabled.includes(o.id), explored: explored.has(o.id) }));
  return {
    decisionId: d.id,
    prompt: d.prompt,
    interaction: {
      type: d.interaction.type,
      options,
      maxLength: d.interaction.max_length ?? null,
      rankCount: d.interaction.rank_count ?? null,
    },
  };
}

/** The answer's path, for recap teaching: option mapping for single choice, rules otherwise. */
function pathOfResponse(I, decisionId, response) {
  if (!response) return null;
  const d = I.decisions.get(decisionId);
  if (d.interaction.type === 'single_choice') return d.paths.find((p) => (p.option_ids || []).includes(response.option_id)) ?? null;
  return d.paths.find((p) => p.id === suggestPath(d, [response]).path_id) ?? null;
}

/** What a per-option count means for an interaction type (room-result copy, spec red team 2 P2). */
const COUNT_MEANING = { single_choice: 'chose', multi_select: 'selected', ranking: 'ranked_first', free_text: null };

/** The option ids a response counts towards: the choice, every selection, or the first-ranked option. */
function countedOptionIds(response) {
  if (!response) return [];
  if (response.option_id) return [response.option_id];
  if (response.option_ids) return [...response.option_ids];
  if (response.order) return response.order.slice(0, 1);
  return [];
}

/** Keep an explicit authored length; old closed defaults need actual complete answers, never guessed positions. */
function closedRankCount(decision, round) {
  if (decision.interaction.rank_count !== undefined) return decision.interaction.rank_count;
  if (Number.isInteger(round.aggregate.rankCount)) return round.aggregate.rankCount;
  const answers = round.responses ? Object.values(round.responses).map(row => row.response) : Object.values(round.answers ?? {});
  if (answers.length !== round.aggregate.total || !answers.length) return null;
  const length = answers[0]?.order?.length;
  return Number.isInteger(length) && length > 0 && answers.every(answer => answer.order?.length === length) ? length : null;
}

function zeroEligibleResult(decision, round) {
  return decision.interaction.type === 'ranking' && decision.interaction.rank_count === undefined
    && round.aggregate.rankCount === 0 && round.aggregate.total === 0
    && Array.isArray(round.aggregate.eligibleOptionIds) && round.aggregate.eligibleOptionIds.length === 0
    && Object.values(round.aggregate.counts).every(count => count === 0)
    && Object.keys(round.responses ?? round.answers ?? {}).length === 0;
}

function rankingPositions(decision, round) {
  if (round.aggregate.positionCounts) return round.aggregate.positionCounts;
  const answers = round.responses ? Object.values(round.responses).map(row => row.response) : Object.values(round.answers ?? {});
  if (answers.length !== round.aggregate.total) return null;
  const rankCount = closedRankCount(decision, round);
  if (rankCount === null || rankCount < 1) return null;
  const counts = Object.fromEntries(decision.interaction.options.map(option => [option.id, Array(rankCount).fill(0)]));
  for (const answer of answers) {
    if (!Array.isArray(answer.order) || answer.order.length !== rankCount || new Set(answer.order).size !== rankCount
      || answer.order.some(id => !Object.hasOwn(counts, id))) return null;
    answer.order.forEach((id, position) => { counts[id][position]++; });
  }
  return counts;
}

/**
 * The room's result for the most recently revealed round (CASE-080): shown to the projector and
 * phones only AFTER its consequence is revealed, and only while that consequence is still the live
 * surface: it is gone when the room moves to the next surface (the debrief, say) or the next round
 * opens, so it can never anchor a vote. Per-option counts are always shown, however few answered
 * (Julian, CASE-104). Free text is never counted or projected (CASE-105).
 */
function lastResult(I, state) {
  if (state.round) return null;
  const r = [...state.rounds].reverse().find((x) => x.status === 'resolved');
  if (!r || !r.aggregate) return null;
  const live = state.revealed.at(-1);
  if (!live || live.kind === 'live' || live.pathId !== r.selectedPathId) return null; // walkthrough bug 1
  const d = I.decisions.get(r.decisionId);
  const type = d.interaction.type;
  if (type === 'ranking' && closedRankCount(d, r) === 0 && !zeroEligibleResult(d, r)) return null;
  const opts = type === 'free_text' || zeroEligibleResult(d, r) ? [] : d.interaction.options || [];
  const positions = type === 'ranking' && !zeroEligibleResult(d, r) ? rankingPositions(d, r) : null;
  const counts = opts.map((o) => ({ optionId: o.id, label: o.label, count: r.aggregate.counts[o.id] ?? 0,
    ...(positions ? { positionCounts: positions[o.id] } : {}) }));
  const top = Math.max(0, ...counts.map((c) => c.count));
  return {
    decisionId: d.id, prompt: d.prompt, roundNo: r.no, total: r.aggregate.total,
    countMeaning: COUNT_MEANING[type] ?? null,
    ...(positions ? { rankCount: closedRankCount(d, r) } : {}),
    counts,
    // A tie at the top of a single choice: the copy says "the room was split", not a majority.
    split: type === 'single_choice' && top > 0 && counts.filter((c) => c.count === top).length > 1,
    howChosen: r.resolutionKind, // majority | minority | override
    whatHappened: I.surfaces.get(live.surfaceId).title,
  };
}

const PUBLIC_PHASE = {
  lobby: 'waiting', surface_live: 'live', responses_open: 'decision_open', responses_locked: 'reviewing',
  path_selected: 'reviewing', consequence_revealed: 'live', terminal_teaching: 'teaching',
  discussion_paused: 'paused', ended: 'ended',
};

/** A chart is eligible only for an actually locked round or its still-live consequence. */
function closedResponseRound(I, state) {
  if (state.phase === 'ended' || state.round?.status === 'open') return null;
  if (state.round?.status === 'locked') return state.round;
  const result = lastResult(I, state);
  return result ? [...state.rounds].reverse().find(round => round.status === 'resolved') : null;
}

/** Only an actually displayed live chart can obscure newly published case context. */
function responsesBlockPublication(I, state) {
  return state.resultsShown !== false && state.display.cursor === null
    && (responseResult(I, state) !== null || lastResult(I, state) !== null);
}

function responseResult(I, state) {
  if (state.resultsShown === false || state.display.cursor !== null) return null;
  const round = closedResponseRound(I, state);
  if (!round?.aggregate) return null;
  const decision = I.decisions.get(round.decisionId);
  const type = decision.interaction.type;
  const options = type === 'free_text' ? [] : decision.interaction.options ?? [];
  const zero = zeroEligibleResult(decision, round);
  if (zero) {
    const current = projectorDecision(I, state);
    if (!current || current.interaction.rankCount !== null || current.interaction.options.some(option => !option.disabled)) return null;
    return { decisionId: decision.id, prompt: decision.prompt, roundNo: round.no, type, total: 0, rankCount: null, counts: [] };
  }
  const rankCount = type === 'ranking' ? closedRankCount(decision, round) : null;
  const positions = rankCount === null ? null : rankingPositions(decision, round);
  if (type === 'ranking' && (rankCount === null || rankCount < 1 || !positions)) return null;
  return {
    decisionId: decision.id, prompt: decision.prompt, roundNo: round.no,
    type, total: round.aggregate.total, rankCount,
    ...(type === 'ranking' && rankedPage(decision, round.aggregate, state.rankedSelection)
      ? { ranked: rankedPage(decision, round.aggregate, state.rankedSelection) } : {}),
    counts: options.map(option => ({ optionId: option.id, label: option.label, count: round.aggregate.counts[option.id] ?? 0,
      positionCounts: rankCount === null ? null : positions[option.id] })),
  };
}

function projectorDecision(I, state) {
  const from = state.phase === 'discussion_paused' ? state.resumePhase : state.phase;
  const current = state.revealed.at(-1);
  const manualPending = state.manual && from === 'surface_live' && state.decisionId
    && current && current.groupsShown === groupsForEntry(state, current).length;
  if (!state.decisionId || !(['responses_open', 'responses_locked', 'path_selected'].includes(from) || manualPending)) return null;
  const status = state.manual ? 'manual' : state.phase === 'discussion_paused' ? 'paused' : from === 'responses_open' ? 'open' : 'locked';
  const { decisionId, prompt, interaction } = publicDecision(I, state);
  const rankCount = interaction.type === 'ranking' ? (state.round?.aggregate ? closedRankCount(I.decisions.get(decisionId), state.round) : interaction.rankCount ?? interaction.options.filter(option => !option.disabled).length) : null;
  return { decisionId, prompt, status, interaction: { type: interaction.type, options: interaction.options, rankCount: rankCount === 0 ? null : rankCount } };
}

/**
 * What a role may see. Display and participant projections never include unrevealed surfaces,
 * paths, cues, classifications, suggestions, or other participants' answers. Closed anonymous
 * counts reach the display; phones receive their result only after the consequence.
 */
export function project(state, role, participantId = null, inputs = {}) {
  state = normalizePresentationState(state);
  const I = idx(state);
  const sv = (e) => surfaceView(I, e, { state, facilitator: role === 'facilitator' });
  const live = state.liveSurfaceId ? sv(lastEntryFor(state, state.liveSurfaceId)) : null;
  const active = Object.entries(state.participants).filter(([, p]) => !p.removedAt);
  // `{k} of {m} answered` counts m from the people actually connected (spec red team 2, P1-7). Presence
  // is not reducer state: the Durable Object passes it in (`inputs.present`, participant ids with a
  // live socket or recent HTTP activity), so the reducer stays pure. Anyone who has answered this round
  // counts too, so k never exceeds m. Without presence (lab, tests, rebuild checks) m is everyone.
  const present = inputs.present ? new Set(inputs.present) : null;
  const answered = state.round ? state.round.responses : {};
  const presentCount = present ? active.filter(([id]) => present.has(id) || answered[id]).length : active.length;
  const roundOpen = state.phase === 'responses_open' || (state.phase === 'discussion_paused' && state.resumePhase === 'responses_open');
  const meta = {
    caseTitle: state.caseDoc.title, caseVersionNo: state.caseVersionNo ?? null,
    // The one exception to hard rule 1 (CASE-164): numbers only, re-checked on the way out.
    art: sanitizeArt(state.art ?? null),
    // The frozen group tint, an enum name (CASE-172); a room from before card 30 projects none.
    ...(state.tint === undefined ? {} : { tint: tintOf(state.tint) }),
    endedAt: state.endedAt, recapExpiresAt: state.endedAt ? new Date(Date.parse(state.endedAt) + RECAP_TTL_MS).toISOString() : null,
  };
  // Advisory timer: everyone may see the time remaining; it never locks anything by itself.
  const timer = state.timer && roundOpen ? (state.timer.remainingS !== null
    ? { paused: true, remainingS: state.timer.remainingS }
    : { paused: false, endsAt: new Date(Date.parse(state.timer.startedAt) + state.timer.durationS * 1000).toISOString() }) : null;

  // The lobby screen layer (CASE-176): exactly the lobby's keys, from the lobby's public fields only. No surface,
  // decision, option, prompt, result, timer or presentation group. Mid-case the names keep their hidden state
  // (CASE-133): avatars only until Show names; with no counts shown, names may appear when shown.
  if (role === 'display' && lobbyShown(state)) {
    return {
      role, sessionId: state.sessionId, joinCode: state.joinCode, epoch: state.epoch,
      revision: state.revision, displayRevision: state.display.revision, ...meta, timer: null,
      phase: PUBLIC_PHASE.lobby, manual: false, joiningClosed: state.joiningClosed, replay: false, surface: null, decision: null,
      counts: { participants: active.length, present: presentCount, responded: null },
      avatars: state.namesShown ? null : active.map(([, p]) => p.avatarId ?? null),
      names: state.namesShown ? active.filter(([, p]) => p.name).map(([, p]) => ({ name: p.name, avatarId: p.avatarId ?? null })) : null,
      arrivalCount: state.arrivalCount ?? Object.keys(state.participants).length,
      resultsShown: true, resultsPage: 0, responseResult: null, lastResult: null,
    };
  }

  if (role === 'display') {
    const cursor = state.display.cursor;
    const selected = Number.isSafeInteger(cursor) ? state.revealed[cursor]
      : typeof cursor === 'string' ? lastEntryFor(state, cursor) : null;
    const displayedResponse = responseResult(I, state);
    const displayedLast = state.resultsShown === false || cursor !== null ? null : lastResult(I, state);
    const answerCountsVisible = displayedResponse !== null || displayedLast !== null;
    return {
      role, sessionId: state.sessionId, joinCode: state.joinCode, epoch: state.epoch,
      revision: state.revision, displayRevision: state.display.revision, ...meta, timer,
      phase: PUBLIC_PHASE[state.phase], manual: Boolean(state.manual),
      joiningClosed: state.joiningClosed, // the projector hides its join route (stage C finding)
      replay: selected !== null && selected !== undefined,
      surface: selected ? sv(selected) : live,
      // The options are always on the projector while a decision is in play (CASE-089), so people
      // without a phone can follow and say their pick; the separate responseResult carries anonymous
      // counts only after responses close, never the route being considered.
      decision: projectorDecision(I, state),
      // No answered count while names are on the projector: with names up, a count lets the room work
      // out who has not answered (spec red team 2, P2).
      counts: {
        participants: active.length, present: presentCount,
        responded: state.phase === 'responses_open' && !state.namesShown ? Object.keys(state.round.responses).length : null,
      },
      // Avatars alone may reach the projector before Show names (CASE-133). No participant ids or
      // names accompany them; the named projection replaces this list after the explicit reveal.
      avatars: answerCountsVisible || state.namesShown || state.phase === 'lobby' ? null : active.map(([, p]) => p.avatarId ?? null),
      // Names with their avatars, for the projector's `In the room` chips (CASE-119).
      names: !answerCountsVisible && (state.namesShown || state.phase === 'lobby') ? active.filter(([, p]) => p.name).map(([, p]) => ({ name: p.name, avatarId: p.avatarId ?? null })) : null,
      arrivalCount: state.arrivalCount ?? Object.keys(state.participants).length,
      resultsShown: state.resultsShown !== false,
      resultsPage: Number.isInteger(state.resultsPage) && state.resultsPage >= 0 && state.resultsPage <= 3 ? state.resultsPage : 0,
      responseResult: displayedResponse,
      lastResult: displayedLast,
    };
  }

  if (role === 'participant') {
    const me = state.participants[participantId];
    const decisionVisible = state.round && ['open', 'locked'].includes(state.round.status);
    const mine = decisionVisible ? state.round.responses[participantId]?.response ?? null : null;
    let decision = null;
    if (decisionVisible) {
      decision = {
        ...publicDecision(I, state, participantId),
        roundId: state.round.id,
        roundNo: state.round.no,
        status: state.phase === 'responses_open' ? 'open' : roundOpen ? 'held' : 'locked',
        yourResponse: mine,
      };
    }
    const labelOf = (decisionId, response) => {
      if (!response) return null;
      const opts = I.decisions.get(decisionId).interaction.options || [];
      const l = (id) => opts.find((o) => o.id === id)?.label ?? id;
      if (response.option_id) return l(response.option_id);
      if (response.option_ids) return response.option_ids.map(l).join(', ');
      if (response.order) return response.order.map(l).join(' → ');
      return response.text ?? null;
    };
    const recap = state.phase === 'ended' && me ? {
      caseTitle: meta.caseTitle, caseVersionNo: meta.caseVersionNo, expiresAt: meta.recapExpiresAt,
      learningPoints: [...state.caseDoc.learning_objectives],
      rounds: state.rounds.filter((r) => r.status === 'resolved' || r.status === 'superseded').map((r) => {
        // What the team saw happen: the public consequence surface revealed for this round's path.
        const shown = r.selectedPathId ? state.revealed.find((e) => e.pathId === r.selectedPathId) : null;
        // After the session the recap teaches (CASE-082): your answer's classification and why,
        // and what the recommended path was if you chose differently.
        const mine = pathOfResponse(I, r.decisionId, r.answers[participantId]);
        const d = I.decisions.get(r.decisionId);
        const rec = d.paths.find((x) => x.recommended);
        const recLabel = rec ? (d.interaction.options || []).filter((o) => (rec.option_ids || []).includes(o.id)).map((o) => o.label).join(' / ') || rec.label : null;
        return {
          decisionId: r.decisionId, prompt: d.prompt, roundNo: r.no, status: r.status,
          optionIds: (d.interaction.options || []).map((o) => o.id), // the shared order, for the marks (CASE-088)
          yourResponse: r.answers[participantId] ?? null,
          yourAnswer: labelOf(r.decisionId, r.answers[participantId]),
          yourClassification: mine?.classification ?? null,
          why: mine?.rationale ?? null,
          doDifferently: mine && !mine.recommended && recLabel ? `Recommended here: ${recLabel}. ${rec.rationale}` : null,
          teamChoice: r.resolutionKind ?? null,
          whatHappened: shown ? I.surfaces.get(shown.surfaceId).title : null,
        };
      }),
      teamPath: state.revealed.filter((e) => e.kind !== 'live').map((e) => I.surfaces.get(e.surfaceId).title),
    } : null;
    const last = state.rounds.at(-1);
    const lastRound = last ? { roundId: last.id, roundNo: last.no, status: last.status } : null;
    const result = lastResult(I, state);
    if (result) {
      const r = [...state.rounds].reverse().find((x) => x.status === 'resolved');
      // The phone's own answer only: its words, and the option ids it counted towards (the marks).
      result.yourAnswer = result.countMeaning ? labelOf(r.decisionId, r.answers[participantId]) : null;
      result.yourOptionIds = countedOptionIds(r.answers[participantId]);
      result.youAnswered = Boolean(r.answers[participantId]);
    }
    return {
      role, sessionId: state.sessionId, epoch: state.epoch, revision: state.revision, ...meta, timer, lastRound,
      phase: PUBLIC_PHASE[state.phase], manual: Boolean(state.manual),
      you: me ? { id: participantId, name: me.name, avatarId: me.avatarId ?? null, removed: Boolean(me.removedAt) } : null,
      liveSurface: live,
      timeline: state.revealed.map(sv),
      decision,
      lastResult: result,
      recap,
    };
  }

  if (role === 'facilitator') {
    const decision = state.decisionId ? I.decisions.get(state.decisionId) : null;
    const beat = state.beatId ? I.beats.get(state.beatId) : null;
    const next = state.nextBeatId ? I.beats.get(state.nextBeatId) : null;
    const presentationEntry = state.revealed.at(-1);
    const presentationGroups = groupsForEntry(state, presentationEntry);
    const displayCursor = state.display.cursor;
    const displayEntry = Number.isSafeInteger(displayCursor) ? state.revealed[displayCursor]
      : typeof displayCursor === 'string' ? lastEntryFor(state, displayCursor)
        : state.liveSurfaceId ? lastEntryFor(state, state.liveSurfaceId) : null;
    const presentation = presentationEntry ? {
      entryIndex: state.revealed.length - 1,
      shown: presentationEntry.groupsShown,
      total: presentationGroups.length,
      nextGroup: presentationGroups[presentationEntry.groupsShown] ?? null,
      mediaUnavailable: Boolean(I.surfaces.get(presentationEntry.surfaceId)?.asset_ids?.length),
    } : null;
    const names = Object.fromEntries(Object.entries(state.participants).map(([id, p]) => [id, p.name]));
    const avatars = Object.fromEntries(Object.entries(state.participants).map(([id, p]) => [id, p.avatarId ?? null]));
    return {
      role, sessionId: state.sessionId, joinCode: state.joinCode, epoch: state.epoch, revision: state.revision, ...meta,
      phase: state.phase, resumePhase: state.resumePhase,
      manual: state.manual ? { ...state.manual } : null,
      namesShown: state.namesShown,
      resultsShown: state.resultsShown !== false,
      resultsPage: Number.isInteger(state.resultsPage) && state.resultsPage >= 0 && state.resultsPage <= 3 ? state.resultsPage : 0,
      rankedRoundId: closedResponseRound(I, state)?.id ?? null,
      rankedSelection: state.rankedSelection ?? { group: 0, position: 0 },
      rankedPresentation: responseResult(I, state)?.ranked ?? null,
      rankedColumns: (() => { const round = closedResponseRound(I, state); return round?.aggregate?.completeOrders
        ? rankedLayout(I.decisions.get(round.decisionId).interaction.options, round.aggregate.rankCount, I.decisions.get(round.decisionId).prompt).columns : null; })(),
      rankedPositionSpan: (() => { const round = closedResponseRound(I, state); return round?.aggregate?.completeOrders
        ? rankedLayout(I.decisions.get(round.decisionId).interaction.options, round.aggregate.rankCount, I.decisions.get(round.decisionId).prompt).positions : null; })(),
      resultsPageCount: (() => { const result = responseResult(I, state); return result?.type === 'ranking' ? Math.ceil(result.counts.length / 2) : 1; })(),
      joiningClosed: state.joiningClosed,
      beat: beat ? { id: beat.id, kind: beat.kind, title: beat.title, cue: beat.cue ?? null } : null,
      nextBeat: next ? { id: next.id, kind: next.kind, title: next.title } : null,
      presentation,
      // The full timeline and live surface remain private to the facilitator. This separately
      // projected row is exactly what the projector shows, including an older replay's reveal count.
      publicDisplaySurface: displayEntry ? surfaceView(I, displayEntry, { state }) : null,
      liveSurface: live,
      timeline: state.revealed.map(sv),
      decision: decision ? {
        ...publicDecision(I, state),
        paths: decision.paths.map((p) => ({
          id: p.id, label: p.label, classification: p.classification, recommended: p.recommended === true,
          rationale: p.rationale, cue: p.cue, optionIds: p.option_ids ?? [],
          revealPreview: I.surfaces.get(p.reveal_surface_id).title,
          terminal: p.classification === 'terminal-unsafe', explored: state.exploredTerminal.includes(p.id),
        })),
      } : null,
      round: state.round ? {
        id: state.round.id, no: state.round.no, status: state.round.status,
        responseCount: Object.keys(state.round.responses).length, participantCount: presentCount,
        responses: Object.entries(state.round.responses).map(([pid, r]) => ({ participantId: pid, name: names[pid] ?? null, avatarId: avatars[pid] ?? null, response: r.response, at: r.lastAt, identifierFlags: r.idFlags ?? [] })),
        aggregate: state.round.aggregate, suggestion: state.round.suggestion,
      } : null,
      selectedPathId: state.selectedPathId, resolutionKind: state.resolutionKind,
      terminalPathId: state.terminalPathId,
      terminal: state.terminalPathId ? (() => {
        const tp = I.paths.get(state.terminalPathId);
        const cp = I.beats.get(tp.terminal.checkpoint_beat_id);
        return { pathId: tp.id, debriefPrompt: tp.terminal.debrief_prompt, checkpointBeat: { id: cp.id, title: cp.title } };
      })() : null,
      flags: [...state.flags],
      participants: Object.entries(state.participants).map(([id, p]) => ({ id, name: p.name, avatarId: p.avatarId ?? null, joinedAt: p.joinedAt, removed: Boolean(p.removedAt) })),
      rounds: state.rounds.map(({ answers, ...r }) => r),
      timer: state.timer,
      display: { ...state.display },
      actions: facilitatorActions(state),
    };
  }
  throw new TypeError(`unknown role: ${role}`);
}

/** The facilitator commands valid right now; clients render only these (HANDOFF §Three projections). */
export function facilitatorActions(state) {
  const a = [];
  const p = state.phase;
  const publicationBlocked = responsesBlockPublication(idx(state), state);
  if (p === 'ended') return a;
  if (p === 'lobby') a.push('start');
  const latest = state.revealed.at(-1);
  const moreGroups = latest && latest.groupsShown < groupsForEntry(state, latest).length;
  if (moreGroups && ['surface_live', 'consequence_revealed', 'terminal_teaching'].includes(p)) a.push('advance');
  else if (['surface_live', 'consequence_revealed'].includes(p)) {
    if (state.decisionId && p === 'surface_live') a.push(state.manual ? 'select_path' : 'advance');
    else if (state.nextBeatId) a.push('advance');
  }
  if (p === 'responses_open') a.push('lock', 'void_round', 'set_timer');
  if (p === 'responses_locked') a.push('select_path', 'reopen', 'void_round');
  if (p === 'path_selected') a.push('reveal', 'back_to_review');
  if (p === 'terminal_teaching') a.push('reset_checkpoint');
  if (p !== 'lobby' && p !== 'discussion_paused') a.push('pause');
  if (p === 'discussion_paused') a.push('resume');
  const inRound = ['responses_open', 'responses_locked'].includes(p) || (p === 'discussion_paused' && ['responses_open', 'responses_locked'].includes(state.resumePhase));
  if (!state.manual && (isStableBoundary(state) || inRound)) a.push('enter_manual');
  if (state.manual) a.push('manual_marker', ...(p === 'path_selected' || state.resumePhase === 'path_selected' ? [] : ['resume_online']));
  if (state.revealed.length) a.push('replay');
  if (p !== 'lobby' && !state.manual) a.push('show_lobby');
  if (closedResponseRound(idx(state), state) && state.display.cursor === null) a.push('show_results');
  const result = responseResult(idx(state), state);
  if (result?.ranked && result.ranked.totalGroups > 0) a.push('ranked_page');
  if (result?.type === 'ranking' && result.counts.length > 2) a.push('results_page');
  if (p !== 'lobby' && (!publicationBlocked || state.namesShown)) a.push('show_names');
  a.push('close_joining', 'takeover', 'remove_participant', 'rename', 'end');
  if (lobbyShown(state)) return a.filter(action => !LOBBY_BLOCKED.has(action));
  return publicationBlocked ? a.filter(action => !['reveal', 'advance', 'reset_checkpoint'].includes(action)) : a;
}
