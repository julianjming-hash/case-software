/** Shared text-only closed anonymous result rendering; callers supply their existing DOM and marks. */
import { responseSummary } from './response-summary.mjs';
import { markFor } from './projector-marks.mjs';

export function renderResponseResult(view, { el, markSvg }) {
  const r = view.responseResult;
  if (!r || view.replay) return null;
  const summary = responseSummary(r);
  const box = el('section', 'card result');
  box.setAttribute('aria-label', summary.heading);
  box.append(el('p', 'eyebrow', summary.heading), el('h2', null, r.prompt));
  if (r.type === 'ranking' && r.ranked) {
    renderRankedColumns(box, r, { el, markSvg });
    return box;
  }
  if (r.type === 'ranking' && summary.rows.length) {
    box.classList.add('rank-table-card');
    const table = el('table', 'rank-table');
    const head = el('tr');
    const option = el('th', null, 'Option'); option.scope = 'col'; head.append(option);
    for (const position of summary.rows[0].positions) {
      const th = el('th', null, `Rank ${position.rank}`); th.scope = 'col'; head.append(th);
    }
    const thead = el('thead'); thead.append(head); table.append(thead);
    const tbody = el('tbody');
    const first = (view.resultsPage ?? 0) * 2;
    const rows = summary.rows.slice(first, first + 2);
    for (const row of rows) {
      const tr = el('tr'); const label = el('th', null, row.label); label.scope = 'row'; tr.append(label);
      for (const position of row.positions) {
        const td = el('td', null, String(position.count)); td.setAttribute('aria-label', position.words); tr.append(td);
      }
      tbody.append(tr);
    }
    table.append(tbody); box.append(table);
    if (summary.rows.length > 2) box.append(el('p', 'results-page', `Options ${first + 1}–${first + rows.length} of ${summary.rows.length}`));
  } else if (summary.rows.length) {
    const ul = el('ul');
    const max = Math.max(1, ...summary.rows.map(row => row.count));
    summary.rows.forEach((row, i) => {
      const li = el('li');
      li.append(markSvg(i, { size: 32, decorative: false }), el('span', null, row.label));
      const bar = el('span', 'bar'); bar.setAttribute('aria-hidden', 'true');
      const fill = el('i'); fill.style.width = `${Math.round((row.count / max) * 100)}%`; bar.append(fill);
      li.append(bar, el('span', 'n', row.words));
      ul.append(li);
    });
    box.append(ul);
  }
  if (r.type === 'ranking' && r.total === 0 && !summary.rows.length) box.append(el('p', 'ranked-empty', 'No responses submitted.'));
  box.append(el('p', null, summary.caption));
  return box;
}

/** A selected page contains full immutable tuples; continuation only changes visible positions. */
function renderRankedColumns(box, result, { el, markSvg }) {
  const page = result.ranked;
  box.classList.add('ranked-result');
  box.append(el('p', 'ranked-meaning', { priority: 'Priority order', action: 'Action order' }[page.orderMeaning] ?? 'Ranked order'));
  if (!page.groups.length) {
    box.append(el('p', 'ranked-empty', 'No responses submitted.'));
    return;
  }
  const columns = el('div', 'ranked-columns');
  columns.style.setProperty('--ranked-columns', String(page.groupCount));
  columns.style.setProperty('--ranked-positions', String(page.positionSpan));
  for (const [tuple, count] of page.groups) {
    const column = el('article', 'ranked-column');
    column.setAttribute('aria-label', `Response order ${page.groupStart + columns.children.length + 1}`);
    const order = el('ol', 'ranked-order');
    order.setAttribute('start', String(page.positionStart + 1));
    for (let position = page.positionStart; position < page.positionStart + page.positionSpan; position++) {
      const authoredIndex = Number(tuple[position]), row = result.counts[authoredIndex];
      const tile = el('li', 'opt-tile ranked-tile');
      tile.style.setProperty('--mk', markFor(authoredIndex).fill);
      tile.append(el('span', 'ranked-rank', String(position + 1)), markSvg(authoredIndex, { size: 40, decorative: false }), el('span', 'ranked-label', row.label));
      order.append(tile);
    }
    column.append(order, el('p', 'ranked-total', `${count} ${count === 1 ? 'response' : 'responses'}`));
    columns.append(column);
  }
  box.append(columns, el('p', 'ranked-overall', `${result.total} responses overall`));
  const start = page.positionStart + 1, end = page.positionStart + page.positionSpan;
  if (page.positionSpan < result.rankCount) box.append(el('p', 'ranked-continuation', start === end
    ? `Position ${start} of ${result.rankCount}${page.positionStart ? ' · continued' : ''}`
    : `Positions ${start}–${end} of ${result.rankCount}${page.positionStart ? ' · continued' : ''}`));
  if (page.residualTotal !== undefined) box.append(el('p', 'ranked-residual', `${page.residualTotal} other responses`));
  box.append(el('p', 'ranked-group-page', `Response orders ${page.groupStart + 1}–${page.groupStart + page.groupCount} of ${page.totalGroups}`));
}
