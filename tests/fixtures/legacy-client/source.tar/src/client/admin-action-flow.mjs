import {adminMessage} from './admin-model.mjs';
const OPS=new Set(['facilitators_disable','facilitators_soft_delete','versions_withdraw','cases_publish','rooms_end']);
function context(selected){
 if(!selected)return null;
 return {key:selected.id??selected.version_id??selected.sessionId,revision:selected.profile?.admin_revision??selected.admin_revision??null,label:selected.email??selected.code??selected.title};
}
export function createAdminActionFlow({model,api,onChange=()=>{}}={}){
 const state={open:false,phase:'confirm',label:null,busy:false,notice:'',elevated:false};
 let generation=0,flight=false,closed=false,target=null,operation=null;
 const emit=()=>onChange(state),active=g=>!closed&&g===generation&&state.open;
 const sameTarget=()=>{const current=context(model.state.selected);return current&&target&&current.key===target.key&&current.revision===target.revision;};
 function reset(){generation++;target=null;operation=null;state.open=false;state.label=null;state.busy=false;state.phase='confirm';state.notice='';emit();}
 function begin(op){if(closed||flight||!OPS.has(op))return false;const current=context(model.state.selected);if(!current||typeof current.label!=='string'||!current.label)return false;generation++;target=current;operation=op;state.elevated=model.hasElevation();state.open=true;state.label=current.label;state.phase='confirm';state.notice='';emit();return true;}
 async function sendCode(confirmation){
  if(closed||flight||!state.open||state.phase!=='confirm'||confirmation!==target?.label||!sameTarget())return false;
  const g=generation;flight=true;state.busy=true;state.notice='';emit();
  // One email code opens a window for every destructive action until sign-out (Julian, 2026-10-07, R-a).
  if(model.hasElevation()){try{const applied=await model.act(operation);if(active(g))reset();return applied;}finally{flight=false;if(active(g)){state.busy=false;emit();}}}
  try{
   const result=await api.call('stepup_start',{body:{}});if(!active(g))return false;
   if(!sameTarget()){state.notice='The target changed. Close and choose it again.';return false;}
   if(!result.ok){state.notice=adminMessage(result.error);return false;}
   state.phase='code';state.notice='Enter the code sent to your email.';return true;
  }finally{flight=false;if(active(g)){state.busy=false;emit();}}
 }
 async function verify(code){
  if(closed||flight||!state.open||state.phase!=='code'||typeof code!=='string'||!/^[0-9]{6}$/.test(code)||!sameTarget())return false;
  const g=generation,capturedOperation=operation;flight=true;state.busy=true;state.notice='';emit();
  try{
   const result=await api.call('stepup_verify',{body:{code}});if(!active(g))return false;
   if(!sameTarget()){state.notice='The target changed. Close and choose it again.';return false;}
   if(!result.ok){state.notice=adminMessage(result.error);return false;}
   if(!model.setElevation(result.data.elevation)){state.notice='The confirmation expired. Request a new code.';return false;}
   const applied=await model.act(capturedOperation);if(active(g))reset();return applied;
  }finally{flight=false;if(active(g)){state.busy=false;emit();}}
 }
 return {state,begin,sendCode,verify,cancel:reset,close(){closed=true;reset();}};
}
