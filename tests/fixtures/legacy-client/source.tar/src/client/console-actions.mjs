// Device-local control descriptions; the authority's action list is the only permission source.
import { presentationNav } from './presentation-nav.mjs';

export function primaryAction(view, {pickedPathId=null, now=Date.now(), armedUntil=0}={}) {
  const actions=new Set(view?.actions ?? []);
  if (actions.has('start')) return {command:'start',label:'Start case'};
  if (actions.has('lock')) return {command:'lock',label:'Lock responses & review'};
  if (actions.has('advance') && view.presentation?.nextGroup)
    return {command:'advance',label:presentationNav(view).nextActionLabel};
  if (actions.has('select_path')) {
    const path=view.decision?.paths?.find(p=>p.id===pickedPathId && !p.explored);
    return path ? {command:'select_path',payload:{pathId:path.id},label:'Select this route'} : {local:'focus_resolution',label:'Select route'};
  }
  if (actions.has('reveal')) {
    if (armedUntil>now) return {command:'reveal',label:'Show to room?',armed:true};
    const path=view.decision?.paths?.find(p=>p.id===view.selectedPathId);
    return {local:'arm_reveal',label:`Reveal: ${path?.revealPreview ?? ''}`,armed:false};
  }
  if (actions.has('reset_checkpoint')) return {command:'reset_checkpoint',label:`Reset to ${view.terminal?.checkpointBeat?.title ?? 'checkpoint'}`};
  if (actions.has('resume')) return {command:'resume',label:view.resumePhase==='responses_open' ? 'Resume · responses open' : view.resumePhase==='responses_locked' ? 'Resume · reviewing' : 'Resume discussion'};
  if (actions.has('advance')) return {command:'advance',label:presentationNav(view).nextActionLabel};
  return null;
}

/**
 * The dock's one control (card 37). Never blank in a live phase: the primary action; else, while a closed
 * chart blocks publication (CASE-143), the explicit Hide as its own press (never fused with the reveal, which
 * keeps its two steps); while the lobby screen is up (CASE-176), Return to case; else a disabled reason.
 * It only ever offers a command the authority's action list carries.
 */
export function dockControl(view, local = {}) {
  if (!view || view.phase === 'ended') return null;
  if (local.pending) return {disabled:true,label:'Upload pending'};
  const actions=new Set(view.actions ?? []);
  if (view.display?.lobby === true && actions.has('show_lobby')) return {command:'show_lobby',payload:{on:false},label:'Return to case'};
  const primary=primaryAction(view, local);
  if (primary) return primary;
  if (actions.has('show_results') && view.resultsShown !== false)
    return {command:'show_results',payload:{on:false},label:'Hide responses on projector',note:'Hide the responses to continue'};
  return {disabled:true,label:view.nextBeat || view.phase === 'discussion_paused' ? 'No room action available now'
    : 'Case complete · End room from the Room tab'};
}

/** Plain-text status for a refused facilitator command (rendered with textContent, never as HTML). */
export function refusedCommandNotice(reason, receipt) {
  if (receipt === 'timeout') return 'No confirmation from the room. Check the case before continuing.';
  if (reason === 'hide_responses_first') return 'Hide the responses on the projector first.';
  if (reason === 'lobby_shown') return 'Return to the case on the projector first.';
  if (reason === 'no_change') return ''; // a stale lobby toggle: the resync shows the actual state
  if (reason === 'stale_revision') return 'The room changed. Refreshing its state.';
  if (reason === 'rate_limited') return 'Too many actions at once — try again in a moment.';
  return 'The room could not apply that action.';
}
