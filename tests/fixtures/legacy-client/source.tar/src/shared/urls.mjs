// src/shared/urls.mjs — the one place Case URLs are built and parsed.
//
// Rules (docs/ARCHITECTURE.md §URLs):
//   • QR / printed routes are SHORT, upper case, QR-alphanumeric only: /J/<join>, /D/<pair>, /P/<pair>.
//     The server matches them case-insensitively, so a hand-typed lower-case URL still works.
//   • App routes are lower case and carry UUIDv7 ids: /cases/<id>, /sessions/<id>/…
//   • API routes are same-origin and versioned: /api/v1/…
//   • Never a token, name or other personal datum in any URL.

import { JOIN_CODE_LENGTH, PAIR_CODE_LENGTH, isUuid, isUuidV7, normalizeCode } from './ids.mjs';

export const ORIGIN = 'https://case.iatrogenic.app';

/** Token-free admin live-room continuation: one shard, optionally its last six-character code. */
export function parseAdminRoomsCursor(value) {
  if (value === null) return {shard:'0',afterCode:null};
  if (typeof value !== 'string' || !/^[0-9A-HJKMNP-TV-Z](?::[0-9A-HJKMNP-TV-Z]{6})?$/.test(value) ||
      value.length > 8) throw new TypeError('Invalid admin room cursor');
  const [shard,afterCode = null] = value.split(':');
  if (afterCode !== null && afterCode[0] !== shard) throw new TypeError('Invalid admin room cursor');
  return {shard,afterCode};
}

/** ISO/IEC 18004 alphanumeric-mode character set. */
export const QR_ALPHANUMERIC = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:';

/** Short-route prefixes. One letter each; upper case in QR, any case accepted. */
export const SHORT = Object.freeze({
  join: 'J', // participant joins a room
  display: 'D', // a projector/display window pairs to a session
  pair: 'P', // a shared PC asks a signed-in phone to approve a facilitator sign-in
});

const SHORT_LEN = { J: JOIN_CODE_LENGTH, D: PAIR_CODE_LENGTH, P: PAIR_CODE_LENGTH };

export function isQrAlphanumeric(s) {
  for (const c of s) if (!QR_ALPHANUMERIC.includes(c)) return false;
  return true;
}

function short(prefix, code, origin) {
  const c = normalizeCode(code, SHORT_LEN[prefix]);
  if (!c) throw new TypeError(`invalid ${prefix} code: ${code}`);
  return `${origin}/${prefix}/${c}`;
}

/** Human-readable join URL for printing on the projector: https://case.iatrogenic.app/J/7K3QX9 */
export const privacyUrl = (origin = ORIGIN) => `${origin}/privacy`;
/** Card 29 (CASE-166): the participant-first root, the facilitator catalogue and the network check. */
export const homeUrl = (origin = ORIGIN) => `${origin}/`;
export const casesUrl = (origin = ORIGIN) => `${origin}/cases`;
export const checkUrl = (origin = ORIGIN) => `${origin}/check`;
export const joinEntryUrl = (origin = ORIGIN) => `${origin}/join`;
export const joinUrl = (code, origin = ORIGIN) => short(SHORT.join, code, origin);
export const displayPairUrl = (code, origin = ORIGIN) => short(SHORT.display, code, origin);
export const devicePairUrl = (code, origin = ORIGIN) => short(SHORT.pair, code, origin);

/**
 * QR payload: the same URL upper-cased so every character is QR-alphanumeric.
 * Scheme and host are case-insensitive by RFC 3986; short routes are matched
 * case-insensitively by the Worker, so this round-trips.
 */
export function qrPayload(url) {
  const u = url.toUpperCase();
  if (!isQrAlphanumeric(u)) throw new TypeError(`not QR-alphanumeric: ${url}`);
  return u;
}

/**
 * Parse any Case URL path (or full URL) into a route. Returns null for unknown paths.
 * @returns {{route:string, code?:string, caseId?:string, sessionId?:string, versionNo?:number}|null}
 */
export function parseRoute(input) {
  let path = input;
  try { path = new URL(input, ORIGIN).pathname; } catch { return null; }
  const seg = path.split('/').filter(Boolean);

  if (seg.length === 2 && /^[jdp]$/i.test(seg[0])) {
    const prefix = seg[0].toUpperCase();
    const code = normalizeCode(seg[1], SHORT_LEN[prefix]);
    if (!code) return null;
    const route = { J: 'join', D: 'display-pair', P: 'device-pair' }[prefix];
    return { route, code };
  }
  if (seg.length === 1 && seg[0] === 'join') return { route: 'join' };
  if (seg.length === 1 && seg[0] === 'privacy') return { route: 'privacy' };
  const id = (s) => (s && isUuid(s) ? s : null);
  if (seg[0] === 'cases') {
    if (seg.length === 1) return { route: 'cases' };
    const caseId = id(seg[1]);
    if (!caseId) return null;
    if (seg.length === 2) return { route: 'case', caseId };
    if (seg.length === 3 && seg[2] === 'edit') return { route: 'case-edit', caseId };
    if (seg.length === 3 && seg[2] === 'map') return { route: 'case-map', caseId };
    if (seg.length === 4 && seg[2] === 'v' && /^[1-9]\d*$/.test(seg[3])) {
      return { route: 'case-version', caseId, versionNo: Number(seg[3]) };
    }
    return null;
  }
  if (seg[0] === 'sessions' && seg.length === 3) {
    const sessionId = id(seg[1]);
    const role = { facilitate: 'facilitate', display: 'display', play: 'play', recap: 'recap' }[seg[2]];
    return sessionId && role ? { route: role, sessionId } : null;
  }
  return null;
}

// App-route builders (lower case, UUIDs).
const need = (x) => { if (!isUuid(x)) throw new TypeError(`not a UUID: ${x}`); return x; };
export const caseUrl = (caseId, origin = ORIGIN) => `${origin}/cases/${need(caseId)}`;
export const caseEditUrl = (caseId, origin = ORIGIN) => `${origin}/cases/${need(caseId)}/edit`;
export const caseMapUrl = (caseId, origin = ORIGIN) => `${origin}/cases/${need(caseId)}/map`;
export const caseVersionUrl = (caseId, versionNo, origin = ORIGIN) => {
  if (!Number.isInteger(versionNo) || versionNo < 1) throw new TypeError(`bad version: ${versionNo}`);
  return `${origin}/cases/${need(caseId)}/v/${versionNo}`;
};
export const sessionUrl = (sessionId, role, origin = ORIGIN) => {
  if (!['facilitate', 'display', 'play', 'recap'].includes(role)) throw new TypeError(`bad role: ${role}`);
  return `${origin}/sessions/${need(sessionId)}/${role}`;
};

/** Same-PC display has no stored display credential; it receives only role-projected local frames. */
export const samePcProjectorUrl = (sessionId, origin = ORIGIN) =>
  `${sessionUrl(sessionId, 'display', origin)}?topology=same-pc`;

/** An opaque browser-local handle for an explicit text-only notes download. */
export function localNotesObjectUrl(blob, urlClass = URL) {
  if (!(blob instanceof Blob) || blob.type !== 'text/plain;charset=utf-8')
    throw new TypeError('Invalid notes blob');
  return urlClass.createObjectURL(blob);
}

/** Versioned same-origin API path. */
export const apiPath = (...parts) => `/api/v1/${parts.map(encodeURIComponent).join('/')}`;
export const apiUrl = (origin, ...parts) => new URL(apiPath(...parts), origin).href;

/** Fixed GoTrue endpoints. Neither credentials nor user input enter an Auth URL. */
export function authApiUrl(supabaseOrigin, operation, redirectOrigin = null) {
  const origin = new URL(supabaseOrigin);
  if (origin.protocol !== 'https:' || origin.username || origin.password || origin.pathname !== '/' ||
      origin.search || origin.hash) throw new TypeError('Invalid Auth origin');
  const paths = {
    base: '/auth/v1/',
    otp: '/auth/v1/otp', verify: '/auth/v1/verify', logout: '/auth/v1/logout',
    refresh: '/auth/v1/token?grant_type=refresh_token', pkce: '/auth/v1/token?grant_type=pkce',
  };
  if (!Object.hasOwn(paths, operation)) throw new TypeError('Unknown Auth endpoint');
  const url = new URL(paths[operation], origin);
  if (redirectOrigin !== null) {
    if (operation !== 'otp') throw new TypeError('Auth redirect only applies to OTP start');
    const redirect = new URL(redirectOrigin);
    if (redirect.href !== redirect.origin + '/' || !['https:', 'http:'].includes(redirect.protocol))
      throw new TypeError('Invalid same-origin Auth redirect');
    url.searchParams.set('redirect_to', redirect.href);
  }
  return url.href;
}

/** Fixed third-party verifier endpoint; credentials and tokens belong only in the POST body. */
export const turnstileSiteverifyUrl = () => 'https://challenges.cloudflare.com/turnstile/v0/siteverify';

/** Fixed explicit-render widget script; public site keys stay in render options. */
export const turnstileWidgetScriptUrl = () => 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';

/** Fixed service-role GoTrue paths. Only numeric paging and an exact redirect origin enter queries. */
export function adminAuthUrl(supabaseOrigin, operation, options = {}) {
  const base = authApiUrl(supabaseOrigin, 'base');
  if (!options || typeof options !== 'object' || Array.isArray(options))
    throw new TypeError('Invalid admin Auth options');
  const keys = Object.keys(options);
  if (['user_read', 'user_update', 'user_delete'].includes(operation)) {
    if (keys.length !== 1 || keys[0] !== 'userId' || !isUuid(options.userId))
      throw new TypeError('Invalid admin Auth user');
    return new URL(`admin/users/${options.userId}`, base).href;
  }
  if (operation === 'users') {
    if (keys.some(key => !['page', 'perPage'].includes(key)))
      throw new TypeError('Invalid admin Auth options');
    const page = options.page ?? 1;
    const perPage = options.perPage ?? 100;
    if (!Number.isSafeInteger(page) || page < 1 || page > 100_000 ||
        !Number.isSafeInteger(perPage) || perPage < 1 || perPage > 1_000)
      throw new TypeError('Invalid admin Auth paging');
    const url = new URL('admin/users', base);
    url.searchParams.set('page', String(page));
    url.searchParams.set('per_page', String(perPage));
    return url.href;
  }
  if (operation === 'invite' || operation === 'invite_resend') {
    if (keys.length !== 1 || keys[0] !== 'redirectOrigin')
      throw new TypeError('Invalid admin Auth options');
    const redirect = new URL(options.redirectOrigin);
    if (redirect.protocol !== 'https:' || redirect.username || redirect.password ||
        redirect.href !== `${redirect.origin}/`)
      throw new TypeError('Invalid admin Auth redirect');
    const url = new URL('invite', base);
    url.searchParams.set('redirect_to', redirect.href);
    return url.href;
  }
  if (keys.length || !['otp', 'verify'].includes(operation))
    throw new TypeError('Unknown admin Auth endpoint');
  return authApiUrl(supabaseOrigin, operation);
}

// Card21b: fixed same-origin private API inventory. Personal inputs belong in JSON/header only.
const ADMIN_PATHS = Object.freeze({
  stepup_start:'stepup/start', stepup_verify:'stepup',
  facilitators_list:'facilitators', facilitators_search:'facilitators/search', facilitators_invite:'facilitators/invite',
  facilitators_resend:'facilitators/:id/resend', facilitators_disable:'facilitators/:id/disable',
  facilitators_enable:'facilitators/:id/enable', facilitators_soft_delete:'facilitators/:id/soft-delete', facilitators_restore:'facilitators/:id/restore',
  cases_list:'cases', cases_publish:'cases/:id/publish', versions_withdraw:'versions/:id/withdraw',
  rooms_list:'rooms', rooms_end:'rooms/:id/end', audit_list:'audit',
});
function adminOrigin(value) {
  const u=new URL(value);
  if(!['https:','http:'].includes(u.protocol)||u.username||u.password||u.pathname!=='/'||u.search||u.hash) throw new TypeError('Invalid admin origin');
  return u.origin;
}
export const adminPageUrl=(origin=ORIGIN)=>`${adminOrigin(origin)}/admin`;
export function adminApiUrl(origin,operation,options={}) {
  if(!Object.hasOwn(ADMIN_PATHS,operation)||!options||typeof options!=='object'||Array.isArray(options)) throw new TypeError('Invalid admin operation');
  const list=operation==='facilitators_list'?'users':['cases_list','audit_list','rooms_list'].includes(operation)?'cursor':null;
  const template=ADMIN_PATHS[operation],target=template.includes(':id');
  const allowed=target?['id']:list==='users'?['page','perPage']:list==='cursor'?['limit','after']:[];
  if(Object.keys(options).some(key=>!allowed.includes(key)))throw new TypeError('Invalid admin options');
  let path=template;
  if(target){
    const auth=operation.startsWith('facilitators_');
    if(!(auth?isUuid(options.id):isUuidV7(options.id)))throw new TypeError('Invalid admin target');
    path=template.replace(':id',options.id);
  }
  const url=new URL(`/api/v1/admin/${path}`,adminOrigin(origin));
  for(const key of ['page','perPage','limit'])if(options[key]!==undefined){
    const max=key==='page'?100000:key==='perPage'?1000:100;
    if(!Number.isSafeInteger(options[key])||options[key]<1||options[key]>max)throw new TypeError('Invalid admin page');
    url.searchParams.set(key,String(options[key]));
  }
  if(options.after!==undefined&&options.after!==null){
    const after=options.after;
    const valid=operation==='rooms_list'?typeof after==='string'&&/^[0-9A-HJKMNP-TV-Z](?::[0-9A-HJKMNP-TV-Z]{6})?$/.test(after):isUuidV7(after);
    if(!valid||(operation==='rooms_list'&&after.includes(':')&&after[0]!==after[2]))throw new TypeError('Invalid admin cursor');
    url.searchParams.set('after',after);
  }
  return url.href;
}
