// The facilitator catalogue (card 29, CASE-166): a workspace picker, search, Length and Audience filters,
// sort, honest paging, and Grid / Table / Board views over one server-sorted dataset. Cards are a single
// link named by the title, with canvas covers (card 28) in their group's tint. Start room lives on case
// detail. Card 30 adds the Group filter, column and board columns, and the owners' Groups screen (lazy).
// Text only: every value is set with textContent.
import { accountRequest, node } from './auth-ui.mjs';
import { catalogueSearch, CATALOGUE_PAGE, CATALOGUE_DURATIONS, CATALOGUE_UNGROUPED } from '../shared/catalogue.mjs';
import { validCatalogueGroupRow, UNGROUPED } from '../shared/groups.mjs';
import { caseVersionUrl, casesUrl, parseRoute } from '../shared/urls.mjs';
import { isUuidV7 } from '../shared/ids.mjs';
import { paintCovers, clearCoverCache } from './cover-art.mjs';
import { coverFor, pilotTag, formatDate } from './library-parts.mjs';
import { watchTheme } from './appearance.mjs';
import { cataloguePage, showingText, lengthText, fieldText, groupText, ariaSort, nextSort, boardColumns, SORT_CHOICES,
  TABLE_COLUMNS, BOARD_COLUMNS } from './library-model.mjs';
import { mountCaseDetail } from './case-detail.mjs';

const VIEWS = [['grid', 'Grid'], ['table', 'Table'], ['board', 'Board']];
let controlId = 0;
// A control with its own <label for>, so its accessible name is the label alone.
const select = (label, options, className = 'library-select') => {
  const wrap = node('div', null, className);
  const control = node('select'); control.className = 'input'; control.id = `library-control-${++controlId}`;
  const name = node('label', label, 'library-label'); name.htmlFor = control.id;
  for (const [value, text] of options) { const option = node('option', text); option.value = value; control.append(option); }
  wrap.append(name, control);
  return { wrap, control };
};
export function mountLibrary(host, { auth, me, onStart }) {
  const state = { workspace: null, view: 'grid', sort: 'title', descending: false, query: '', duration: null,
    audience: null, group: null, groups: null, boardBy: 'length', rows: [], total: null, pilotPin: null, loading: false };
  let generation = 0, closed = false, searchTimer = null, detail = null, painting = [], screen = null;
  const root = node('section', null, 'library'); root.setAttribute('aria-labelledby', 'libraryTitle');
  const list = node('div', null, 'library-list');
  const head = node('div', null, 'library-head');
  const title = node('h1', 'Cases'); title.id = 'libraryTitle'; title.tabIndex = -1;
  const memberships = [...me.memberships];
  const workspace = select('Workspace', [], 'library-select library-workspace');
  const status = node('p', '', 'library-status'); status.setAttribute('role', 'status');
  const views = node('div', null, 'segmented'); views.setAttribute('role', 'group'); views.setAttribute('aria-label', 'View');
  const titleBlock = node('div', null, 'library-title');
  titleBlock.append(title, workspace.wrap, status);
  // Owners of the selected workspace manage its groups (P-18 to P-20); everyone else never sees the control.
  const manage = node('button', 'Groups', 'btn library-groups'); manage.type = 'button'; manage.hidden = true;
  const headActions = node('div', null, 'library-head-actions'); headActions.append(manage, views);
  head.append(titleBlock, headActions);
  const toolbar = node('div', null, 'library-toolbar');
  const searchLabel = node('div', null, 'library-search');
  const search = node('input'); search.type = 'search'; search.className = 'input'; search.maxLength = 80;
  search.id = `library-control-${++controlId}`;
  search.placeholder = 'Search title, audience or summary';
  const searchName = node('label', 'Search cases', 'sr-only'); searchName.htmlFor = search.id;
  searchLabel.append(searchName, search);
  const length = select('Length', [['', 'All lengths'], ...CATALOGUE_DURATIONS.map(n => [String(n), `${n} min`])]);
  const audience = select('Audience', [['', 'All audiences']]);
  const group = select('Group', [['', 'All groups']]);
  const sort = select('Sort', SORT_CHOICES.map(c => [c.value, c.label]));
  const columns = select('Columns', BOARD_COLUMNS);
  toolbar.append(searchLabel, length.wrap, audience.wrap, group.wrap, sort.wrap, columns.wrap);
  const results = node('div', null, 'library-results');
  const more = node('button', 'Show more cases', 'btn quiet library-more'); more.type = 'button'; more.hidden = true;
  const empty = node('div', null, 'library-empty'); empty.hidden = true;
  list.append(head, toolbar, results, empty, more);
  root.append(list);
  host.append(root);

  // Workspaces: the picker labels operator (rooms-refused) workspaces and lists them last, never mixed in.
  function fillWorkspaces() {
    const teaching = memberships.filter(m => m.rooms_refused !== true), operators = memberships.filter(m => m.rooms_refused === true);
    const option = m => { const item = node('option', m.rooms_refused === true ? `${m.name || 'Workspace'} (operators; rooms refused here)` : (m.name || 'Workspace')); item.value = m.workspace_id; return item; };
    workspace.control.replaceChildren(...teaching.map(option));
    if (operators.length) { const group = node('optgroup'); group.label = 'Operators'; group.append(...operators.map(option)); workspace.control.append(group); }
    if (!state.workspace || !memberships.some(m => m.workspace_id === state.workspace))
      state.workspace = (teaching[0] ?? operators[0])?.workspace_id ?? null;
    workspace.control.value = state.workspace ?? '';
    manage.hidden = memberships.find(m => m.workspace_id === state.workspace)?.role !== 'owner';
  }
  fillWorkspaces();
  for (const [value, label] of VIEWS) {
    const button = node('button', label); button.type = 'button'; button.dataset.view = value;
    button.addEventListener('click', () => { if (state.view === value) return; const board = value === 'board' || state.view === 'board'; state.view = value; if (board) reload(); else render(); });
    views.append(button);
  }

  async function loadAudiences() {
    const current = generation, ws = state.workspace;
    try {
      const value = await accountRequest(auth, ['workspaces', ws, 'catalogue', 'audiences']);
      if (closed || current !== generation || ws !== state.workspace) return;
      if (!Array.isArray(value?.audiences)) throw new Error('invalid_audiences');
      const chosen = state.audience;
      audience.control.replaceChildren(Object.assign(node('option', 'All audiences'), { value: '' }),
        ...value.audiences.filter(a => typeof a?.audience === 'string').map(a => Object.assign(node('option', a.audience), { value: a.audience })));
      audience.control.value = chosen ?? '';
      if (audience.control.value !== (chosen ?? '')) { state.audience = null; audience.control.value = ''; }
    } catch { /* The filter keeps "All audiences"; the list itself still loads. */ }
  }
  // The group filter and board columns: live groups with whole-set counts, then Ungrouped (card 30).
  async function loadGroups() {
    const current = generation, ws = state.workspace;
    try {
      const value = await accountRequest(auth, ['workspaces', ws, 'catalogue', 'groups']);
      if (closed || ws !== state.workspace) return;
      if (!Array.isArray(value?.groups) || !value.groups.every(validCatalogueGroupRow)) throw new Error('invalid_groups');
      state.groups = value.groups;
      const chosen = state.group;
      group.control.replaceChildren(Object.assign(node('option', 'All groups'), { value: '' }),
        ...value.groups.map(g => Object.assign(node('option', g.id === null ? UNGROUPED : g.name), { value: g.id ?? CATALOGUE_UNGROUPED })));
      group.control.value = chosen ?? '';
      if (group.control.value !== (chosen ?? '')) { state.group = null; group.control.value = ''; if (current === generation) reload(); }
      else if (state.view === 'board' && state.boardBy === 'group') render();
    } catch { state.groups = null; /* The filter keeps "All groups"; the list still loads. */ }
  }
  const query = offset => {
    const board = state.view === 'board';
    return { sort: board ? state.boardBy : state.sort, descending: board ? false : state.descending, query: state.query,
      duration: state.duration, audience: state.audience, group: state.group, limit: CATALOGUE_PAGE, offset };
  };
  async function load(offset) {
    const current = generation, request = query(offset);
    state.loading = true; more.disabled = true;
    if (!offset) status.textContent = 'Loading published cases…';
    try {
      const value = await accountRequest(auth, ['workspaces', state.workspace, 'catalogue'], { query: catalogueSearch(request) });
      if (closed || current !== generation) return;
      const page = cataloguePage(value, request);
      state.rows = offset ? [...state.rows, ...page.rows] : page.rows;
      state.total = page.total; state.pilotPin = page.pilotPin;
      render();
    } catch {
      if (closed || current !== generation) return;
      status.textContent = offset ? 'The next cases could not be loaded. Try again.' : 'Published cases are unavailable. Try again.';
      if (!offset) { results.replaceChildren(); empty.hidden = true; }
      more.hidden = false;
    } finally { if (current === generation) { state.loading = false; more.disabled = false; } }
  }
  function reload() {
    generation++; state.rows = []; state.total = null;
    if (!state.workspace) { status.textContent = 'No workspaces are assigned to this account.'; results.replaceChildren(); more.hidden = true; return; }
    void load(0);
  }

  function cardFor(row, covers, className = 'case-card', level = 'h2') {
    const card = node('article', null, className);
    const link = node('a', row.title, 'case-link'); link.href = caseVersionUrl(row.case_id, row.version_no, location.origin);
    const heading = node(level, null, 'case-card-title'); heading.append(link);
    const meta = node('p', null, 'case-meta');
    meta.append(node('span', lengthText(row.duration_min)), node('span', fieldText(row.audience, 'audience')), node('span', groupText(row), 'case-group-name'));
    const body = node('div', null, 'case-card-body');
    body.append(heading, node('p', fieldText(row.summary, 'summary'), 'case-summary'), meta, pilotTag(row, state.pilotPin));
    card.append(coverFor(row, covers), body);
    return card;
  }
  function renderGrid(covers) {
    const grid = node('div', null, 'case-grid');
    grid.append(...state.rows.map(row => cardFor(row, covers)));
    return grid;
  }
  function renderTable(covers) {
    const wrap = node('div', null, 'table-scroll');
    const table = node('table', null, 'case-table');
    const caption = node('caption', 'Published cases. Sorting applies to the whole result set, not just the rows loaded so far.', 'sr-only');
    const head = node('thead'), tr = node('tr');
    const coverTh = node('th'); coverTh.append(node('span', 'Cover', 'sr-only')); tr.append(coverTh);
    for (const [column, label] of TABLE_COLUMNS) {
      const th = node('th'); th.scope = 'col';
      th.setAttribute('aria-sort', ariaSort(column, state.sort, state.descending));
      const button = node('button', label, 'sort-button'); button.type = 'button'; button.dataset.sort = column;
      button.addEventListener('click', () => {
        Object.assign(state, nextSort(column, state.sort, state.descending));
        sort.control.value = SORT_CHOICES.find(c => c.sort === state.sort && c.descending === state.descending)?.value ?? sort.control.value;
        reload();
      });
      th.append(button); tr.append(th);
    }
    head.append(tr);
    const body = node('tbody');
    for (const row of state.rows) {
      const r = node('tr');
      const cover = node('td', null, 'cover-cell'); cover.append(coverFor(row, covers, 'cover small'));
      const titleCell = node('td');
      const link = node('a', row.title, 'case-link'); link.href = caseVersionUrl(row.case_id, row.version_no, location.origin);
      titleCell.append(link, node('span', fieldText(row.summary, 'summary'), 'case-summary-line'));
      const published = node('td');
      published.append(node('span', `v${row.version_no} · ${formatDate(row.published_at)}`), pilotTag(row, state.pilotPin));
      r.append(cover, titleCell, node('td', groupText(row)), node('td', lengthText(row.duration_min)), node('td', fieldText(row.audience, 'audience')), published);
      body.append(r);
    }
    table.append(caption, head, body); wrap.append(table);
    return wrap;
  }
  function renderBoard(covers) {
    const board = node('div', null, 'case-board');
    for (const column of boardColumns(state.rows, state.boardBy, state.boardBy === 'group' ? state.groups : null)) {
      const section = node('section', null, 'board-column'); section.setAttribute('aria-label', column.label);
      const header = node('h2', null, 'board-column-head');
      header.append(node('span', column.label), node('span', String(column.count ?? column.rows.length), 'muted'));
      section.append(header, ...column.rows.map(row => cardFor(row, covers, 'case-card board-card', 'h3')));
      board.append(section);
    }
    return board;
  }
  function render() {
    if (closed) return;
    for (const button of views.querySelectorAll('button')) button.setAttribute('aria-pressed', String(button.dataset.view === state.view));
    sort.wrap.hidden = state.view !== 'grid';
    columns.wrap.hidden = state.view !== 'board';
    status.textContent = showingText(state.rows.length, state.total);
    const covers = [];
    if (!state.rows.length && state.total === 0) {
      results.replaceChildren();
      const filtered = state.query || state.duration !== null || state.audience !== null || state.group !== null;
      empty.replaceChildren(node('p', filtered ? 'No cases match.' : 'No published cases in this workspace.'));
      if (filtered) {
        const clear = node('button', 'Clear search and filters', 'btn tertiary'); clear.type = 'button';
        clear.addEventListener('click', () => {
          Object.assign(state, { query: '', duration: null, audience: null, group: null });
          search.value = ''; length.control.value = ''; audience.control.value = ''; group.control.value = ''; reload();
        });
        empty.append(clear);
      }
      empty.hidden = false;
    } else {
      empty.hidden = true;
      // A late response rebuilds the table: keep keyboard focus on the sort header it replaces, so a key
      // pressed at that instant still sorts instead of vanishing with the detached button.
      const focusedSort = results.contains(document.activeElement) ? document.activeElement.dataset?.sort : undefined;
      results.replaceChildren(state.view === 'table' ? renderTable(covers) : state.view === 'board' ? renderBoard(covers) : renderGrid(covers));
      if (focusedSort) results.querySelector(`button.sort-button[data-sort="${focusedSort}"]`)?.focus();
    }
    more.hidden = !(state.total === null ? state.rows.length > 0 && state.rows.length % CATALOGUE_PAGE === 0 : state.rows.length < state.total);
    painting = covers;
    void paintCovers(covers);
  }

  workspace.control.addEventListener('change', () => {
    state.workspace = workspace.control.value; state.audience = null; audience.control.value = '';
    state.group = null; state.groups = null; group.control.value = '';
    manage.hidden = memberships.find(m => m.workspace_id === state.workspace)?.role !== 'owner';
    reload(); void loadAudiences(); void loadGroups();
  });
  search.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { const next = search.value.trim(); if (next !== state.query) { state.query = next; reload(); } }, 250);
  });
  search.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); clearTimeout(searchTimer); state.query = search.value.trim(); reload(); } });
  length.control.addEventListener('change', () => { state.duration = length.control.value ? Number(length.control.value) : null; reload(); });
  audience.control.addEventListener('change', () => { state.audience = audience.control.value || null; reload(); });
  group.control.addEventListener('change', () => { state.group = group.control.value || null; reload(); });
  sort.control.addEventListener('change', () => {
    const choice = SORT_CHOICES.find(c => c.value === sort.control.value);
    if (choice) { state.sort = choice.sort; state.descending = choice.descending; reload(); }
  });
  columns.control.addEventListener('change', () => { state.boardBy = ['audience', 'group'].includes(columns.control.value) ? columns.control.value : 'length'; reload(); });
  // The owner's Groups screen replaces the list in this document; closing it reloads the catalogue.
  manage.addEventListener('click', async () => {
    if (screen || manage.hidden) return;
    const ws = state.workspace;
    const { mountGroups } = await import('./groups-screen.mjs');
    if (closed || ws !== state.workspace || screen) return;
    list.hidden = true;
    screen = mountGroups(root, { request: (parts, options) => accountRequest(auth, parts, options),
      workspaces: memberships.filter(m => m.workspace_id === ws), workspaceId: ws,
      onClose: ({ forbidden = false } = {}) => {
        screen?.close(); screen = null; list.hidden = false;
        if (forbidden) { const m = memberships.find(x => x.workspace_id === ws); if (m) m.role = 'facilitator'; manage.hidden = true; }
        reload(); void loadGroups(); (forbidden ? title : manage).focus();
      } });
  });
  more.addEventListener('click', () => { if (!state.loading) void load(state.rows.length); });
  const stopTheme = watchTheme(() => { clearCoverCache(); void paintCovers(painting); });

  // Case detail is an in-document view at /cases/<case>/v/<n>: a plain click opens it, a modified click
  // or a reload follows the link (the route mounts detail directly).
  function showList({ push = false } = {}) {
    detail?.close(); detail = null; screen?.close(); screen = null; list.hidden = false;
    if (push) history.pushState(null, '', casesUrl(location.origin));
    title.focus();
  }
  function showDetail(caseId, versionNo, { push = false } = {}) {
    if (push) history.pushState(null, '', caseVersionUrl(caseId, versionNo, location.origin));
    list.hidden = true; detail?.close(); screen?.close(); screen = null;
    detail = mountCaseDetail(root, { auth, caseId, versionNo, onBack: () => showList({ push: true }), onStart,
      onGroupChanged: () => { reload(); void loadGroups(); } });
  }
  root.addEventListener('click', event => {
    const link = event.target.closest?.('a.case-link');
    if (!link || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const route = parseRoute(link.href);
    if (route?.route !== 'case-version' || !isUuidV7(route.caseId)) return;
    event.preventDefault(); showDetail(route.caseId, route.versionNo, { push: true });
  });
  const onPop = () => {
    const route = parseRoute(location.pathname);
    if (route?.route === 'case-version' && isUuidV7(route.caseId)) showDetail(route.caseId, route.versionNo);
    else showList();
  };
  window.addEventListener('popstate', onPop);

  const initial = parseRoute(location.pathname);
  reload(); void loadAudiences(); void loadGroups();
  if (initial?.route === 'case-version' && isUuidV7(initial.caseId)) showDetail(initial.caseId, initial.versionNo);
  return {
    close() {
      closed = true; generation++; clearTimeout(searchTimer); stopTheme(); window.removeEventListener('popstate', onPop);
      detail?.close(); detail = null; screen?.close(); screen = null; root.remove();
    },
    addMemberships(rows) { for (const m of rows) if (!memberships.some(x => x.workspace_id === m.workspace_id)) memberships.push(m); fillWorkspaces(); },
  };
}
