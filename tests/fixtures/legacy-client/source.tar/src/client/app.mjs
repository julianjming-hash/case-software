import { storedCredential } from './transport.mjs';
import { startShell } from './shell.mjs';
import { mount as privacyMount } from './privacy.mjs';
import { boot, loadFailedNotice } from './app-boot.mjs';
// Consume a one-use Auth code before mounting a surface, starting service-worker
// work or making any application request. Only the root callback is accepted.
const callback = new URL(location.href);
const magicCallback = callback.pathname === '/' && callback.searchParams.has('code') ? callback.href : null;
if (magicCallback) history.replaceState(null, '', callback.origin + callback.pathname);
const path = location.pathname;
// CASE-166 (Julian, 2026-10-06, "trim first"): each surface is its own chunk, loaded by a literal
// same-origin import() (script-src 'self'; no Trusted Types sink), so the root loads only room-code entry.
// Every chunk is a budgeted entry in scripts/size-budget.mjs.
async function route() {
  if (storedCredential('display') && /\/facilitate$/.test(path)) (await import('./projector.mjs')).mount();
  else if (path === '/privacy') privacyMount();
  else if (path === '/help') (await import('./help.mjs')).mount();
  else if (path === '/join' || /^\/[Jj]\//.test(path) || /\/play$|\/recap$/.test(path)) (await import('./phone.mjs')).mount();
  else if (/^\/[PpDd]\//.test(path)) (await import('./pair.mjs')).mount();
  else if (/^\/[Pp]\/?$/.test(path)) (await import('./pair.mjs')).mountConsolePair();
  else if (/\/display$/.test(path)) (await import('./projector.mjs')).mount();
  // Card 29 (CASE-166): the root is participant-first for everyone. It never touches an account; a
  // magic-link callback (root only) and the catalogue (/cases) mount the facilitator document.
  else if ((path === '/' || path === '/index.html') && !magicCallback) (await import('./home.mjs')).mount();
  else (await import('./console.mjs')).mount({ magicCallback });
}
await boot({ route, notice: loadFailedNotice, startShell });
