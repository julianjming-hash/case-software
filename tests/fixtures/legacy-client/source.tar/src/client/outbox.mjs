// Phone-only durable vote envelopes. Credentials never enter this store.
import { uuidv7, isUuidV7 } from '../shared/ids.mjs';
import { parseCommandEnvelope, WIRE_VERSION } from '../shared/wire.mjs';

export const OUTBOX_LIMIT = 20;
const TERMINAL = new Set(['accepted', 'already_accepted', 'locked', 'rejected', 'voided', 'removed', 'ended']);
export const isVoteResponse = response => {
  if (!response || Object.keys(response).length !== 1) return false;
  if ('text' in response) return typeof response.text === 'string';
  if ('option_id' in response) return isUuidV7(response.option_id);
  const choices = response.option_ids ?? response.order;
  return Array.isArray(choices) && choices.length > 0 && choices.every(isUuidV7) && new Set(choices).size === choices.length;
};

export function createOutbox({ store, roomId, participantId, send }) {
  if (!isUuidV7(roomId) || !isUuidV7(participantId)) throw new TypeError('invalid outbox scope');
  let flight = null, generation = 0, closed = false;
  const owned = row => row.roomId === roomId && row.participantId === participantId;
  const update = change => store.update(roomId, change);
  const read = () => update(rows => ({ rows, result: rows.filter(owned) }));
  const box = {
    async enqueue(input) {
      if (closed || !input || Object.keys(input).some(key => !['roundId', 'epoch', 'response'].includes(key))) throw new TypeError('invalid vote');
      const envelope = { v: WIRE_VERSION, type: 'vote', epoch: input.epoch, clientEventId: uuidv7(), roundId: input.roundId, response: structuredClone(input.response) };
      if (!parseCommandEnvelope(envelope, 'participant').ok || !isVoteResponse(envelope.response)) throw new TypeError('invalid vote');
      await update(rows => {
        const next = rows.map(row => owned(row) && row.envelope.roundId === envelope.roundId ? { ...row, superseded: true } : row);
        if (next.length >= OUTBOX_LIMIT) {
          const sameRound = next.findIndex(row => owned(row) && row.superseded && row.envelope.roundId === envelope.roundId);
          const stale = sameRound >= 0 ? sameRound : next.findIndex(row => row.superseded);
          if (stale < 0) throw new Error('Outbox full');
          next.splice(stale, 1);
        }
        next.push({ roomId, participantId, envelope, superseded: false });
        return { rows: next, result: null };
      });
      return structuredClone(envelope);
    },
    async count() { return (await read()).filter(row => !row.superseded).length; },
    async latest(roundId) { return structuredClone((await read()).findLast(row => !row.superseded && row.envelope.roundId === roundId)?.envelope ?? null); },
    async setEpoch(epoch) {
      if (!Number.isInteger(epoch) || epoch < 0) throw new TypeError('invalid epoch');
      await update(rows => ({ rows: rows.map(row => owned(row) ? { ...row, envelope: { ...row.envelope, epoch } } : row), result: null }));
    },
    flush() {
      if (flight) return flight;
      const seen = generation;
      flight = (async () => {
        const entries = await read();
        for (const entry of entries) {
          if (closed || generation !== seen) return;
          // Recheck after each network wait: an answer can be superseded meanwhile.
          const live = (await read()).find(row => row.envelope.clientEventId === entry.envelope.clientEventId && !row.superseded);
          if (!live) continue;
          if (!parseCommandEnvelope(live.envelope, 'participant').ok || !isVoteResponse(live.envelope.response)) { await box.clear(); return; }
          let receipt;
          try { receipt = await send(structuredClone(live.envelope)); } catch { return; }
          if (generation !== seen || closed) return;
          if (!TERMINAL.has(receipt?.receipt)) return;
          await update(rows => ({ rows: rows.filter(row => !owned(row) || row.envelope.clientEventId !== live.envelope.clientEventId && !(row.superseded && row.envelope.roundId === live.envelope.roundId)), result: null }));
        }
      })().finally(() => { flight = null; });
      return flight;
    },
    async clear() { generation++; await update(rows => ({ rows: rows.filter(row => !owned(row)), result: null })); },
    async close() { closed = true; generation++; },
  };
  return box;
}
