// THE shared art-renderer chunk for the whole app (card 36a, CASE-164, CASE-173): braid splash behind an opaque panel and
// the small canvas cover. The phone (join, waiting, recap cover) and the projector (lobby, ended; card 36b) both import it
// lazily and dynamically, so the renderer never enters any surface's first load, and it is one budgeted `splash` entry.
// It holds nothing private: only the numbers-only descriptor a surface already receives, the fixed brand braid, and
// local layout presets. Anything that does not validate falls back to the brand braid, never to an error.
import { validArtDescriptor } from '../shared/art-descriptor.mjs';
import { BRAND_ART } from './brand-art.mjs';

export { BRAND_ART };
import { mountSplash, paintCover, paintCovers, clearCoverCache, currentTheme } from './mosaic.mjs';
export { paintCovers, clearCoverCache, currentTheme };
import { watchTheme } from './appearance.mjs';

/** The descriptor to draw: the room's when it validates, else the brand braid. */
export const artOrBrand = art => (validArtDescriptor(art) ? art : BRAND_ART);

/**
 * Mount splash art into `host` (replacing its children) and repaint when the appearance changes.
 * `brand: true` ignores `art` (the join page, which holds only a code). `host.dataset.art` says which was drawn.
 * Motion is assemble and shimmer; both are off under reduced motion and paused while hidden (mosaic.mjs).
 */
export function mountCaseSplash(host, art, { brand = false, aspect = 0.5, focus = null, group = 'neutral' } = {}) {
  const chosen = brand ? BRAND_ART : artOrBrand(art);
  const kind = chosen === BRAND_ART ? 'brand' : 'case';
  let handle = null;
  const paint = () => {
    handle?.stop();
    handle = mountSplash(host, chosen, { motion: ['assemble', 'shimmer'], contentSeed: kind === 'brand' ? 'case-brand' : 'case-room', group: kind === 'brand' ? 'neutral' : group, aspect, focus });
    host.dataset.art = kind;
  };
  paint();
  const unwatch = watchTheme(paint);
  return { kind, stop() { unwatch(); handle?.stop(); handle = null; } };
}

/** Paint a small canvas cover from the room's descriptor (brand braid when it does not validate). `group` is the room's frozen tint (an enum name; unknown reads as neutral). */
export function paintCaseCover(canvas, art, { size = 72, group = 'neutral' } = {}) {
  return paintCover(canvas, artOrBrand(art), { cssSize: size, theme: currentTheme(), group, contentSeed: 'case-room' });
}

/** Layout presets (aspect, focus region of the art) per surface, so each surface names its composition instead of repeating numbers. */
export const SPLASH_LAYOUT = Object.freeze({
  phoneJoin: Object.freeze({ aspect: 0.5, focus: [0.02, 0.62, 0.98, 0.99] }),
  phoneWaiting: Object.freeze({ aspect: 0.5, focus: [0.04, 0.36, 0.96, 0.96] }),
  projectorLobby: Object.freeze({ aspect: 1.6, focus: [0.62, 0.04, 0.98, 0.96] }), // right third
});

let authArt = null;
/** The facilitator sign-in page (signed out): the brand braid behind one panel. Idempotent; `on = false` removes it. */
export function setAuthSplash(main, on) {
  const wanted = on && main.isConnected;
  main.classList.toggle('auth-splash', wanted);
  let host = main.querySelector(':scope > .auth-art');
  if (!wanted) { authArt?.stop(); authArt = null; host?.replaceChildren(); return; }
  if (!host) { host = document.createElement('div'); host.className = 'auth-art'; host.setAttribute('aria-hidden', 'true'); main.prepend(host); }
  if (!authArt) authArt = mountCaseSplash(host, null, { brand: true, aspect: 1.6 });
}

// ── projector (card 36b, CASE-174) ──
/** A lobby title past two lines steps down to --projector-title (`.long`), by measurement, never by count. */
function stepTitle(root) {
  const h = root.querySelector('.joinpanel h1');
  if (!h) return;
  h.classList.remove('long');
  const style = getComputedStyle(h), line = parseFloat(style.lineHeight) || parseFloat(style.fontSize) * 1.15;
  if (h.getBoundingClientRect().height > line * 2 + 1) h.classList.add('long');
}
const projectorLayers = new WeakMap();

/**
 * The projector's art layer, run after every render (`view` null on teardown): splash only behind the lobby and the
 * ended state (one composition, the art in the right third), the room's frozen tint when the view carries it, and
 * the lobby title step-down. The projector loads this chunk after its first paint; the panels render without it.
 */
export function projectorArt(root, view) {
  const doc = root.ownerDocument;
  let host = root.querySelector(':scope > .projector-splash');
  if (!host) {
    host = doc.createElement('div'); host.className = 'projector-splash'; host.setAttribute('aria-hidden', 'true');
    root.prepend(host);
    doc.fonts?.ready.then(() => { if (root.isConnected) stepTitle(root); });
  }
  const was = projectorLayers.get(host);
  if (view?.phase !== 'waiting' && view?.phase !== 'ended') {
    was?.stop(); projectorLayers.delete(host); host.hidden = true;
    if (host.firstChild) host.replaceChildren();
    return;
  }
  const win = doc.defaultView, group = typeof view.tint === 'string' ? view.tint : 'neutral';
  const aspect = win.innerWidth / Math.max(1, win.innerHeight);
  const key = [JSON.stringify(view.art ?? null), group, aspect.toFixed(3)].join('|');
  host.hidden = false;
  if (was?.key !== key) {
    was?.stop();
    const layer = mountCaseSplash(host, view.art, { ...SPLASH_LAYOUT.projectorLobby, aspect, group });
    projectorLayers.set(host, { key, stop: layer.stop });
  }
  stepTitle(root);
}
