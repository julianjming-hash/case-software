import { createTeardown, TEARDOWN_KEYS } from './teardown.mjs';
import { credentialKey } from './transport.mjs';
import { normalizeCode, JOIN_CODE_LENGTH } from '../shared/ids.mjs';
import { validateParticipantRecovery } from './phone-recovery.mjs';
const JOIN_DRAFT='case:phone:join-code-draft';
/** Select the participant exception, then use the same bounded cleanup as every other surface. */
export function createPhoneCleanup({selection=()=>null,privacyReturn=()=>false,now=Date.now,...options}={}) {
  return function cleanup(reason) {
    const navigation=reason==='pagehide'||reason==='next_load';
    let selected=null,keepDraft=false;
    try {
      const candidate=selection();
      if(navigation && candidate?.queueValidated===true && validateParticipantRecovery({...candidate,rows:[],now:now()}).preserve) selected=candidate;
      const code=options.sessionStorage?.getItem(JOIN_DRAFT);
      keepDraft=reason==='pagehide' && privacyReturn()===true && typeof code==='string' && code.length===JOIN_CODE_LENGTH && normalizeCode(code,JOIN_CODE_LENGTH)===code;
    } catch { selected=null;keepDraft=false; }
    // A participant page never ends the facilitator's account session on this device (card 38, CASE-175).
    return createTeardown({...options,accountEnds:[],
      preserveSession:keepDraft?[JOIN_DRAFT]:[],
      preserveLocal:selected?[TEARDOWN_KEYS.keepOnly,credentialKey('participant')]:[TEARDOWN_KEYS.keepOnly],
      preserveDatabases:selected?['case:phone-outbox']:[],
    })(reason);
  };
}
