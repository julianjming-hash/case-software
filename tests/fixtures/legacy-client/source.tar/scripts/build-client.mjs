#!/usr/bin/env node
// Static shell only: no fixtures, cases, secrets or API responses enter the build graph.
import { readFile, writeFile, mkdir, rm, readdir, realpath } from 'node:fs/promises';
import { resolve, relative, dirname, extname, basename, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { withSecurityHeaders } from '../src/worker/headers.mjs';
import { WIRE_VERSION } from '../src/shared/wire.mjs';
import { init, parse } from 'es-module-lexer';
import { AVATAR_IDS } from '../src/shared/participant.mjs';

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const HTML_ROUTES = ['/', '/join', '/privacy', '/help', '/cases', '/cases/*', '/index.html', '/room.html', '/J/*', '/j/*', '/D/*', '/d/*', '/P/*', '/p/*', '/sessions/*', '/check', '/check.html', '/admin', '/admin.html'];
const ASSET_ROOTS = ['src/client/', 'src/shared/', 'public/fonts/', 'public/avatars/', 'public/audio/'];
// CSS lexical tokens consume comments and strings before considering a real url().
function cssReferences(text) {
  const refs = [];
  const tokens = /\/\*[\s\S]*?\*\/|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\burl\(\s*(?:"([^"\\]*)"|'([^'\\]*)'|([^)'"\s]+))\s*\)|@import\b/gi;
  for (const token of text.matchAll(tokens)) {
    if (/^@import/i.test(token[0])) throw new Error('unsupported_css_import');
    const target = token[1] ?? token[2] ?? token[3];
    if (target !== undefined) { const start = token.index + token[0].indexOf(target); refs.push({ start, end: start + target.length, target }); }
  }
  return refs;
}
const replaceSpans = (text, spans) => {
  for (const { start, end, value } of spans.sort((a, b) => b.start - a.start)) text = text.slice(0, start) + value + text.slice(end);
  return text;
};
function htmlReferences(text) {
  const masked = text.replace(/<!--[\s\S]*?-->/g, match => ' '.repeat(match.length));
  const refs = [];
  for (const tag of masked.matchAll(/<(?:script|link|img|source)\b(?:[^>"']|"[^"]*"|'[^']*')*>/gi)) {
    for (const attr of tag[0].matchAll(/\b(?:src|href)\s*=\s*(["'])(\.{1,2}\/[^"']+)\1/g)) {
      const start = tag.index + attr.index + attr[0].indexOf(attr[2]);
      refs.push({ start, end: start + attr[2].length, target: attr[2] });
    }
  }
  return refs;
}

// Static assets receive headers before the Worker runs. Read only the selected
// environment's three public Auth URL bindings; key material is never a build input.
async function selectedPublicAuthBindings(root, env) {
  if (env === 'local') return {};
  let source;
  try { source = await readFile(join(root, 'wrangler.toml'), 'utf8'); }
  catch (error) { if (error.code === 'ENOENT') return {}; throw error; }
  const section = `[env.${env}.vars]`;
  const start = source.indexOf(section);
  if (start < 0) return {};
  const body = source.slice(start + section.length).split(/^\[/m, 1)[0];
  const bindings = {};
  for (const key of ['SUPABASE_URL', 'SUPABASE_JWT_ISSUER', 'SUPABASE_JWKS_URL']) {
    const line = body.match(new RegExp(`^${key}\\s*=\\s*("[^"\\n]*")\\s*$`, 'm'));
    if (line) bindings[key] = JSON.parse(line[1]);
  }
  return bindings;
}

/** The selected environment travels with the public build SHA into the shared response policy. */
export async function buildClient({ root = ROOT, outDir = join(root, 'dist'), env = 'local', buildSha = 'unconfigured', wireVersion = WIRE_VERSION, publicAuthBindings = null } = {}) {
  if (!['local', 'production', 'staging'].includes(env)) throw new Error('invalid_environment');
  if (buildSha !== 'unconfigured' && (typeof buildSha !== 'string' || buildSha.length !== 40 || !/^[0-9a-f]{40}$/.test(buildSha))) throw new Error('invalid_build');
  if (env !== 'local' && buildSha === 'unconfigured') throw new Error('invalid_build');
  root = resolve(root); outDir = resolve(outDir);
  const physicalRoot = await realpath(root);
  await init;
  if (outDir === root) throw new Error('invalid_output');
  if (outDir === join(root, 'dist')) await rm(outDir, { recursive: true, force: true });
  else await mkdir(outDir); // Noncanonical outputs must be fresh; never delete a caller's directory.
  await mkdir(join(outDir, 'assets'), { recursive: true });
  const emitted = new Map(); const visiting = new Set(); const hashedFiles = [];
  const asset = async path => {
    path = resolve(path); const source = relative(root, path).split('\\').join('/');
    const allowed = candidate => ASSET_ROOTS.some(prefix => candidate.startsWith(prefix)) && !candidate.includes('/fixtures/') && /\.(mjs|css|woff2|svg|txt|wav)$/.test(candidate);
    if (!allowed(source)) throw new Error('non_shell_asset');
    const physicalSource = relative(physicalRoot, await realpath(path)).split('\\').join('/');
    if (!allowed(physicalSource)) throw new Error('non_shell_asset');
    if (emitted.has(path)) return emitted.get(path);
    if (visiting.has(path)) throw new Error('asset_cycle'); visiting.add(path);
    let bytes = await readFile(path);
    if (/\.(mjs|css)$/.test(path)) {
      let text = bytes.toString();
      // One explicit generated module; never rewrite arbitrary JavaScript URL-looking text.
      if (source === 'src/client/avatar-assets.mjs') {
        if (text !== 'export const AVATAR_URLS = Object.freeze(/*__AVATAR_URLS__*/{});\n') throw new Error('invalid_avatar_template');
        const urls = {};
        for (const id of AVATAR_IDS) urls[id] = `/${await asset(join(root, 'public/avatars', `${id}.svg`))}`;
        text = `export const AVATAR_URLS = Object.freeze(${JSON.stringify(urls)});\n`;
      }

      // On-demand room audio: hashed into dist/assets but never precached (see `shell` below). Event cues
      // (projector) and ui-* tones (console only) are separate maps so neither surface ships the other's URLs.
      const audioMap = { 'src/client/audio-assets.mjs': ['CUE_URLS', name => !name.startsWith('ui-')], 'src/client/ui-tone-assets.mjs': ['UI_TONE_URLS', name => name.startsWith('ui-')] }[source];
      if (audioMap) {
        const [exportName, pick] = audioMap;
        if (text !== `export const ${exportName} = Object.freeze(/*__${exportName}__*/{});\n`) throw new Error('invalid_audio_template');
        const urls = {};
        for (const file of (await readdir(join(root, 'public/audio'))).filter(name => name.endsWith('.wav') && pick(name)).sort()) urls[file.replace(/\.wav$/, '')] = `/${await asset(join(root, 'public/audio', file))}`;
        text = `export const ${exportName} = Object.freeze(${JSON.stringify(urls)});\n`;
      }
      const refs = path.endsWith('.mjs') ? parse(text)[0].filter(ref => ref.d !== -2).map(ref => {
        if (!ref.n) throw new Error('dynamic_asset');
        return { start: ref.s, end: ref.e, target: ref.n, quoted: ref.d >= 0 };
      }) : cssReferences(text);
      const spans = [];
      for (const ref of refs) {
        if (!ref.target.startsWith('./') && !ref.target.startsWith('../')) throw new Error('external_asset');
        const output = await asset(resolve(dirname(path), ref.target));
        spans.push({ ...ref, value: ref.quoted ? JSON.stringify(`/${output}`) : `/${output}` });
      }
      text = replaceSpans(text, spans);
      bytes = Buffer.from(text);
    }
    const file = `assets/${basename(path, extname(path))}.${digest(bytes)}${extname(path)}`;
    await writeFile(join(outDir, file), bytes); emitted.set(path, file); visiting.delete(path); hashedFiles.push(file); return file;
  };
  const publicFiles = (await readdir(join(root, 'public'))).filter(name => name.endsWith('.html')).sort();
  for (const page of publicFiles) {
    let text = await readFile(join(root, 'public', page), 'utf8');
    if (/<script(?![^>]*\bsrc=)[^>]*>/i.test(text) || /<style\b|\son\w+=|\sstyle=/i.test(text)) throw new Error('inline_shell_code');
    const spans = [];
    for (const ref of htmlReferences(text)) {
      const file = await asset(resolve(root, 'public', ref.target)); spans.push({ ...ref, value: `/${file}` });
    }
    text = replaceSpans(text, spans);
    await writeFile(join(outDir, page), text);
    // Wrangler rejects wildcard proxies to index.html even with HTML handling disabled.
    if (page === 'index.html') await writeFile(join(outDir, 'room.html'), text);
  }
  const manifest = { id: '/', name: 'Case', short_name: 'Case', start_url: '/', scope: '/', display: 'standalone' };
  await writeFile(join(outDir, 'manifest.webmanifest'), JSON.stringify(manifest));
  // Optional vendors have no runtime coupling to prototype HTML or case data.
  for (const folder of ['fonts', 'avatars']) {
    let files = []; try { files = await readdir(join(root, 'public', folder)); } catch (error) { if (error.code !== 'ENOENT') throw error; }
    for (const file of files.sort()) await asset(join(root, 'public', folder, file));
  }
  const shell = [...new Set([...publicFiles, ...(publicFiles.includes('index.html') ? ['room.html'] : []), 'manifest.webmanifest', ...hashedFiles.filter(file => !file.endsWith('.wav'))])].sort();
  const parts = [];
  for (const file of shell) parts.push(file, '\0', await readFile(join(outDir, file)), '\0');
  const hash = createHash('sha256'); for (const part of parts) hash.update(part);
  const cacheName = `case-shell-wire${wireVersion}-${hash.digest('hex')}`;
  const template = await readFile(join(root, 'src/client/sw.mjs'), 'utf8');
  await writeFile(join(outDir, 'sw.mjs'), template.replace('__CACHE_NAME__', cacheName).replace('/*__SHELL__*/[]', JSON.stringify(shell.map(file => `/${file}`))));
  const bindings = { CASE_ENV: env === 'local' ? '' : env, BUILD_SHA: buildSha,
    ...(publicAuthBindings ?? await selectedPublicAuthBindings(root, env)) };
  const policy = kind => [...withSecurityHeaders(new Response(), kind, bindings).headers].filter(([key]) => key !== 'content-type');
  const common = policy('asset').filter(([key]) => !['cache-control', 'content-security-policy'].includes(key));
  const block = (pattern, headers) => `${pattern}\n${headers.map(([key, value]) => `  ${key}: ${value}`).join('\n')}\n`;
  const perKind = kind => policy(kind).filter(([key]) => ['cache-control', 'content-security-policy'].includes(key));
  const headers = [block('/*', common), ...HTML_ROUTES.map(path => block(path, perKind('html'))), block('/assets/*', perKind('immutable-asset')), block('/manifest.webmanifest', perKind('asset')), block('/sw.mjs', perKind('html'))].join('\n');
  await writeFile(join(outDir, '_headers'), headers);
  await writeFile(join(outDir, '_redirects'), ['/ /index.html 200', '/join /index.html 200', '/privacy /index.html 200', '/help /index.html 200', '/cases /index.html 200', '/check /check.html 200', '/admin /admin.html 200', ...['J', 'j', 'D', 'd', 'P', 'p', 'sessions', 'cases'].map(route => `/${route}/* /room.html 200`)].join('\n') + '\n');
  return { environment: env, cacheName, shell, hashedFiles: [...new Set(hashedFiles)].sort(), entries: Object.fromEntries([...emitted].filter(([file]) => /\/(console|projector|phone|check|pair|app|admin|home|library|console-tones|groups-screen|help|splash|console-room-tab|account-session)\.mjs$/.test(file)).map(([file, target]) => [basename(file, '.mjs'), target])) };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2); let env = 'local'; let buildSha;
  for (let i = 0; i < args.length; i++) { if (args[i] === '--env') env = args[++i]; else if (args[i] === '--build-sha') buildSha = args[++i]; else throw new Error('unknown_option'); }
  buildSha ??= execFileSync('git', ['rev-parse', 'HEAD'], { cwd: ROOT, encoding: 'utf8' }).trim();
  buildClient({ env, buildSha }).then(result => console.log(`client build: ${result.environment}; ${result.hashedFiles.length} hashed files`)).catch(() => { console.error('client build failed'); process.exitCode = 1; });
}
