// Standalone entry: private administration is never imported by the participant shell.
import {node,mountAccount,accountRequest} from './auth-ui.mjs';
import {casesUrl} from '../shared/urls.mjs';
import {startShell} from './shell.mjs';
import {createAdminApi} from './admin-api.mjs';
import {createAdminModel} from './admin-model.mjs';
import {createAdminPolling} from './admin-polling.mjs';
import {createAdminActionFlow} from './admin-action-flow.mjs';

const TABS={facilitators:'Facilitators',cases:'Cases',groups:'Groups',rooms:'Live rooms',audit:'Audit'};
const DESTRUCTIVE=new Set(['facilitators_disable','facilitators_soft_delete','versions_withdraw','cases_publish','rooms_end']);
const text=value=>value===null||value===undefined?'Not recorded':String(value);
const date=value=>value?new Date(value).toLocaleString():'Not recorded';
const groupLabel=row=>row.group_name??'Ungrouped';
const recordKey=(tab,row)=>tab==='facilitators'?row.id:tab==='cases'?row.version_id:tab==='rooms'?row.sessionId:row.id;
// Erase retained descendants as well as removing them from the document.
function erase(root){for(const child of root.querySelectorAll('*')){if('value' in child)child.value='';for(const name of ['data-record','aria-label','title'])child.removeAttribute(name);child.textContent='';}root.replaceChildren();}
export function mountAdmin({origin=location.origin}={}){
 const surface=document.getElementById('adminSurface'),account=document.getElementById('adminAccount'),dialog=document.getElementById('adminConfirmation');
 let model=null,api=null,polling=null,flow=null,closed=false,pauseNotice=false,restoreFocus=null,focusRecord=null,authRef=null,accountUi=null,accountEmail=undefined;
 // Card 30: Administration -> Groups is its own lazily loaded screen (groups-screen.mjs) kept across renders.
 let groupsView=false,groupsScreen=null,caseGroup=null;const groupsHost=node('div',null,'admin-groups');
 const request=(parts,options)=>accountRequest(authRef,parts,options);
 function closeGroups(){groupsScreen?.close();groupsScreen=null;groupsHost.replaceChildren();}
 async function openGroups(){
  if(closed||!model||groupsScreen)return;groupsView=true;render();
  const g=model;let workspaces;
  try{const [loaded,me]=await Promise.all([import('./groups-screen.mjs'),request(['me'],{query:new URLSearchParams({limit:'100'})})]);
   if(closed||model!==g||!groupsView||groupsScreen)return;workspaces=(me?.memberships??[]).filter(m=>typeof m?.workspace_id==='string');
   groupsScreen=loaded.mountGroups(groupsHost,{request,workspaces,admin:true,stepUp:{has:()=>g.hasElevation(),token:()=>g.elevationToken(),drop:()=>g.clearElevation(),
    sendCode:async()=>{const r=await api.call('stepup_start',{body:{}});return {ok:r.ok,error:r.error};},
    verify:async code=>{const r=await api.call('stepup_verify',{body:{code}});return r.ok&&g.setElevation(r.data.elevation)?{ok:true}:{ok:false,error:r.error};}}});
  }catch{if(!closed&&groupsView)groupsHost.replaceChildren(status('Groups are unavailable. Try again.'));}
 }
 const button=(label,action,primary=false)=>{const item=node('button',label,primary?'btn primary':'btn');item.type='button';item.addEventListener('click',action);return item;};
 const status=(label,className='admin-notice')=>{const item=node('p',label,className);item.setAttribute('role','status');return item;};
 function cleanup(reason='sign_out'){
  restoreFocus=null;focusRecord=null;accountEmail=undefined;groupsView=false;closeGroups();caseGroup?.close();caseGroup=null;polling?.close();flow?.close();model?.clear(reason);api?.close();polling=null;flow=null;model=null;api=null;pauseNotice=false;
  if(dialog.open)dialog.close();erase(dialog);erase(surface);surface.append(status('Sign in to continue.'));document.querySelector('h1')?.focus();
 }
 function details(items){const dl=node('dl');for(const [label,value] of items){dl.append(node('dt',label),node('dd',text(value)));}return dl;}
 function action(operation,label){const item=button(label,()=>{if(closed||!model||model.state.acting)return;if(DESTRUCTIVE.has(operation)){restoreFocus=item;focusRecord=model.state.selected?recordKey(model.state.tab,model.state.selected):null;if(!flow.begin(operation)){restoreFocus=null;focusRecord=null;}}else void model.act(operation);});item.disabled=model.state.acting;return item;}
 function renderDrawer(work,state){
  const row=state.selected;if(!row)return;
  const drawer=node('aside',null,'admin-drawer');drawer.setAttribute('aria-label','Selected record');drawer.tabIndex=-1;
  const title=state.tab==='facilitators'?row.email:state.tab==='cases'?row.title:state.tab==='rooms'?row.code:row.action;
  drawer.append(node('h3',title),button('Close details',()=>{flow.cancel();model.cancel();}));
  const actions=node('div',null,'admin-actions');
  if(state.tab==='facilitators'){
   const profile=row.profile;
   drawer.append(details([['Confirmed',date(row.confirmedAt)],['Invited',date(row.invitedAt)],['Created',date(row.createdAt)],['Disabled',date(profile?.disabled_at)],['Deleted',date(profile?.soft_deleted_at)],['Deletion due',date(profile?.delete_due_at)],['Revision',profile?.admin_revision]]));
   if(!row.confirmedAt)actions.append(action('facilitators_resend','Resend invitation'));
   if(!profile)drawer.append(node('p','Administrative profile is not yet available. Changes are unavailable.','admin-muted'));
   else if(profile.soft_deleted_at){if(profile.delete_due_at&&Date.parse(profile.delete_due_at)>Date.now())actions.append(action('facilitators_restore','Restore'));drawer.append(node('p','A claimed deletion may require manual reconciliation. Restore is subject to server verification.','admin-muted'));}
   else {actions.append(action(profile.disabled_at?'facilitators_enable':'facilitators_disable',profile.disabled_at?'Enable':'Disable'),action('facilitators_soft_delete','Soft delete'));}
  }else if(state.tab==='cases'){
   drawer.append(details([['Version',row.version_no],['Status',row.status],['Revision',row.admin_revision],['Group',groupLabel(row)]]));
   actions.append(action(row.status==='published'?'versions_withdraw':'cases_publish',row.status==='published'?'Withdraw':'Republish'));
   // Change group (P-20, no step-up): the case's own workspace; a success reloads the list.
   const change=button('Change group',()=>{change.remove();void import('./groups-screen.mjs').then(loaded=>{if(closed||!model||model.state.selected!==row)return;caseGroup?.close();
    caseGroup=loaded.mountCaseGroup(drawer,{request,workspaceId:row.workspace_id,caseId:row.case_id,group:{id:row.group_id,name:row.group_name,tint:row.tint,revision:row.group_revision},onChanged:()=>{caseGroup?.close();caseGroup=null;void model?.load();}});}).catch(()=>{});});
   change.disabled=state.acting;actions.append(change);
   drawer.append(node('p','Republishing uses this existing immutable version. New case authoring is separate.','admin-muted'));
  }else if(state.tab==='rooms'){
   drawer.append(details([['Registered',row.registeredAt?date(row.registeredAt):'Age unknown'],['Expires',date(row.expiresAt)],['Owner',row.ownerEmail??'Unknown'],['Phase',row.phase],['Participants',row.participantCount]]));actions.append(action('rooms_end','End room'));
   drawer.append(node('p','Ending revokes facilitator access. Participant recap follows the existing retention deadline.','admin-muted'));
  }else{
   drawer.append(details([['Event',row.id],['Intent',row.intent_id],['Phase',row.phase],['Actor',row.actor_email],['Target type',row.target_type],['Target',row.target_id],['Recorded',date(row.at)],['Network prefix',row.from_prefix]]));
   for(const [label,snapshot] of [['Before',row.before],['After',row.after]])drawer.append(node('h4',label),details(Object.entries(snapshot??{}).map(([key,value])=>[key,text(value)])));
   drawer.append(node('p','Phase is shown as recorded. An outcome may be on another page. Audit records cannot be edited.','admin-muted'));
  }
  drawer.append(actions);work.append(drawer);return drawer;
 }
 async function loadAccount(){
  if(accountEmail!==undefined)return;accountEmail=null;
  try{const e=(await request(['me'],{query:new URLSearchParams({limit:'1'})}))?.account?.email;if(closed||!authRef)return;if(typeof e==='string')accountEmail=e;}catch{return;}
  if(model?.state.gate==='admin_only')render();
 }
 function renderDenied(){
  const who=node('p',null,'admin-muted'),back=node('a','Back to cases','btn primary'),other=node('button','Sign in with another account','btn tertiary'),denied=node('div',null,'admin-denied');
  who.append("You're signed in as ",accountEmail?node('strong',accountEmail):'this account',". Signing in again won't change this.");
  back.href=casesUrl(location.origin);other.type='button';
  other.onclick=()=>accountUi.signOut.click();
  denied.append(node('h2',"This account doesn't have administrator access"),who,node('p','If you should have access, ask the Case owner to add this address.'),back,other);
  surface.append(denied);void loadAccount();
 }
 function render(){
  if(closed||!model)return;
  const state=model.state;groupsHost.remove();erase(surface);caseGroup?.close();caseGroup=null;
  if(state.gate!=='ready'){
   if(!state.loading&&state.gate==='admin_only'){renderDenied();return;}
   surface.append(status(state.loading?'Loading administration…':state.gate==='sign_in'?'Sign in to continue.':'Administration is unavailable.'));
   if(state.gate==='unavailable')surface.append(button('Refresh information',()=>void model.load()));return;
  }
  const nav=node('nav',null,'admin-nav');nav.setAttribute('aria-label','Administration sections');
  for(const [tab,label] of Object.entries(TABS)){const item=button(label,()=>{flow.cancel();if(tab==='groups'){void openGroups();return;}groupsView=false;closeGroups();void model.load({tab,page:1});});if(groupsView?tab==='groups':state.tab===tab)item.setAttribute('aria-current','page');item.disabled=state.acting;nav.append(item);}
  if(groupsView){const work=node('section',null,'admin-work');work.append(groupsHost);surface.append(nav,work);return;}
  const work=node('section',null,'admin-work');work.append(node('h2',TABS[state.tab]));
  if(state.loading){work.append(status('Loading administration…'));surface.append(nav,work);return;}
  if(pauseNotice)work.append(status('Automatic refresh is paused after inactivity. Use any control to continue.'));
  if(state.notice)work.append(status(state.notice));
  const toolbar=node('div',null,'admin-toolbar');toolbar.append(button('Refresh information',()=>{flow.cancel();void model.load();}));
  if(state.tab==='facilitators'){
   const search=node('form',null,'admin-toolbar'),label=node('label','Find facilitator by email'),input=node('input');input.type='search';input.maxLength=320;input.value=state.query;label.append(input);
   const submit=node('button','Search','btn');submit.type='submit';search.append(label,submit);search.addEventListener('submit',event=>{event.preventDefault();if(!closed&&!model.state.acting){flow.cancel();void model.search(input.value);}});toolbar.append(search);
   const invite=node('form',null,'admin-toolbar'),inviteLabel=node('label','Invite email'),email=node('input');email.type='email';email.required=true;email.maxLength=320;email.autocomplete='off';inviteLabel.append(email);
   const send=node('button','Invite facilitator','btn');send.type='submit';send.disabled=state.acting;invite.append(inviteLabel,send);invite.addEventListener('submit',event=>{event.preventDefault();if(!closed&&!model.state.acting){const value=email.value;email.value='';void model.act('facilitators_invite',{email:value});}});toolbar.append(invite);
  }
  work.append(toolbar);
  const headings=state.tab==='facilitators'?['Email','State','Confirmed']:state.tab==='cases'?['Case','Version','Status','Group']:state.tab==='rooms'?['Code','Phase','Participants','Owner','Registered']:['Action','Phase','Actor','Recorded'];
  const table=node('table',null,'admin-table'),caption=node('caption',`${TABS[state.tab]} · current page`),head=node('thead'),headRow=node('tr'),body=node('tbody');
  for(const label of headings){const th=node('th',label);th.scope='col';headRow.append(th);}head.append(headRow);
  for(const row of state.rows){
   const tr=node('tr'),td=node('td'),select=node('button',state.tab==='facilitators'?row.email:state.tab==='cases'?row.title:state.tab==='rooms'?row.code:row.action,'btn tertiary');select.type='button';select.dataset.record=recordKey(state.tab,row);td.append(select);tr.append(td);
   const columns=state.tab==='facilitators'?[row.profile?.soft_deleted_at?'Soft deleted':row.profile?.disabled_at?'Disabled':row.profile?'Active':'Profile pending',date(row.confirmedAt)]:state.tab==='cases'?[row.version_no,row.status,groupLabel(row)]:state.tab==='rooms'?[row.phase,row.participantCount,row.ownerEmail??'Unknown',row.registeredAt?date(row.registeredAt):'Age unknown']:[row.phase,row.actor_email,date(row.at)];
   for(const value of columns)tr.append(node('td',text(value)));body.append(tr);
  }
  // Delegation resolves against current memory rather than retaining private row objects in closures.
  table.addEventListener('click',event=>{if(closed||!model||model.state.acting)return;const key=event.target.closest('button[data-record]')?.dataset.record;if(!key)return;const row=model.state.rows.find(item=>recordKey(model.state.tab,item)===key);if(row){flow.cancel();model.select(row);surface.querySelector('.admin-drawer')?.focus();}});
  table.append(caption,head,body);const content=node('div',null,'admin-content'),list=node('div',null,'admin-list'),scroll=node('div',null,'admin-scroll');scroll.append(table);list.append(scroll);content.append(list);work.append(content);
  if(!state.rows.length)list.append(node('p','No records on this page.','admin-muted'));
  const pagination=node('div',null,'admin-pagination');pagination.append(node('p',state.tab==='facilitators'?`Page ${state.page}`:'Keyset page'));
  if(state.tab==='facilitators'&&state.page>1)pagination.append(button('Previous page',()=>void model.load({page:state.page-1})));
  if(state.next!==null)pagination.append(button('Next page',()=>void model.load(state.tab==='facilitators'?{page:state.next}:{after:state.next})));
  list.append(pagination);renderDrawer(content,state);surface.append(nav,work);
  for(const control of surface.querySelectorAll('button,input'))if(state.acting)control.disabled=true;
 }
 function renderDialog(){
  if(closed||!flow)return;const state=flow.state;
  if(!state.open){if(dialog.open)dialog.close();erase(dialog);const target=restoreFocus?.isConnected?restoreFocus:[...surface.querySelectorAll('button[data-record]')].find(item=>item.dataset.record===focusRecord);target?.focus();restoreFocus=null;focusRecord=null;return;}
  erase(dialog);dialog.append(node('h2',state.phase==='confirm'?'Confirm destructive action':'Verify your email code'));dialog.querySelector('h2').id='adminConfirmationTitle';
  dialog.append(node('p',state.phase==='confirm'?`Type ${state.label} exactly to continue.`:'This confirmation lasts until you sign out and applies only to your account.'));
  const form=node('form'),label=node('label',state.phase==='confirm'?'Type the target':'Six-digit email code'),input=node('input');input.required=true;input.autocomplete='off';
  if(state.phase==='code'){input.inputMode='numeric';input.pattern='[0-9]{6}';input.maxLength=6;}else input.maxLength=320;
  label.append(input);const submit=node('button',state.phase==='confirm'&&!state.elevated?'Send verification code':'Confirm action','btn primary');submit.type='submit';submit.disabled=state.busy;input.disabled=state.busy;
  form.append(label,submit);form.addEventListener('submit',event=>{event.preventDefault();if(closed||!flow||flow.state.busy)return;const value=input.value;input.value='';void (flow.state.phase==='confirm'?flow.sendCode(value):flow.verify(value));});dialog.append(form,button('Cancel',()=>flow.cancel()));
  if(state.notice)dialog.append(status(state.notice));if(!dialog.open)dialog.showModal();if(!state.busy)input.focus();
 }
 dialog.addEventListener('cancel',event=>{event.preventDefault();flow?.cancel();});
 document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!dialog.open&&model?.state.selected){model.cancel();}});
 for(const type of ['pointerdown','keydown'])surface.addEventListener(type,()=>{void polling?.activity();});
 accountUi=mountAccount(account,{idleText:'',onSignedOut:cleanup,onSignedIn:auth=>{
  if(closed)return;cleanup('account_change');authRef=auth;api=createAdminApi({origin,auth});model=createAdminModel({api,onChange:render});flow=createAdminActionFlow({model,api,onChange:renderDialog});
  polling=createAdminPolling({refresh:async()=>{
   const current=model,active=document.activeElement;
   if(!current||groupsView||current.state.selected||current.state.acting||flow.state.open||
      (surface.contains(active)&&active.matches('input,textarea,select,[contenteditable],form button')))return;
   const key=surface.contains(active)?active.closest('button[data-record]')?.dataset.record:null;
   if(await current.load()&&!closed&&model===current&&!current.state.selected&&!flow.state.open&&document.activeElement===document.body)
    [...surface.querySelectorAll('button[data-record]')].find(item=>item.dataset.record===key)?.focus();
  },onPause:value=>{pauseNotice=value;render();}});
  void model.load().then(()=>{if(!closed&&model)polling?.start();});
 }});
 window.addEventListener('pagehide',()=>{closed=true;cleanup('pagehide');},{once:true});
 return {clear:cleanup};
}
// No callback secrets are retained in this entry's URL. Auth callbacks use the root entry.
{const entryUrl=new URL(location.href);if(entryUrl.search||entryUrl.hash)history.replaceState(null,'',entryUrl.origin+entryUrl.pathname);}
mountAdmin();startShell();
