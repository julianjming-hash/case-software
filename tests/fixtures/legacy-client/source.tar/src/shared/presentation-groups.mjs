// The authored surface stays whole on the facilitator device. Public roles receive only the
// groups the room authority has deliberately revealed. Asset IDs remain private until a
// visible media delivery contract exists; no invisible group consumes a reveal press.
import { populatedPresentationGroups } from './presentation-order.mjs';
export { PRESENTATION_GROUPS, populatedPresentationGroups } from './presentation-order.mjs';

export function publicPresentationSurface(surface, shown) {
  const groups = populatedPresentationGroups(surface);
  const count = Number.isSafeInteger(shown) && shown >= 0 ? Math.min(shown, groups.length) : 0;
  const visible = new Set(groups.slice(0, count));
  return {
    surfaceId: surface.surfaceId,
    kind: surface.kind,
    title: surface.title,
    scene: visible.has('scene') ? surface.scene : null,
    assetIds: [],
    observations: visible.has('observations') ? surface.observations : [],
    points: visible.has('findings') ? surface.points : [],
    investigations: visible.has('investigations') ? surface.investigations : [],
    timelineKind: surface.timelineKind,
    manual: surface.manual,
    at: surface.at,
  };
}
