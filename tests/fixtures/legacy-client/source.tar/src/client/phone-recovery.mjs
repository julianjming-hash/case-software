// Counts-only validation before participant private-storage cleanup. No draft is returned.
import { normalizeCode, JOIN_CODE_LENGTH, isUuidV7 } from '../shared/ids.mjs';
import { parseCommandEnvelope } from '../shared/wire.mjs';
import { PARTICIPANT_TOKEN_MAX_MS } from './transport.mjs';
import { OUTBOX_LIMIT, isVoteResponse } from './outbox.mjs';
import { openVoteStore } from './vote-store.mjs';
import { apiPath } from '../shared/urls.mjs';

const refused = () => ({ preserve: false, count: 0 });
export function validateParticipantRecovery({ role, sessionId, credential, rows, now = Date.now(), knownInventory }) {
  if (role !== 'participant' || knownInventory !== true || !isUuidV7(sessionId) || !credential ||
      Object.keys(credential).sort().join(',') !== 'expiresAt,sessionId,token' ||
      credential.sessionId !== sessionId || typeof credential.token !== 'string' ||
      !/^[A-Za-z0-9._~-]{16,4096}$/.test(credential.token) || !Number.isSafeInteger(credential.expiresAt) ||
      credential.expiresAt <= now || credential.expiresAt > now + PARTICIPANT_TOKEN_MAX_MS ||
      !Array.isArray(rows) || rows.length > OUTBOX_LIMIT) return refused();
  const ids = new Set();
  for (const row of rows) {
    if (!row || Object.keys(row).sort().join(',') !== 'envelope,participantId,roomId,superseded' ||
        row.roomId !== sessionId || !isUuidV7(row.participantId) || typeof row.superseded !== 'boolean' ||
        !parseCommandEnvelope(row.envelope, 'participant').ok || row.envelope.type !== 'vote' ||
        !isUuidV7(row.envelope.clientEventId) || !isVoteResponse(row.envelope.response) || ids.has(row.envelope.clientEventId)) return refused();
    ids.add(row.envelope.clientEventId);
  }
  return { preserve: true, count: rows.filter(row => !row.superseded).length };
}

export async function readParticipantRecovery({ openStore = openVoteStore, timeoutMs = 1000, ...state }) {
  if (!validateParticipantRecovery({ ...state, rows: [] }).preserve) return refused();
  let store, timer, expired = false;
  const duration = Number.isFinite(timeoutMs) ? Math.max(1, Math.min(1000, timeoutMs)) : 1000;
  const read = Promise.resolve().then(async () => {
    store = await openStore();
    if (expired) { store.close().catch(() => {}); return refused(); }
    try { return validateParticipantRecovery({ ...state, rows: await store.read(state.sessionId) }); }
    catch { return refused(); }
  }).catch(() => refused());
  const deadline = new Promise(resolve => { timer = setTimeout(() => { expired = true; resolve(refused()); }, duration); });
  try { return await Promise.race([read, deadline]); }
  finally { clearTimeout(timer); store?.close().catch(() => {}); }
}

/** A QR never resumes a different saved room; transient failure leaves the decision pending. */
export async function recoverJoinCapability({code,credential,fetch=globalThis.fetch,timeoutMs=10_000}) {
  const normalized = normalizeCode(code,JOIN_CODE_LENGTH);
  if (!normalized || normalized.length !== JOIN_CODE_LENGTH ||
      !validateParticipantRecovery({role:'participant',sessionId:credential?.sessionId,credential,rows:[],knownInventory:true}).preserve) return {status:'refused'};
  const controller=new AbortController();let timer,reader,responseBody;
  const unavailable=()=>({status:'unavailable'});
  const task=Promise.resolve().then(async()=>{
    const response=await fetch(apiPath('join','recover'),{method:'POST',credentials:'omit',redirect:'manual',cache:'no-store',referrerPolicy:'no-referrer',signal:controller.signal,
      headers:{'content-type':'application/json',authorization:`Bearer ${credential.token}`},body:JSON.stringify({code:normalized,sessionId:credential.sessionId})});
    responseBody=response.body;
    if(controller.signal.aborted){try{Promise.resolve(response.body?.cancel()).catch(()=>{});}catch{/* Late response is discarded. */}return unavailable();}
    if(!response.ok)return [401,403,404,410].includes(response.status)?{status:'refused'}:unavailable();
    if(!response.body||Number(response.headers.get('content-length')||0)>1024)return {status:'refused'};
    reader=response.body.getReader();const chunks=[];let n=0;
    for(;;){const next=await reader.read();if(next.done)break;n+=next.value.byteLength;if(n>1024)return {status:'refused'};chunks.push(next.value);}
    const bytes=new Uint8Array(n);let at=0;for(const chunk of chunks){bytes.set(chunk,at);at+=chunk.byteLength;}
    const body=JSON.parse(new TextDecoder().decode(bytes));
    return body&&Object.keys(body).length===1&&body.sessionId===credential.sessionId?{status:'recovered',sessionId:body.sessionId}:{status:'refused'};
  }).catch(unavailable);
  const duration=Number.isSafeInteger(timeoutMs)&&timeoutMs>0&&timeoutMs<=10_000?timeoutMs:10_000;
  const deadline=new Promise(resolve=>{timer=setTimeout(()=>resolve(unavailable()),duration);});
  try{return await Promise.race([task,deadline]);}
  finally{clearTimeout(timer);controller.abort();try{Promise.resolve(reader ? reader.cancel() : responseBody?.cancel()).catch(()=>{});}catch{/* Cancellation cannot hold recovery. */}}
}

/** Enumerate actual writers' storage before choosing the participant-only preservation exception. */
export async function inspectPhoneInventory({sessionStorage,localStorage,indexedDB,assertKnownStorageKeys,knownDatabases,timeoutMs=1000}) {
  let timer;
  try {
    const keys=[];
    for(const store of [sessionStorage,localStorage]){
      if(!store||!Number.isInteger(store.length)||store.length<0||store.length>1000)return false;
      for(let i=0;i<store.length;i++){const key=store.key(i);if(typeof key!=='string')return false;keys.push(key);}
    }
    assertKnownStorageKeys(keys);
    if(!indexedDB?.databases||!Array.isArray(knownDatabases))return false;
    const duration=Number.isSafeInteger(timeoutMs)&&timeoutMs>0&&timeoutMs<=1000?timeoutMs:1000;
    const expired=new Promise(resolve=>{timer=setTimeout(()=>resolve(null),duration);});
    const databases=await Promise.race([Promise.resolve().then(()=>indexedDB.databases()).catch(()=>null),expired]);
    if(!Array.isArray(databases)||databases.length>1000)return false;
    return databases.every(db=>typeof db?.name==='string'&&(!/^(case:|case-lab:)/.test(db.name)||knownDatabases.includes(db.name)));
  }catch{return false;}finally{clearTimeout(timer);}
}
