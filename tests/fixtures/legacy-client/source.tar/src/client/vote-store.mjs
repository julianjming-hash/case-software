// Phone-owned IndexedDB queue; no account or room credentials are persisted here.
import { reopenOnce } from './idb.mjs';

export const VOTE_DATABASE = 'case:phone-outbox';

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(VOTE_DATABASE, 1);
    request.onupgradeneeded = () => {
      const store = request.result.createObjectStore('votes', { keyPath: 'envelope.clientEventId' });
      store.createIndex('roomId', 'roomId');
    };
    request.onerror = () => reject(request.error);
    request.onblocked = () => reject(new Error('Vote storage unavailable'));
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => db.close();
      resolve(db);
    };
  });
}

export function openVoteStore({ openDatabase: factory = openDatabase } = {}) {
  const database = reopenOnce(factory); let tail = Promise.resolve(), closed = false;
  return {
    read(roomId) {
      if (closed) return Promise.reject(new Error('Vote storage closed'));
      return tail.then(() => database.run(db => new Promise((resolve, reject) => {
        const tx = db.transaction('votes', 'readonly');
        const request = tx.objectStore('votes').index('roomId').getAll(roomId);
        tx.oncomplete = () => resolve(request.result);
        tx.onerror = tx.onabort = () => reject(tx.error ?? new Error('Vote storage unavailable'));
        request.onerror = () => reject(request.error);
      })));
    },
    update(roomId, change) {
      if (closed) return Promise.reject(new Error('Vote storage closed'));
      const task = tail.then(() => database.run(db => new Promise((resolve, reject) => {
        const tx = db.transaction('votes', 'readwrite'), store = tx.objectStore('votes');
        let result;
        tx.oncomplete = () => resolve(result);
        tx.onerror = tx.onabort = () => reject(tx.error ?? new Error('Vote storage unavailable'));
        const request = store.index('roomId').getAll(roomId);
        request.onerror = () => reject(request.error);
        request.onsuccess = () => {
          try {
            const next = change(request.result);
            if (!next || !Array.isArray(next.rows) || next.rows.some(row => row.roomId !== roomId)) throw new TypeError('Invalid vote storage update');
            for (const row of request.result) store.delete(row.envelope.clientEventId);
            for (const row of next.rows) store.put(row);
            result = next.result;
          } catch (error) { tx.abort?.(); reject(error); }
        };
      })));
      tail = task.catch(() => {});
      return task;
    },
    async close() { closed = true; await tail; await database.close(); },
  };
}
