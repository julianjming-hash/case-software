// Gesture-gated, on-demand sample player shared by the projector's event cues and the console's UI tones
// (CASE-169). `map` is kind -> sample name; `fallback(ctx, kind)` runs when a sample is unavailable (omit for
// silence); `volume` is 0..1 and scales gain (0 is silent). Nothing plays without a running context.
export function createCuePlayer({ urls = {}, fetchImpl = (...a) => fetch(...a), enabled, reduced, hidden, getContext, map, fallback, volume = () => 1 }) {
  const buffers = new Map();
  let generation = {};
  const ready = () => { const ctx = getContext(); return enabled() && volume() > 0 && !reduced() && !hidden() && ctx?.state === 'running' && ctx; };
  return {
    // Fence pending playback while retaining the sample cache.
    cancel() { generation = {}; },
    /** Resolves 'sample', 'tone' or null (silent). Conditions are re-checked after the load. */
    async play(kind) {
      const started = generation, cue = map[kind]; let ctx = Object.hasOwn(map, kind) && ready(); if (!ctx) return null;
      let pending = buffers.get(cue);
      if (!pending) {
        pending = (async () => {
          const response = urls[cue] && await fetchImpl(urls[cue], { credentials: 'omit' });
          if (!response?.ok) throw new Error();
          return ctx.decodeAudioData(await response.arrayBuffer());
        })();
        pending.catch(() => buffers.delete(cue)); buffers.set(cue, pending);
      }
      const buffer = await pending.catch(() => null);
      if (started !== generation || !(ctx = ready())) return null;
      if (!buffer) return fallback ? (fallback(ctx, kind), 'tone') : null;
      const source = ctx.createBufferSource(), gain = ctx.createGain();
      source.buffer = buffer; gain.gain.value = volume(); source.connect(gain); gain.connect(ctx.destination); source.start();
      source.onended = () => { source.disconnect(); gain.disconnect(); };
      return 'sample';
    },
  };
}
