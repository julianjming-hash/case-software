// The site bar and menu (card 29, CASE-166): one menu for every role on the root and the facilitator
// documents. A native modal <dialog> traps focus and closes on Escape; focus returns to the menu button.
// Signed out it offers Join a room, one Facilitator sign in, Help (a page, card 36a), Privacy and Appearance. Signed in (only
// in a document that holds the account) it adds the account with Sign out, Your cases, and Administration
// only when the Worker says the account is entitled. The root never reads or restores an account.
import { appearanceControl } from './appearance.mjs';
import { homeUrl, casesUrl, privacyUrl, adminPageUrl } from '../shared/urls.mjs';
/** Help is a public static page (card 36a); the route is matched by the shell (app.mjs), not parseRoute. */
export const helpUrl = (origin = location.origin) => `${origin}/help`;

const SVG = 'http://www.w3.org/2000/svg';
const el = (tag, text, className) => {
  const item = document.createElement(tag);
  if (text != null) item.textContent = text;
  if (className) item.className = className;
  return item;
};
function icon(d) {
  const svg = document.createElementNS(SVG, 'svg'); svg.setAttribute('class', 'ic'); svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('aria-hidden', 'true');
  const path = document.createElementNS(SVG, 'path'); path.setAttribute('d', d); svg.append(path); return svg;
}
/** The wordmark: the 2×2 tessera and CASE. Decorative SVG built node by node. */
export function wordmark() {
  const mark = el('a', null, 'wordmark'); mark.href = homeUrl(location.origin);
  const svg = document.createElementNS(SVG, 'svg'); svg.setAttribute('class', 'tessera'); svg.setAttribute('viewBox', '0 0 16 16');
  svg.setAttribute('aria-hidden', 'true');
  for (const [x, y, c] of [[0, 0, ''], [9, 0, 't2'], [0, 9, 't3'], [9, 9, '']]) {
    const r = document.createElementNS(SVG, 'rect'); r.setAttribute('x', x); r.setAttribute('y', y);
    r.setAttribute('width', '7'); r.setAttribute('height', '7'); r.setAttribute('rx', '1'); if (c) r.setAttribute('class', c);
    svg.append(r);
  }
  mark.append(svg, el('span', 'CASE'));
  mark.setAttribute('aria-label', 'Case home');
  return mark;
}

export function mountSiteHeader(host, { context = null, current = 'join' } = {}) {
  const bar = el('header', null, 'site-bar');
  const open = el('button', null, 'menu-button'); open.type = 'button';
  open.setAttribute('aria-label', 'Open menu'); open.setAttribute('aria-haspopup', 'dialog');
  open.append(icon('M4 7h16M4 12h16M4 17h16'));
  bar.append(wordmark());
  if (context) bar.append(el('span', context, 'site-context'));
  bar.append(open);
  const dialog = el('dialog', null, 'site-menu'); dialog.setAttribute('aria-labelledby', 'siteMenuTitle');
  const head = el('div', null, 'site-menu-head');
  const title = el('h2', 'Menu'); title.id = 'siteMenuTitle';
  const close = el('button', null, 'menu-button'); close.type = 'button'; close.setAttribute('aria-label', 'Close menu');
  close.append(icon('M6 6l12 12M18 6L6 18'));
  head.append(title, close);
  const account = el('section', null, 'site-account'); account.hidden = true; account.setAttribute('aria-label', 'Account');
  const nav = el('nav', null, 'site-nav'); nav.setAttribute('aria-label', 'Main');
  dialog.append(head, account, nav, appearanceControl());
  let signedIn = null;
  const link = (text, href, key, hint = null) => {
    const a = el('a', null, 'site-nav-link'); a.href = href; a.append(el('span', text));
    if (hint) a.append(el('span', hint, 'site-nav-hint'));
    if (key === current) a.setAttribute('aria-current', 'page');
    return a;
  };
  function renderNav() {
    const origin = location.origin;
    const items = [link('Join a room', homeUrl(origin), 'join')];
    if (!signedIn) items.push(link('Facilitator sign in', casesUrl(origin), 'cases', 'Cases, rooms and administration'));
    else {
      items.push(link('Your cases', casesUrl(origin), 'cases'));
      if (signedIn.administration === true) items.push(link('Administration', adminPageUrl(origin), 'admin'));
    }
    items.push(link('Help', helpUrl(origin), 'help'), link('Privacy', privacyUrl(origin), 'privacy'));
    nav.replaceChildren(...items);
    account.replaceChildren();
    account.hidden = !signedIn;
    if (signedIn) {
      const out = el('button', 'Sign out', 'btn quiet'); out.type = 'button';
      out.addEventListener('click', () => { dialog.close(); signedIn?.signOut(); });
      account.append(el('p', 'Signed in as', 'site-account-label'), el('p', signedIn.email || 'Facilitator account', 'site-account-email'), out);
    }
  }
  renderNav();
  open.addEventListener('click', () => { if (!dialog.open) dialog.showModal(); });
  close.addEventListener('click', () => dialog.close());
  // A click on the backdrop (outside the panel) closes the menu.
  dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
  dialog.addEventListener('close', () => { if (open.isConnected) open.focus(); });
  // Keep Tab and Shift+Tab inside the open menu (a modal dialog may otherwise hand focus to the page body).
  dialog.addEventListener('keydown', event => {
    if (event.key !== 'Tab') return;
    const items = [...dialog.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), summary')]
      .filter(item => item.getClientRects().length && (item.type !== 'radio' || item.checked));
    if (!items.length) return;
    const first = items[0], last = items.at(-1);
    if (event.shiftKey && (document.activeElement === first || !dialog.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && (document.activeElement === last || !dialog.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
  });
  host.prepend(bar); document.body.append(dialog);
  return {
    bar, dialog,
    /** Signed-in details come only from the Worker's /me answer; null signs the menu out. */
    setAccount(value) {
      signedIn = value && typeof value.signOut === 'function'
        ? { email: typeof value.email === 'string' ? value.email : null, administration: value.administration === true, signOut: value.signOut }
        : null;
      renderNav();
    },
    remove() { if (dialog.open) dialog.close(); dialog.remove(); bar.remove(); },
  };
}
