// One cleanup path for sign-out, room end, idle lock, account change and tab close.
// The broad Case prefixes intentionally catch a newly added key until the inventory is updated.
import { isUuidV7 } from '../shared/ids.mjs';
export const TEARDOWN_KEYS = Object.freeze({
  sessionPrefixes: Object.freeze(['case:', 'case-lab:']),
  localPrefixes: Object.freeze(['case:', 'case-lab:']),
  keepOnly: 'case:transport:pin',
  // Device preferences that are not personal data (card 29: Appearance) survive every teardown.
  preferences: Object.freeze(['case:appearance']),
  knownKeyPrefixes: Object.freeze(['case-lab:segment:']),
  knownExact: Object.freeze(['case:auth:refresh', 'case:auth:pkce', 'case:transport:pin', 'case:appearance',
    'case:privacy-return-search', 'case:phone:join-code-draft', 'case:console:active-room']),
  knownPatterns: Object.freeze([/^case:(?:participant|display|facilitator):[^:]+:token$/,
    /^case:join-code-draft:[^:]+$/, /^case-lab:segment:[^:]+$/,
    /^case-lab:(?:participant|display|facilitator):[^:]+:token$/]),
  knownDatabases: Object.freeze(['case:phone-outbox']),
  shellCachePrefix: 'case-shell-',
  indexedDBPrefixes: Object.freeze(['case:', 'case-lab:']),
});

const isCaseKey = key => TEARDOWN_KEYS.sessionPrefixes.some(prefix => key.startsWith(prefix));
const knownKey = key => TEARDOWN_KEYS.knownExact.includes(key) ||
  TEARDOWN_KEYS.knownPatterns.some(pattern => pattern.test(key));
export function assertKnownStorageKeys(keys) {
  if (keys.some(key => isCaseKey(key) && !knownKey(key))) throw new Error('unlisted_case_key');
}

const REFRESH = 'case:auth:refresh';
/** CASE-175: a tab's room marker (an id); the reasons that end the account session. */
export const ACTIVE_ROOM_KEY = 'case:console:active-room';
const ACCOUNT_ENDS = ['sign_out', 'unauthorised', 'account_changed', 'refresh_failed', 'next_load_failed'];
const PKCE_MS = 10 * 60_000;
export function validPendingPkce(value, nowMs = Date.now()) {
  try {
    if (typeof value !== 'string' || value.length > 256) return null;
    const record = JSON.parse(value);
    if (!record || Object.keys(record).sort().join(',') !== 'createdAt,expiresAt,verifier' ||
        typeof record.verifier !== 'string' || !/^[A-Za-z0-9_-]{43,128}$/.test(record.verifier) ||
        !Number.isSafeInteger(record.createdAt) || !Number.isSafeInteger(record.expiresAt) ||
        record.createdAt > nowMs || record.expiresAt <= nowMs ||
        record.expiresAt - record.createdAt !== PKCE_MS) return null;
    return record;
  } catch { return null; }
}
const manualKeys = callback => {
  const keys = callback();
  if (!Array.isArray(keys) || keys.length > 1 || keys.some(key => typeof key !== 'string' ||
      !key.startsWith('case-lab:segment:') || !isUuidV7(key.slice('case-lab:segment:'.length))))
    throw new Error('invalid_manual_preservation');
  return keys;
};

export function authNavigationPreservation({ sessionStorage, now = Date.now, preserveSessionKeys = () => [] } = {}) {
  return {
    preserveSession: reason => reason === 'pagehide' || reason === 'next_load' ? [
      ...(validPendingPkce(sessionStorage?.getItem('case:auth:pkce'), now()) ? ['case:auth:pkce'] : []),
      ...(isUuidV7(sessionStorage?.getItem(ACTIVE_ROOM_KEY)) ? [ACTIVE_ROOM_KEY] : []), ...manualKeys(preserveSessionKeys)] : [],
  };
}

function clearStorage(store, prefixes, preserve) {
  if (!store) return true;
  try {
    const keys = [];
    for (let i = 0; i < store.length; i++) keys.push(store.key(i));
    let known = true;
    for (const key of keys) if (key && !preserve.includes(key) && prefixes.some(prefix => key.startsWith(prefix))) {
      if (!knownKey(key)) known = false;
      store.removeItem(key);
    }
    return known;
  } catch { return false; }
}

function deleteDatabase(indexedDB, name) {
  return new Promise(resolve => {
    try {
      const request = indexedDB.deleteDatabase(name);
      const timer = setTimeout(() => resolve(false), 1000);
      const finish = complete => { clearTimeout(timer); resolve(complete); };
      request.onsuccess = () => finish(true);
      request.onerror = () => finish(false);
      request.onblocked = () => finish(false);
    } catch { resolve(false); }
  });
}

const safeStorage = name => { try { return globalThis[name] ?? null; } catch { return null; } };

export function createTeardown({
  sessionStorage = safeStorage('sessionStorage'), localStorage = safeStorage('localStorage'),
  caches = globalThis.caches, indexedDB = globalThis.indexedDB, clearMemory = () => {},
  cleanupTimeoutMs = 1500, preserveSession = [], preserveLocal = [TEARDOWN_KEYS.keepOnly],
  preserveDatabases = [], accountEnds = ACCOUNT_ENDS,
} = {}) {
  return async function teardown(reason) {
    // Decide narrow pagehide exceptions before clearMemory clears the opt-in bit.
    let sessionKeep = [], localKeep = [], databaseKeep = [], complete = true;
    try {
      const requested = typeof preserveSession === 'function' ? preserveSession(reason) : preserveSession;
      if (!Array.isArray(requested) || requested.some(key => !knownKey(key))) complete = false;
      if (Array.isArray(requested) && (reason === 'pagehide' || reason === 'next_load'))
        sessionKeep = requested.filter(knownKey);
    }
    catch { complete = false; }
    try {
      const requested = typeof preserveLocal === 'function' ? preserveLocal(reason) : preserveLocal;
      if (!Array.isArray(requested) || requested.some(key => !knownKey(key))) complete = false;
      if (Array.isArray(requested)) localKeep = requested.filter(key => knownKey(key) &&
        ((reason === 'pagehide' || reason === 'next_load') || key === TEARDOWN_KEYS.keepOnly));
    }
    catch { complete = false; }
    if (!accountEnds.includes(reason)) localKeep.push(REFRESH);
    try {
      const requested = typeof preserveDatabases === 'function' ? preserveDatabases(reason) : preserveDatabases;
      if (!Array.isArray(requested) || requested.some(name => !TEARDOWN_KEYS.knownDatabases.includes(name)))
        complete = false;
      else if (reason === 'pagehide' || reason === 'next_load') databaseKeep = requested;
    } catch { complete = false; }
    // Memory is dropped before any asynchronous browser storage operation.
    try { clearMemory(reason); } catch { complete = false; }
    if (!clearStorage(sessionStorage, TEARDOWN_KEYS.sessionPrefixes, sessionKeep)) complete = false;
    if (!clearStorage(localStorage, TEARDOWN_KEYS.localPrefixes, [...localKeep, ...TEARDOWN_KEYS.preferences])) complete = false;
    let expired = false;
    const duration = Number.isFinite(cleanupTimeoutMs) ? Math.max(1, Math.min(1500, cleanupTimeoutMs)) : 1500;
    let timer;
    const timeout = new Promise(resolve => { timer = setTimeout(() => { expired = true; resolve(false); }, duration); });
    const cleanup = (async () => {
      const jobs = [];
      if (caches?.keys && caches?.delete) jobs.push((async () => {
        try {
          const names = await caches.keys();
          if (expired || !Array.isArray(names)) return false;
          const results = await Promise.allSettled(names.filter(name => !name.startsWith(TEARDOWN_KEYS.shellCachePrefix))
            .map(name => caches.delete(name)));
          return results.every(result => result.status === 'fulfilled' && result.value === true);
        } catch { return false; }
      })());
      if (indexedDB) jobs.push((async () => {
        try {
          if (typeof indexedDB.deleteDatabase !== 'function') return false;
          if (typeof indexedDB.databases !== 'function') {
            await Promise.all(TEARDOWN_KEYS.knownDatabases.filter(name => !databaseKeep.includes(name))
              .map(name => deleteDatabase(indexedDB, name)));
            // Without enumeration, unknown private databases cannot be ruled out.
            return false;
          }
          const databases = await indexedDB.databases();
          if (expired || !Array.isArray(databases)) return false;
          const privateNames = databases.filter(db => db.name && TEARDOWN_KEYS.indexedDBPrefixes
            .some(prefix => db.name.startsWith(prefix))).map(db => db.name);
          const results = await Promise.all(privateNames.filter(name => !databaseKeep.includes(name))
            .map(name => deleteDatabase(indexedDB, name)));
          return results.every(Boolean) && privateNames.every(name => TEARDOWN_KEYS.knownDatabases.includes(name));
        } catch { return false; }
      })());
      return (await Promise.all(jobs)).every(Boolean);
    })();
    const cleaned = await Promise.race([cleanup, timeout]);
    clearTimeout(timer);
    const finished = complete && cleaned;
    if (!finished) for (const key of sessionKeep) {
      if (key.startsWith('case-lab:segment:')) try { sessionStorage?.removeItem(key); } catch {}
    }
    return { complete: finished };
  };
}

/** On reload, finish private cleanup before considering an existing tab refresh or PKCE. */
export const recoverOnLoad = ({ nowMs = Date.now(), sessionStorage = safeStorage('sessionStorage'),
  preserveSessionKeys, ...options } = {}) => createTeardown({ ...options, sessionStorage,
  ...authNavigationPreservation({ sessionStorage, now: () => nowMs, preserveSessionKeys }) })('next_load');
