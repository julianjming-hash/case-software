const TABS=Object.freeze({facilitators:['facilitators_list','users','nextPage'],cases:['cases_list','versions','nextCursor'],rooms:['rooms_list','rooms','nextCursor'],audit:['audit_list','events','nextCursor']});
const DESTRUCTIVE=new Set(['facilitators_disable','facilitators_soft_delete','versions_withdraw','cases_publish','rooms_end']);
const MESSAGES=Object.freeze({conflict:'This record changed. Current information has been loaded.',forbidden:'This action is not permitted.',rate_limited:'Too many code attempts. Try again later.',request_timeout:'The request timed out. Check current information before acting again.',change_reverted_audit_unavailable:'The change was reverted because audit recording is unavailable.',manual_reconciliation_needed:'Manual reconciliation is needed. Do not repeat this action.',audit_unavailable:'Audit recording is unavailable. No change was made.',bad_request:'Check the information and try again.',admin_unavailable:'Administration is unavailable. Do not repeat an uncertain change.'});
export function adminMessage(error){return MESSAGES[error]??'Administration is unavailable.';}
export function createAdminModel({api,onChange=()=>{},now=Date.now}={}){
 let generation=0,closed=false,flight=false,elevation=null;
 const state={tab:'facilitators',gate:'loading',rows:[],selected:null,query:'',page:1,next:null,loading:false,acting:false,notice:''};
 const emit=()=>onChange(state);
 function dropElevation(){elevation=null;}
 const current=g=>!closed&&g===generation;
 function clear(reason='sign_out'){
  closed=true;generation++;dropElevation();state.rows.length=0;state.rows=[];state.selected=null;state.query='';state.next=null;state.notice='';state.loading=false;state.acting=false;state.gate=reason==='forbidden'?'admin_only':'sign_in';api.close();emit();
 }
 // R-a: the elevation lasts for this sign-in session; sign-out (clear) or a 403 drops it.
 function hasElevation(){return elevation!==null;}
 // Card 30: Administration -> Groups names this session's elevation on an archive (the Worker verifies it).
 function elevationToken(){return elevation?.token??null;}
 async function load({tab=state.tab,page=state.page,after=null}={}){
  if(closed||!Object.hasOwn(TABS,tab))return false;
  const g=++generation;state.tab=tab;state.page=page;state.rows=[];state.selected=null;state.next=null;state.loading=true;state.notice='';emit();
  const [operation,rowsKey,nextKey]=TABS[tab],search=tab==='facilitators'&&state.query;
  const result=await api.call(search?'facilitators_search':operation,search?{body:{query:state.query,page,perPage:100}}:{options:tab==='facilitators'?{page,perPage:100}:{limit:100,...(after?{after}:{})}});
  if(!current(g))return false;
  state.loading=false;
  if(!result.ok){
   state.gate=result.status===401?'sign_in':result.status===403?'admin_only':'unavailable';state.notice=adminMessage(result.error);emit();return false;
  }
  state.gate='ready';state.rows=result.data[rowsKey];state.next=result.data[nextKey];emit();return true;
 }
 function select(target){if(closed)return;generation++;state.selected=target;state.notice='';emit();}
 function cancel(){if(closed)return;generation++;state.selected=null;state.notice='';emit();}
 function setElevation(token){if(closed||typeof token!=='string'||!token||token.length>2048)return false;elevation={token};return true;}
 async function act(operation,{email=null}={}){
  if(closed||flight)return false;
  const selected=state.selected,g=generation;let options={},body={};
  if(operation==='facilitators_invite'){if(typeof email!=='string'||email.length>320)return false;body={email};}
  else{
   if(!selected)return false;
   if(operation.startsWith('facilitators_')){
    if(operation!=='facilitators_resend'&&(!selected.profile||!Number.isSafeInteger(selected.profile.admin_revision)))return false;
    options={id:selected.id};body=operation==='facilitators_resend'?{}:{expectedRevision:selected.profile.admin_revision,...(['facilitators_disable','facilitators_soft_delete'].includes(operation)?{confirmEmail:selected.email}:{})};
   }else if(operation==='cases_publish'){options={id:selected.case_id};body={versionId:selected.version_id,expectedRevision:selected.admin_revision};}
   else if(operation==='versions_withdraw'){options={id:selected.version_id};body={expectedRevision:selected.admin_revision};}
   else if(operation==='rooms_end')options={id:selected.sessionId};else return false;
  }
  if(DESTRUCTIVE.has(operation)&&!hasElevation()){state.notice='Enter a fresh email code before this action.';emit();return false;}
  flight=true;state.acting=true;emit();
  try{
   const result=await api.call(operation,{options,body,elevation:DESTRUCTIVE.has(operation)?elevation.token:null});
   if(!current(g))return false;
   if(!result.ok){
    if(result.status===403)dropElevation();
    if(result.status===409){await load();if(!closed){state.notice=adminMessage('conflict');emit();}}
    else {state.notice=adminMessage(result.error);emit();}
    return false;
   }
   await load();if(!closed){state.notice=operation==='facilitators_invite'&&result.data.idempotent?'This facilitator was already invited. No new email was sent.':'Action recorded.';emit();}return true;
  }catch{if(current(g)){state.notice=adminMessage('admin_unavailable');emit();}return false;}
  finally{flight=false;if(!closed){state.acting=false;emit();}}
 }
 return {state,load,select,cancel,clearElevation:dropElevation,setElevation,hasElevation,elevationToken,act,clear,async search(query){if(closed||typeof query!=='string'||query.length>320)return false;state.query=query;return load({tab:'facilitators',page:1});}};
}
